const jwt = require('jsonwebtoken');

/*
 * Reads the authentication token stored in the public site's HttpOnly
 * cookie. Valid account information is made available to every Handlebars
 * view so the shared navigation can show the correct account links.
 */
const loadCurrentUser = (req, res, next) => {
  const token = req.cookies?.travlr_token;

  res.locals.currentUser = null;
  res.locals.isLoggedIn = false;

  if (!token) {
    return next();
  }

  try {
    const user = jwt.verify(token, process.env.JWT_SECRET);

    res.locals.currentUser = user;
    res.locals.isLoggedIn = true;

    return next();
  } catch (error) {
    res.clearCookie('travlr_token');
    return next();
  }
};

/*
 * Protects customer account pages from visitors who have not logged in.
 */
const requireCustomerLogin = (req, res, next) => {
  if (!res.locals.currentUser) {
    return res.redirect('/login');
  }

  next();
};

module.exports = {
  loadCurrentUser,
  requireCustomerLogin
};