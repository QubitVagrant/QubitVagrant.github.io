const express = require('express');
const router = express.Router();

const ctrlTravlr =
  require('../controllers/travlr');

/*
 * Displays the complete trip list and recommendation form.
 */
router.get(
  '/',
  ctrlTravlr.travel
);

/*
 * Displays the dedicated details page for one trip.
 */
router.get(
  '/:tripCode',
  ctrlTravlr.tripDetails
);

module.exports = router;