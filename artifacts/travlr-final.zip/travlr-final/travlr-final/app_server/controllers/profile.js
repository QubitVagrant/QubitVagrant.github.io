const User = require('../../app_api/models/user');

const COOKIE_NAME = 'travlr_token';

const PHONE_PATTERN =
  /^[0-9+().\-\s]+$/;

const MIN_PASSWORD_LENGTH = 8;
const MAX_PASSWORD_LENGTH = 128;

const cookieOptions = {
  httpOnly: true,
  sameSite: 'lax',
  secure: process.env.NODE_ENV === 'production',
  maxAge: 60 * 60 * 1000
};

/*
 * Displays the profile editing form.
 */
const showEditAccount = async (req, res) => {
  res.locals.navAccount = true;

  try {
    const user = await User.findById(
      res.locals.currentUser._id
    );

    if (!user) {
      res.clearCookie(COOKIE_NAME);
      return res.redirect('/login');
    }

    return res.render('edit-account', {
      title: 'Edit Account',
      error: null,
      formData: {
        name: user.name || '',
        email: user.email || '',
        phone: user.phone || ''
      }
    });
  } catch (error) {
    console.error(
      'Account profile load failed:',
      error
    );

    return res.status(500).render(
      'edit-account',
      {
        title: 'Edit Account',
        error:
          'Your account details could not be loaded.',
        formData: {
          name:
            res.locals.currentUser?.name || '',
          email:
            res.locals.currentUser?.email || '',
          phone:
            res.locals.currentUser?.phone || ''
        }
      }
    );
  }
};

/*
 * Saves changes to the customer profile.
 */
const updateAccount = async (req, res) => {
  res.locals.navAccount = true;

  const name =
    req.body.name?.trim();

  const email =
    req.body.email
      ?.trim()
      .toLowerCase();

  const phone =
    req.body.phone?.trim();

  const formData = {
    name,
    email,
    phone
  };

  if (!name || !email || !phone) {
    return res.status(400).render(
      'edit-account',
      {
        title: 'Edit Account',
        error:
          'Name, email, and phone are required.',
        formData
      }
    );
  }

  if (
    phone.length < 7 ||
    phone.length > 20 ||
    !PHONE_PATTERN.test(phone)
  ) {
    return res.status(400).render(
      'edit-account',
      {
        title: 'Edit Account',
        error:
          'Enter a valid phone number.',
        formData
      }
    );
  }

  try {
    const user = await User.findById(
      res.locals.currentUser._id
    );

    if (!user) {
      res.clearCookie(COOKIE_NAME);
      return res.redirect('/login');
    }

    user.name = name;
    user.email = email;
    user.phone = phone;

    await user.save();

    const token =
      user.generateJWT();

    res.cookie(
      COOKIE_NAME,
      token,
      cookieOptions
    );

    return res.redirect('/account');
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).render(
        'edit-account',
        {
          title: 'Edit Account',
          error:
            'An account already exists for that email address.',
          formData
        }
      );
    }

    console.error(
      'Account profile update failed:',
      error
    );

    return res.status(500).render(
      'edit-account',
      {
        title: 'Edit Account',
        error:
          'Your account could not be updated. Please try again.',
        formData
      }
    );
  }
};

/*
 * Displays the password change form.
 */
const showChangePassword = (
  req,
  res
) => {
  res.locals.navAccount = true;

  return res.render(
    'change-password',
    {
      title: 'Change Password',
      error: null
    }
  );
};

/*
 * Verifies the current password and saves a new one.
 */
const updatePassword = async (
  req,
  res
) => {
  res.locals.navAccount = true;

  const currentPassword =
    req.body.currentPassword || '';

  const newPassword =
    req.body.newPassword || '';

  const confirmPassword =
    req.body.confirmPassword || '';

  const renderError = (
    status,
    message
  ) => {
    return res.status(status).render(
      'change-password',
      {
        title: 'Change Password',
        error: message
      }
    );
  };

  if (
    !currentPassword ||
    !newPassword ||
    !confirmPassword
  ) {
    return renderError(
      400,
      'All password fields are required.'
    );
  }

  if (
    newPassword.length <
      MIN_PASSWORD_LENGTH ||
    newPassword.length >
      MAX_PASSWORD_LENGTH
  ) {
    return renderError(
      400,
      `New password must contain between ${MIN_PASSWORD_LENGTH} and ${MAX_PASSWORD_LENGTH} characters.`
    );
  }

  if (
    newPassword !==
    confirmPassword
  ) {
    return renderError(
      400,
      'New password and confirmation do not match.'
    );
  }

  if (
    newPassword ===
    currentPassword
  ) {
    return renderError(
      400,
      'New password must be different from the current password.'
    );
  }

  try {
    const user = await User.findById(
      res.locals.currentUser._id
    );

    if (!user) {
      res.clearCookie(COOKIE_NAME);
      return res.redirect('/login');
    }

    if (
      !user.validPassword(
        currentPassword
      )
    ) {
      return renderError(
        400,
        'Current password is incorrect.'
      );
    }

    user.setPassword(
      newPassword
    );

    await user.save();

    const token =
      user.generateJWT();

    res.cookie(
      COOKIE_NAME,
      token,
      cookieOptions
    );

    return res.redirect(
      '/account?passwordChanged=true'
    );
  } catch (error) {
    console.error(
      'Password change failed:',
      error
    );

    return renderError(
      500,
      'Your password could not be changed. Please try again.'
    );
  }
};

module.exports = {
  showEditAccount,
  updateAccount,
  showChangePassword,
  updatePassword
};