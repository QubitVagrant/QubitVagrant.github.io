/*
 * Public informational-page controller.
 */
const API_SERVER =
  process.env.API_SERVER ||
  `http://localhost:${process.env.PORT || 3000}`;

/*
 * Safely reads JSON returned by the REST API.
 */
const readApiResponse = async (
  response
) => {
  const responseText =
    await response.text();

  if (!responseText) {
    return {};
  }

  try {
    return JSON.parse(
      responseText
    );
  } catch (error) {
    return {
      message: responseText
    };
  }
};

/*
 * Formats an article publication date for display.
 */
const formatArticleDate = (value) => {
  if (!value) {
    return '';
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return '';
  }

  return new Intl.DateTimeFormat(
    'en-US',
    {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      timeZone: 'UTC'
    }
  ).format(date);
};

/*
 * Converts stored article content into separate paragraphs for
 * the Handlebars article-details template.
 */
const getContentParagraphs = (
  content
) => {
  if (typeof content !== 'string') {
    return [];
  }

  return content
    .split(/\r?\n\s*\r?\n/)
    .map(
      (paragraph) =>
        paragraph.trim()
    )
    .filter(Boolean);
};

/*
 * Adds display values to one article returned by the API.
 */
const prepareArticleForDisplay = (
  article = {}
) => {
  return {
    ...article,

    formattedPublishedAt:
      formatArticleDate(
        article.publishedAt
      ),

    hasImage:
      Boolean(
        article.image
      ),

    contentParagraphs:
      getContentParagraphs(
        article.content
      )
  };
};

/*
 * GET home page.
 */
const index = (
  req,
  res
) => {
  return res.render(
    'index',
    {
      title:
        'Travlr Getaways',

      navHome:
        true
    }
  );
};

/*
 * GET Travel Blog article list.
 *
 * Published articles are retrieved from MongoDB through the REST API.
 */
const news = async (
  req,
  res
) => {
  try {
    const articleResponse =
      await fetch(
        `${API_SERVER}/api/articles`
      );

    const articleData =
      await readApiResponse(
        articleResponse
      );

    if (!articleResponse.ok) {
      return res
        .status(
          articleResponse.status
        )
        .render(
          'news',
          {
            title:
              'Travel Blog',

            navNews:
              true,

            articles:
              [],

            hasArticles:
              false,

            articleLoadError:
              articleData.message ||
              'Travel Blog articles could not be loaded.'
          }
        );
    }

    const articles =
      Array.isArray(articleData)
        ? articleData.map(
          prepareArticleForDisplay
        )
        : [];

    return res.render(
      'news',
      {
        title:
          'Travel Blog',

        navNews:
          true,

        articles,

        hasArticles:
          articles.length > 0,

        articleLoadError:
          null
      }
    );
  } catch (error) {
    console.error(
      'Travel Blog request failed:',
      error
    );

    return res
      .status(500)
      .render(
        'news',
        {
          title:
            'Travel Blog',

          navNews:
            true,

          articles:
            [],

          hasArticles:
            false,

          articleLoadError:
            'The Travel Blog is currently unavailable.'
        }
      );
  }
};

/*
 * GET one published Travel Blog article by its slug.
 */
const articleDetails = async (
  req,
  res
) => {
  const slug =
    typeof req.params.slug ===
    'string'
      ? req.params.slug
        .trim()
        .toLowerCase()
      : '';

  if (!slug) {
    return res
      .status(400)
      .render(
        'error',
        {
          message:
            'Article slug is required.',

          error: {}
        }
      );
  }

  try {
    const articleResponse =
      await fetch(
        `${API_SERVER}/api/articles/${encodeURIComponent(
          slug
        )}`
      );

    const articleData =
      await readApiResponse(
        articleResponse
      );

    if (!articleResponse.ok) {
      return res
        .status(
          articleResponse.status
        )
        .render(
          'error',
          {
            message:
              articleData.message ||
              'Article was not found.',

            error: {}
          }
        );
    }

    const article =
      prepareArticleForDisplay(
        articleData
      );

    return res.render(
      'article-details',
      {
        title:
          `${article.title} | Travel Blog`,

        navNews:
          true,

        article
      }
    );
  } catch (error) {
    console.error(
      'Article-details request failed:',
      error
    );

    return res
      .status(500)
      .render(
        'error',
        {
          message:
            'The Travel Blog is currently unavailable.',

          error: {}
        }
      );
  }
};

/*
 * GET combined about and contact page.
 */
const about = (
  req,
  res
) => {
  return res.render(
    'about',
    {
      title:
        'About',

      navAbout:
        true
    }
  );
};

module.exports = {
  index,
  news,
  articleDetails,
  about
};