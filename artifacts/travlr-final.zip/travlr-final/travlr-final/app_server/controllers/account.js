const passport = require('passport');
const User = require('../../app_api/models/user');

const COOKIE_NAME = 'travlr_token';

const API_SERVER =
  process.env.API_SERVER ||
  `http://localhost:${process.env.PORT || 3000}`;

const CANCELLATION_WINDOW_DAYS = 7;
const DAY_IN_MILLISECONDS =
  24 * 60 * 60 * 1000;

/*
 * Configures the secure cookie used by the server-rendered public site.
 * The cookie cannot be read through normal browser JavaScript.
 */
const cookieOptions = {
  httpOnly: true,
  sameSite: 'lax',
  secure: process.env.NODE_ENV === 'production',
  maxAge: 60 * 60 * 1000
};

/*
 * Safely reads one query-string value.
 */
const getQueryValue = (value) => {
  return typeof value === 'string'
    ? value.trim()
    : '';
};

/*
 * Formats a stored date for customer-facing pages.
 */
const formatDate = (value) => {
  if (!value) {
    return '';
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return '';
  }

  return new Intl.DateTimeFormat('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  }).format(date);
};

/*
 * Formats server-calculated currency values.
 */
const formatCurrency = (
  value,
  currency = 'USD'
) => {
  const amount = Number(value);

  if (!Number.isFinite(amount)) {
    return '';
  }

  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency
    }).format(amount);
  } catch (error) {
    return `$${amount.toFixed(2)}`;
  }
};

/*
 * Converts the stored booking location snapshot into readable text.
 */
const formatLocation = (location) => {
  if (!location) {
    return '';
  }

  if (typeof location === 'string') {
    return location;
  }

  return [
    location.city,
    location.stateOrRegion,
    location.country
  ]
    .filter(Boolean)
    .join(', ');
};

/*
 * Converts one booking document into the display values used by
 * account.hbs.
 */
const prepareBooking = (booking) => {
  const room =
    booking.room &&
    typeof booking.room === 'object'
      ? booking.room
      : {};

  const diningOptions =
    Array.isArray(booking.diningOptions)
      ? booking.diningOptions
      : [];

  const pricing =
    booking.pricing &&
    typeof booking.pricing === 'object'
      ? booking.pricing
      : {};

  const status =
    typeof booking.status === 'string'
      ? booking.status.toLowerCase()
      : 'confirmed';

  const startDate =
    booking.startDate
      ? new Date(booking.startDate)
      : null;

  const hasValidStartDate =
    startDate &&
    !Number.isNaN(startDate.getTime());

  const cancellationDeadline =
    hasValidStartDate
      ? new Date(
          startDate.getTime() -
          CANCELLATION_WINDOW_DAYS *
          DAY_IN_MILLISECONDS
        )
      : null;

  const canCancel =
    status === 'confirmed' &&
    cancellationDeadline !== null &&
    Date.now() <
      cancellationDeadline.getTime();

  const diningNames =
    diningOptions
      .map((option) => {
        if (!option) {
          return '';
        }

        if (typeof option === 'string') {
          return option;
        }

        return (
          option.name ||
          option.restaurantName ||
          option.code ||
          ''
        );
      })
      .filter(Boolean);

  const currency =
    pricing.currency || 'USD';

  return {
    bookingReference:
      booking.bookingReference || '',

    tripCode:
      booking.tripCode || '',

    tripName:
      booking.tripName ||
      'Travlr Getaway',

    resort:
      booking.resort || '',

    locationDisplay:
      formatLocation(
        booking.location
      ),

    startDisplay:
      formatDate(
        booking.startDate
      ),

    travelerCount:
      booking.travelerCount || 1,

    contactName:
      booking.contactName || '',

    contactEmail:
      booking.contactEmail || '',

    contactPhone:
      booking.contactPhone || '',

    roomName:
      room.name ||
      room.code ||
      'Included room',

    roomQuantity:
      room.quantity || 1,

    diningNames,

    hasDiningSelections:
      diningNames.length > 0,

    basePriceDisplay:
      formatCurrency(
        pricing.baseTripTotal,
        currency
      ),

    roomPriceDisplay:
      formatCurrency(
        pricing.roomUpgradeTotal,
        currency
      ),

    diningPriceDisplay:
      formatCurrency(
        pricing.diningTotal,
        currency
      ),

    totalDisplay:
      formatCurrency(
        pricing.totalPrice,
        currency
      ),

    status,

    statusLabel:
      status === 'cancelled'
        ? 'Cancelled'
        : 'Confirmed',

    isCancelled:
      status === 'cancelled',

    canCancel,

    cancellationDeadlineDisplay:
      formatDate(
        cancellationDeadline
      ),

    createdAtDisplay:
      formatDate(
        booking.createdAt
      ),

    cancelledAtDisplay:
      formatDate(
        booking.cancelledAt
      )
  };
};

/*
 * Retrieves bookings belonging to the authenticated customer.
 */
const getCustomerBookings = async (token) => {
  const response = await fetch(
    `${API_SERVER}/api/bookings`,
    {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        Authorization: `Bearer ${token}`
      }
    }
  );

  let responseBody = null;

  try {
    responseBody =
      await response.json();
  } catch (error) {
    responseBody = null;
  }

  if (!response.ok) {
    const requestError = new Error(
      responseBody?.message ||
      'Your bookings could not be loaded.'
    );

    requestError.status =
      response.status;

    throw requestError;
  }

  if (Array.isArray(responseBody)) {
    return responseBody;
  }

  if (
    Array.isArray(
      responseBody?.bookings
    )
  ) {
    return responseBody.bookings;
  }

  return [];
};

/*
 * Displays the customer registration form.
 */
const showRegister = (req, res) => {
  if (res.locals.isLoggedIn) {
    return res.redirect('/account');
  }

  return res.render('register', {
    title: 'Create Account',
    error: null,
    formData: {}
  });
};

/*
 * Creates a customer account and signs the customer in.
 */
const register = async (req, res) => {
  const name =
    req.body.name?.trim();

  const email =
    req.body.email
      ?.trim()
      .toLowerCase();

  const phone =
    req.body.phone?.trim();

  const password =
    req.body.password;

  const confirmPassword =
    req.body.confirmPassword;

  const formData = {
    name,
    email,
    phone
  };

  if (
    !name ||
    !email ||
    !phone ||
    !password ||
    !confirmPassword
  ) {
    return res.status(400).render(
      'register',
      {
        title: 'Create Account',
        error:
          'All account fields are required.',
        formData
      }
    );
  }

  if (
    phone.length < 7 ||
    phone.length > 20 ||
    !/^[0-9+().\-\s]+$/.test(phone)
  ) {
    return res.status(400).render(
      'register',
      {
        title: 'Create Account',
        error:
          'Enter a valid phone number.',
        formData
      }
    );
  }

  if (
    password !==
    confirmPassword
  ) {
    return res.status(400).render(
      'register',
      {
        title: 'Create Account',
        error:
          'The passwords do not match.',
        formData
      }
    );
  }

  if (password.length < 8) {
    return res.status(400).render(
      'register',
      {
        title: 'Create Account',
        error:
          'The password must contain at least eight characters.',
        formData
      }
    );
  }

  try {
    const user = new User({
      name,
      email,
      phone
    });

    user.setPassword(password);

    await user.save();

    const token =
      user.generateJWT();

    res.cookie(
      COOKIE_NAME,
      token,
      cookieOptions
    );

    return res.redirect('/account');
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).render(
        'register',
        {
          title: 'Create Account',
          error:
            'An account already exists for that email address.',
          formData
        }
      );
    }

    console.error(
      'Public account registration failed:',
      error
    );

    return res.status(500).render(
      'register',
      {
        title: 'Create Account',
        error:
          'The account could not be created. Please try again.',
        formData
      }
    );
  }
};

/*
 * Displays the customer login form.
 */
const showLogin = (req, res) => {
  if (res.locals.isLoggedIn) {
    return res.redirect('/account');
  }

  return res.render('login', {
    title: 'Log In',
    error: null,
    email: ''
  });
};

/*
 * Uses Passport to verify the customer credentials.
 */
const login = (req, res, next) => {
  const email =
    req.body.email
      ?.trim()
      .toLowerCase();

  const password =
    req.body.password;

  if (!email || !password) {
    return res.status(400).render(
      'login',
      {
        title: 'Log In',
        error:
          'Email and password are required.',
        email
      }
    );
  }

  req.body.email = email;

  return passport.authenticate(
    'local',
    (
      error,
      user,
      information
    ) => {
      if (error) {
        return next(error);
      }

      if (!user) {
        return res.status(401).render(
          'login',
          {
            title: 'Log In',
            error:
              information?.message ||
              'The email or password is incorrect.',
            email
          }
        );
      }

      const token =
        user.generateJWT();

      res.cookie(
        COOKIE_NAME,
        token,
        cookieOptions
      );

      return res.redirect('/account');
    }
  )(req, res, next);
};

/*
 * Displays the signed-in customer's account and booking history.
 */
const account = async (req, res) => {
  res.locals.navAccount = true;

  const token =
    req.cookies?.[COOKIE_NAME];

  if (!token) {
    return res.redirect('/login');
  }

  let bookings = [];
  let bookingLoadError = '';

  try {
    const bookingDocuments =
      await getCustomerBookings(token);

    bookings =
      bookingDocuments.map(
        prepareBooking
      );
  } catch (error) {
    if (
      error.status === 401 ||
      error.status === 403
    ) {
      res.clearCookie(
        COOKIE_NAME,
        {
          httpOnly: true,
          sameSite: 'lax',
          secure:
            process.env.NODE_ENV ===
            'production'
        }
      );

      return res.redirect('/login');
    }

    console.error(
      'Public booking history request failed:',
      error
    );

    bookingLoadError =
      error.message ||
      'Your bookings could not be loaded.';
  }

  const bookingReference =
    getQueryValue(
      req.query.bookingReference
    );

  const cancelledReference =
    getQueryValue(
      req.query.cancelledReference
    );

  const bookingError =
    getQueryValue(
      req.query.bookingError
    );

  /*
   * Confirmed bookings remain in the main Booked Trips section.
   * Cancelled bookings are placed in a separate archive.
   */
  const activeBookings =
    bookings.filter(
      (booking) =>
        !booking.isCancelled
    );

  const cancelledBookings =
    bookings.filter(
      (booking) =>
        booking.isCancelled
    );

  return res.render('account', {
    title: 'My Account',

    user:
      res.locals.currentUser,

    bookings:
      activeBookings,

    hasBookings:
      activeBookings.length > 0,

    cancelledBookings,

    hasCancelledBookings:
      cancelledBookings.length > 0,

    cancelledBookingCount:
      cancelledBookings.length,

    bookingReference:
      bookingReference || null,

    cancelledReference:
      cancelledReference || null,

    bookingError:
      bookingError || null,

    bookingLoadError:
      bookingLoadError || null
  });
};

/*
 * Removes the authentication cookie.
 */
const logout = (req, res) => {
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    sameSite: 'lax',
    secure:
      process.env.NODE_ENV ===
      'production'
  });

  return res.redirect('/');
};

module.exports = {
  showRegister,
  register,
  showLogin,
  login,
  account,
  logout
};