/*
 * Public travel-page controller.
 */
const apiOptions = {
  server:
    process.env.API_SERVER ||
    `http://localhost:${process.env.PORT || 3000}`
};

/*
 * Formats a trip date for customer-facing display.
 */
const formatTripDate = (value) => {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return '';
  }

  return date.toLocaleDateString(
    'en-US',
    {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
      timeZone: 'UTC'
    }
  );
};

/*
 * Formats database prices as US currency.
 */
const formatCurrency = (value) => {
  const amount = Number(value);

  if (!Number.isFinite(amount)) {
    return '';
  }

  return amount.toLocaleString(
    'en-US',
    {
      style: 'currency',
      currency: 'USD'
    }
  );
};

/*
 * Reads an API response while protecting the public site from
 * malformed or empty JSON responses.
 */
const readApiResponse = async (
  response
) => {
  const responseText =
    await response.text();

  if (!responseText) {
    return {};
  }

  try {
    return JSON.parse(
      responseText
    );
  } catch (error) {
    return {
      message: responseText
    };
  }
};

/*
 * Adds display-only values without changing the underlying
 * trip information returned by the API.
 *
 * Raw numeric values are preserved for the customer-side
 * booking price estimate.
 */
const prepareTripForDisplay = (
  trip = {}
) => {
  const startDate =
    new Date(trip.start);

  const hasFutureStartDate =
    !Number.isNaN(
      startDate.getTime()
    ) &&
    startDate.getTime() >
      Date.now();

  const gallery =
    Array.isArray(
      trip.gallery
    ) &&
    trip.gallery.length > 0
      ? trip.gallery
      : trip.image
        ? [trip.image]
        : [];

  const roomTypes =
    Array.isArray(
      trip.roomTypes
    )
      ? trip.roomTypes.map(
        (room) => {
          const nightlyRate =
            Number(
              room.nightlyRate
            );

          const maxGuests =
            Number(
              room.maxGuests
            );

          const availableUnits =
            Number(
              room.availableUnits
            );

          const normalizedNightlyRate =
            Number.isFinite(
              nightlyRate
            )
              ? nightlyRate
              : 0;

          const normalizedMaxGuests =
            Number.isInteger(
              maxGuests
            ) &&
            maxGuests > 0
              ? maxGuests
              : 1;

          const normalizedAvailableUnits =
            Number.isInteger(
              availableUnits
            ) &&
            availableUnits >= 0
              ? availableUnits
              : 0;

          return {
            ...room,

            nightlyRate:
              normalizedNightlyRate,

            maxGuests:
              normalizedMaxGuests,

            availableUnits:
              normalizedAvailableUnits,

            formattedNightlyRate:
              formatCurrency(
                normalizedNightlyRate
              ),

            isIncluded:
              normalizedNightlyRate === 0,

            isAvailable:
              normalizedAvailableUnits > 0
          };
        }
      )
      : [];

  /*
   * A trip can be booked when at least one room type
   * still has an available room.
   */
  const hasAvailableRooms =
    roomTypes.some(
      (room) =>
        room.isAvailable
    );

  const diningOptions =
    Array.isArray(
      trip.diningOptions
    )
      ? trip.diningOptions.map(
        (option) => {
          const pricePerPerson =
            Number(
              option.pricePerPerson
            );

          const normalizedPrice =
            Number.isFinite(
              pricePerPerson
            )
              ? pricePerPerson
              : 0;

          return {
            ...option,

            pricePerPerson:
              normalizedPrice,

            formattedPricePerPerson:
              formatCurrency(
                normalizedPrice
              ),

            pricingLabel:
              option.included
                ? 'Included'
                : `${formatCurrency(
                  normalizedPrice
                )} per person`
          };
        }
      )
      : [];

  const perPerson =
    Number(trip.perPerson);

  return {
    ...trip,

    perPerson:
      Number.isFinite(perPerson)
        ? perPerson
        : 0,

    formattedStart:
      formatTripDate(
        trip.start
      ),

    formattedPerPerson:
      formatCurrency(
        perPerson
      ),

    gallery,
    roomTypes,
    diningOptions,

    isSoldOut:
      !hasAvailableRooms,

    canBook:
      hasFutureStartDate &&
      hasAvailableRooms
  };
};

/*
 * Adds display values to the complete trip list.
 */
const prepareTripList = (
  trips = []
) => (
  trips.map(
    prepareTripForDisplay
  )
);

/*
 * Adds display values to each ranked recommendation.
 */
const prepareRecommendations = (
  recommendations = []
) => (
  recommendations.map(
    (result) => ({
      ...result,

      trip:
        prepareTripForDisplay(
          result.trip
        )
    })
  )
);

/*
 * Renders the public travel page with either the full trip list
 * or ranked recommendation results.
 */
const renderTravelPage = (
  req,
  res,
  trips,
  options = {}
) => {
  return res.render(
    'travel',
    {
      title:
        'Travlr Getaways',

      trips,

      recommendations:
        options.recommendations ||
        [],

      hasRecommendations:
        options.recommendations
          ?.length > 0,

      recommendationAttempted:
        options
          .recommendationAttempted ||
        false,

      recommendationError:
        options
          .recommendationError ||
        null,

      preferences:
        options.preferences ||
        {}
    }
  );
};

/*
 * Checks whether the customer supplied at least one recommendation
 * preference through the Travel page form.
 */
const hasRecommendationPreferences = (
  preferences
) => (
  Object.values(
    preferences
  ).some(
    (value) => (
      value !== undefined &&
      value !== null &&
      String(value).trim() !== ''
    )
  )
);

/*
 * GET travel page.
 *
 * Without preferences, the page displays every trip. When preferences
 * are provided, the API scores and ranks the available trips.
 */
const travel = async (
  req,
  res
) => {
  const preferences = {
    maximumPrice:
      req.query.maximumPrice ||
      '',

    resort:
      req.query.resort ||
      '',

    startDate:
      req.query.startDate ||
      '',

    length:
      req.query.length ||
      ''
  };

  try {
    const tripsResponse =
      await fetch(
        `${apiOptions.server}/api/trips`
      );

    const tripData =
      await readApiResponse(
        tripsResponse
      );

    if (!tripsResponse.ok) {
      return res
        .status(
          tripsResponse.status
        )
        .render(
          'error',
          {
            message:
              tripData.message ||
              'API lookup error',

            error: {}
          }
        );
    }

    const trips =
      prepareTripList(
        Array.isArray(tripData)
          ? tripData
          : []
      );

    if (
      !hasRecommendationPreferences(
        preferences
      )
    ) {
      return renderTravelPage(
        req,
        res,
        trips,
        {
          preferences
        }
      );
    }

    const query =
      new URLSearchParams();

    Object.entries(
      preferences
    ).forEach(
      ([key, value]) => {
        if (
          String(value)
            .trim() !== ''
        ) {
          query.set(
            key,
            value
          );
        }
      }
    );

    const recommendationResponse =
      await fetch(
        `${apiOptions.server}/api/trips/recommendations?${query.toString()}`
      );

    const recommendationData =
      await readApiResponse(
        recommendationResponse
      );

    if (
      !recommendationResponse.ok
    ) {
      return renderTravelPage(
        req,
        res,
        trips,
        {
          preferences,

          recommendationAttempted:
            true,

          recommendationError:
            recommendationData
              .message ||
            'Unable to generate recommendations.'
        }
      );
    }

    const recommendations =
      prepareRecommendations(
        Array.isArray(
          recommendationData
            .recommendations
        )
          ? recommendationData
            .recommendations
          : []
      );

    return renderTravelPage(
      req,
      res,
      trips,
      {
        preferences,

        recommendationAttempted:
          true,

        recommendations
      }
    );
  } catch (error) {
    console.error(
      'Travel page error:',
      error
    );

    return res
      .status(500)
      .render(
        'error',
        {
          message:
            'The trip service is currently unavailable.',

          error: {}
        }
      );
  }
};

/*
 * GET one public trip-details page using its permanent trip code.
 */
const tripDetails = async (
  req,
  res
) => {
  const tripCode =
    typeof req.params.tripCode ===
    'string'
      ? req.params.tripCode
        .trim()
        .toUpperCase()
      : '';

  if (!tripCode) {
    return res
      .status(400)
      .render(
        'error',
        {
          message:
            'Trip code is required.',

          error: {}
        }
      );
  }

  try {
    const tripResponse =
      await fetch(
        `${apiOptions.server}/api/trips/${encodeURIComponent(
          tripCode
        )}`
      );

    const tripData =
      await readApiResponse(
        tripResponse
      );

    if (!tripResponse.ok) {
      return res
        .status(
          tripResponse.status
        )
        .render(
          'error',
          {
            message:
              tripData.message ||
              'Trip was not found.',

            error: {}
          }
        );
    }

    const trip =
      prepareTripForDisplay(
        tripData
      );

    const bookingError =
      typeof req.query.bookingError ===
      'string'
        ? req.query.bookingError
          .trim()
        : '';

    return res.render(
      'trip-details',
      {
        title:
          `${trip.name} | Travlr Getaways`,

        trip,

        bookingError:
          bookingError ||
          null
      }
    );
  } catch (error) {
    console.error(
      'Trip-details page error:',
      error
    );

    return res
      .status(500)
      .render(
        'error',
        {
          message:
            'The trip service is currently unavailable.',

          error: {}
        }
      );
  }
};

module.exports = {
  travel,
  tripDetails
};