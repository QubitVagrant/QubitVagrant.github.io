const express = require('express');
const router = express.Router();

const tripsController =
  require('../controllers/trips');

const authController =
  require('../controllers/authentication');

const bookingsController =
  require('../controllers/bookings');

const articlesController =
  require('../controllers/articles');

const {
  authenticateJWT,
  requireAdmin
} = require('../middleware/auth');

/*
 * Public authentication routes allow users to create an account
 * and sign in without already having an authentication token.
 */
router
  .route('/register')
  .post(authController.register);

router
  .route('/login')
  .post(authController.login);

/*
 * Authenticated customers may create bookings and retrieve their
 * own booking history.
 */
router
  .route('/bookings')
  .get(
    authenticateJWT,
    bookingsController.bookingsListForCustomer
  )
  .post(
    authenticateJWT,
    bookingsController.bookingsCreate
  );

/*
 * Authenticated customers may cancel one of their own confirmed
 * bookings when it is outside the cancellation deadline.
 */
router
  .route('/bookings/:bookingReference/cancel')
  .patch(
    authenticateJWT,
    bookingsController.bookingsCancel
  );

/*
 * Anyone may retrieve published Travel Blog articles.
 * Creating an article requires an authenticated administrator.
 */
router
  .route('/articles')
  .get(
    articlesController.articlesListPublished
  )
  .post(
    authenticateJWT,
    requireAdmin,
    articlesController.articlesAddArticle
  );

/*
 * Administrators may retrieve every article, including drafts.
 *
 * This route must appear before /articles/:slug so Express does not
 * treat "admin" as an article slug.
 */
router
  .route('/articles/admin')
  .get(
    authenticateJWT,
    requireAdmin,
    articlesController.articlesListAll
  );

/*
 * Anyone may retrieve one published article by its slug.
 * Updating or deleting an article requires administrator access.
 */
router
  .route('/articles/:slug')
  .get(
    articlesController.articlesFindPublishedBySlug
  )
  .put(
    authenticateJWT,
    requireAdmin,
    articlesController.articlesUpdateArticle
  )
  .delete(
    authenticateJWT,
    requireAdmin,
    articlesController.articlesDeleteArticle
  );

/*
 * Anyone may view the trip list. Creating a trip requires both
 * a valid login token and the administrator role.
 */
router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(
    authenticateJWT,
    requireAdmin,
    tripsController.tripsAddTrip
  );

/*
 * Returns ranked trip recommendations from public query parameters.
 * This route must appear before /trips/:tripCode so Express does not
 * treat "recommendations" as a trip code.
 */
router
  .route('/trips/recommendations')
  .get(tripsController.tripsRecommend);

/*
 * Anyone may retrieve one trip by its code. Updating or deleting
 * the trip is restricted to authenticated administrator accounts.
 */
router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindCode)
  .put(
    authenticateJWT,
    requireAdmin,
    tripsController.tripsUpdateTrip
  )
  .delete(
    authenticateJWT,
    requireAdmin,
    tripsController.tripsDeleteTrip
  );

module.exports = router;