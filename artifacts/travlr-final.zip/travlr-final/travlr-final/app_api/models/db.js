const mongoose = require('mongoose');

const host =
  process.env.DB_HOST || '127.0.0.1';

const dbURI =
  `mongodb://${host}/travlr`;

mongoose.connect(dbURI);

mongoose.connection.on(
  'connected',
  () => {
    console.log(
      `Mongoose connected to ${dbURI}`
    );
  }
);

mongoose.connection.on(
  'error',
  (error) => {
    console.log(
      'Mongoose connection error:',
      error
    );
  }
);

mongoose.connection.on(
  'disconnected',
  () => {
    console.log(
      'Mongoose disconnected'
    );
  }
);

/*
 * Closes the MongoDB connection before the application exits.
 */
const gracefulShutdown = async (
  message,
  callback
) => {
  try {
    await mongoose.connection.close();

    console.log(
      `Mongoose disconnected through ${message}`
    );

    callback();
  } catch (error) {
    console.log(
      'Mongoose disconnection error:',
      error
    );

    callback();
  }
};

/*
 * Handles nodemon restarts.
 */
process.once(
  'SIGUSR2',
  () => {
    gracefulShutdown(
      'nodemon restart',
      () => {
        process.kill(
          process.pid,
          'SIGUSR2'
        );
      }
    );
  }
);

/*
 * Handles application termination from the terminal.
 */
process.on(
  'SIGINT',
  () => {
    gracefulShutdown(
      'app termination',
      () => {
        process.exit(0);
      }
    );
  }
);

/*
 * Handles hosted application termination.
 */
process.on(
  'SIGTERM',
  () => {
    gracefulShutdown(
      'application termination',
      () => {
        process.exit(0);
      }
    );
  }
);

/*
 * Registers all Mongoose models used by the application.
 */
require('./travlr');
require('./user');
require('./booking');
require('./article');