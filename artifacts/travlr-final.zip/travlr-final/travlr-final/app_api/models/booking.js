const mongoose = require('mongoose');

/*
 * Stores the room selection as a snapshot so an existing booking
 * remains accurate if the trip's room information changes later.
 */
const bookedRoomSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: true,
      trim: true,
      uppercase: true
    },

    name: {
      type: String,
      required: true,
      trim: true
    },

    nightlyRate: {
      type: Number,
      required: true,
      min: 0
    },

    quantity: {
      type: Number,
      required: true,
      min: 1,
      validate: {
        validator: Number.isInteger,
        message:
          'Room quantity must be a whole number.'
      }
    },

    maxGuests: {
      type: Number,
      required: true,
      min: 1,
      validate: {
        validator: Number.isInteger,
        message:
          'Maximum guests must be a whole number.'
      }
    }
  },
  {
    _id: false
  }
);

/*
 * Stores selected dining information as a snapshot so previous
 * bookings are not changed when resort dining options are edited.
 */
const bookedDiningOptionSchema =
  new mongoose.Schema(
    {
      code: {
        type: String,
        required: true,
        trim: true,
        uppercase: true
      },

      name: {
        type: String,
        required: true,
        trim: true
      },

      restaurantName: {
        type: String,
        required: true,
        trim: true
      },

      pricePerPerson: {
        type: Number,
        required: true,
        min: 0
      },

      included: {
        type: Boolean,
        required: true
      }
    },
    {
      _id: false
    }
  );

/*
 * Stores the resort location as it appeared when the customer
 * completed the booking.
 */
const bookedLocationSchema =
  new mongoose.Schema(
    {
      city: {
        type: String,
        required: true,
        trim: true
      },

      stateOrRegion: {
        type: String,
        trim: true,
        default: ''
      },

      country: {
        type: String,
        required: true,
        trim: true
      }
    },
    {
      _id: false
    }
  );

/*
 * Stores server-calculated prices. Values submitted by the browser
 * will not be trusted when a booking is created.
 */
const bookingPriceSchema =
  new mongoose.Schema(
    {
      baseTripTotal: {
        type: Number,
        required: true,
        min: 0
      },

      roomUpgradeTotal: {
        type: Number,
        required: true,
        min: 0
      },

      diningTotal: {
        type: Number,
        required: true,
        min: 0
      },

      totalPrice: {
        type: Number,
        required: true,
        min: 0
      },

      currency: {
        type: String,
        enum: ['USD'],
        default: 'USD',
        required: true
      }
    },
    {
      _id: false
    }
  );

/*
 * Defines a customer booking connected to both a user and a trip.
 * Important trip, room, dining, and price details are also stored
 * as snapshots for historical accuracy.
 */
const bookingSchema = new mongoose.Schema(
  {
    bookingReference: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true
    },

    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users',
      required: true,
      index: true
    },

    trip: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'trips',
      required: true,
      index: true
    },

    tripCode: {
      type: String,
      required: true,
      trim: true,
      uppercase: true
    },

    tripName: {
      type: String,
      required: true,
      trim: true
    },

    resort: {
      type: String,
      required: true,
      trim: true
    },

    location: {
      type: bookedLocationSchema,
      required: true
    },

    startDate: {
      type: Date,
      required: true
    },

    travelerCount: {
      type: Number,
      required: true,
      min: 1,
      max: 12,
      validate: {
        validator: Number.isInteger,
        message:
          'Traveler count must be a whole number.'
      }
    },

    contactName: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 120
    },

    contactEmail: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      maxlength: 254
    },

    contactPhone: {
      type: String,
      required: true,
      trim: true,
      minlength: 7,
      maxlength: 20
    },

    room: {
      type: bookedRoomSchema,
      required: true
    },

    diningOptions: {
      type: [bookedDiningOptionSchema],
      default: []
    },

    pricing: {
      type: bookingPriceSchema,
      required: true
    },

    status: {
      type: String,
      enum: [
        'confirmed',
        'cancelled'
      ],
      default: 'confirmed',
      required: true,
      index: true
    },

    cancelledAt: {
      type: Date,
      default: null
    },

    cancellationReason: {
      type: String,
      trim: true,
      maxlength: 500,
      default: ''
    }
  },
  {
    timestamps: true
  }
);

/*
 * Supports fast customer account booking-history queries.
 */
bookingSchema.index({
  customer: 1,
  createdAt: -1
});

/*
 * Supports availability checks and administrator booking reports
 * for a specific trip.
 */
bookingSchema.index({
  trip: 1,
  status: 1
});

/*
 * Supports lookups using the permanent customer-facing trip code.
 */
bookingSchema.index({
  tripCode: 1,
  status: 1
});

const Booking = mongoose.model(
  'bookings',
  bookingSchema
);

module.exports = Booking;