const mongoose = require('mongoose');

/*
 * Restricts customer-facing image values to safe local filenames.
 */
const imageFilenamePattern =
  /^[A-Za-z0-9._-]+\.(?:jpg|jpeg|png|webp)$/i;

const roomTypeSchema = new mongoose.Schema(
  {
    code: {
      type: String,
      required: true,
      trim: true,
      uppercase: true
    },

    name: {
      type: String,
      required: true,
      trim: true
    },

    description: {
      type: String,
      required: true,
      trim: true
    },

    image: {
      type: String,
      required: true,
      trim: true,
      validate: {
        validator: (value) =>
          imageFilenamePattern.test(value),

        message:
          'Room image must be a valid JPG, JPEG, PNG, or WebP filename.'
      }
    },

    nightlyRate: {
      type: Number,
      required: true,
      min: 0
    },

    /*
     * Maximum number of travelers allowed in one room.
     */
    maxGuests: {
      type: Number,
      required: true,
      min: 1,
      validate: {
        validator: Number.isInteger,
        message:
          'Maximum guests must be a whole number.'
      }
    },

    /*
     * Number of rooms of this type currently available.
     */
    availableUnits: {
      type: Number,
      required: true,
      min: 0,
      validate: {
        validator: Number.isInteger,
        message:
          'Available rooms must be a whole number.'
      }
    }
  },
  {
    _id: false
  }
);

const diningOptionSchema =
  new mongoose.Schema(
    {
      code: {
        type: String,
        required: true,
        trim: true,
        uppercase: true
      },

      name: {
        type: String,
        required: true,
        trim: true
      },

      restaurantName: {
        type: String,
        required: true,
        trim: true
      },

      description: {
        type: String,
        required: true,
        trim: true
      },

      pricePerPerson: {
        type: Number,
        required: true,
        min: 0
      },

      included: {
        type: Boolean,
        default: false
      }
    },
    {
      _id: false
    }
  );

/*
 * Prevents duplicate room or dining codes inside the same trip.
 */
const hasUniqueCodes = (items) => {
  if (!Array.isArray(items)) {
    return true;
  }

  const codes = items.map(
    (item) =>
      String(item.code || '')
        .trim()
        .toUpperCase()
  );

  return (
    new Set(codes).size ===
    codes.length
  );
};

const tripSchema =
  new mongoose.Schema(
    {
      code: {
        type: String,
        required: true,
        unique: true,
        trim: true,
        uppercase: true
      },

      name: {
        type: String,
        required: true,
        trim: true
      },

      length: {
        type: String,
        required: true,
        trim: true
      },

      start: {
        type: Date,
        required: true
      },

      resort: {
        type: String,
        required: true,
        trim: true
      },

      location: {
        city: {
          type: String,
          required: true,
          trim: true
        },

        stateOrRegion: {
          type: String,
          trim: true,
          default: ''
        },

        country: {
          type: String,
          required: true,
          trim: true
        }
      },

      perPerson: {
        type: Number,
        required: true,
        min: 0
      },

      image: {
        type: String,
        required: true,
        trim: true,
        validate: {
          validator: (value) =>
            imageFilenamePattern.test(
              value
            ),

          message:
            'Trip image must be a valid JPG, JPEG, PNG, or WebP filename.'
        }
      },

      gallery: {
        type: [String],
        default: [],
        validate: {
          validator: (images) =>
            images.every(
              (image) =>
                imageFilenamePattern.test(
                  image
                )
            ),

          message:
            'Gallery images must use valid JPG, JPEG, PNG, or WebP filenames.'
        }
      },

      description: {
        type: String,
        required: true,
        trim: true
      },

      details: {
        type: String,
        required: true,
        trim: true
      },

      /*
       * Inventory is tracked separately for each room type.
       */
      roomTypes: {
        type: [roomTypeSchema],
        default: [],
        validate: {
          validator: hasUniqueCodes,
          message:
            'Room type codes must be unique within a trip.'
        }
      },

      diningOptions: {
        type: [diningOptionSchema],
        default: [],
        validate: {
          validator: hasUniqueCodes,
          message:
            'Dining option codes must be unique within a trip.'
        }
      }
    },
    {
      timestamps: true
    }
  );

tripSchema.index({
  start: 1,
  perPerson: 1
});

tripSchema.index({
  resort: 1,
  'location.country': 1
});

tripSchema.index({
  name: 'text',
  resort: 'text',
  description: 'text',
  details: 'text',
  'location.city': 'text',
  'location.country': 'text'
});

const Trip = mongoose.model(
  'trips',
  tripSchema
);

module.exports = Trip;