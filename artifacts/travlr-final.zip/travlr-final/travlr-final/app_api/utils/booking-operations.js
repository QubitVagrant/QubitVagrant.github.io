const crypto = require('crypto');

const Trip =
  require('../models/travlr');

const {
  normalizeCode
} = require('./booking-validation');

const getTripNightCount = (
  length
) => {
  if (typeof length !== 'string') {
    return null;
  }

  const match =
    length.match(
      /^(\d+)\s+nights?/i
    );

  if (!match) {
    return null;
  }

  const nights =
    Number(match[1]);

  return (
    Number.isInteger(nights) &&
    nights > 0
  )
    ? nights
    : null;
};

const generateBookingReference = () => {
  const timestamp =
    Date.now()
      .toString(36)
      .toUpperCase();

  const randomCode =
    crypto
      .randomBytes(4)
      .toString('hex')
      .toUpperCase();

  return (
    `TVL-${timestamp}-${randomCode}`
  );
};

const getRoomSelection = (
  trip,
  roomCode,
  travelerCount
) => {
  const roomTypes =
    Array.isArray(
      trip.roomTypes
    )
      ? trip.roomTypes
      : [];

  const room =
    roomTypes.find(
      (roomType) =>
        normalizeCode(
          roomType.code
        ) === roomCode
    );

  if (!room) {
    return {
      error: {
        status: 400,
        message:
          'The selected room type is not available for this trip.'
      }
    };
  }

  const maxGuests =
    Number(
      room.maxGuests
    );

  if (
    !Number.isInteger(
      maxGuests
    ) ||
    maxGuests < 1
  ) {
    return {
      error: {
        status: 500,
        message:
          'The selected room occupancy is not configured correctly.'
      }
    };
  }

  const roomQuantity =
    Math.ceil(
      travelerCount /
      maxGuests
    );

  const nights =
    getTripNightCount(
      trip.length
    );

  if (!nights) {
    return {
      error: {
        status: 500,
        message:
          'The trip duration is not configured correctly.'
      }
    };
  }

  return {
    data: {
      room,
      maxGuests,
      roomQuantity,
      nights
    }
  };
};

const getDiningSelection = (
  trip,
  diningCodes
) => {
  const diningOptions =
    Array.isArray(
      trip.diningOptions
    )
      ? trip.diningOptions
      : [];

  const requestedDiningOptions =
    diningCodes.map(
      (diningCode) =>
        diningOptions.find(
          (option) =>
            normalizeCode(
              option.code
            ) === diningCode
        )
    );

  if (
    requestedDiningOptions.some(
      (option) =>
        !option
    )
  ) {
    return {
      error: {
        status: 400,
        message:
          'One or more selected dining options are not available for this trip.'
      }
    };
  }

  const selectedDiningMap =
    new Map();

  diningOptions
    .filter(
      (option) =>
        option.included
    )
    .forEach(
      (option) => {
        selectedDiningMap.set(
          normalizeCode(
            option.code
          ),
          option
        );
      }
    );

  requestedDiningOptions
    .forEach(
      (option) => {
        selectedDiningMap.set(
          normalizeCode(
            option.code
          ),
          option
        );
      }
    );

  return {
    data: [
      ...selectedDiningMap.values()
    ]
  };
};

const calculateBookingPricing = ({
  trip,
  room,
  travelerCount,
  roomQuantity,
  nights,
  selectedDiningOptions
}) => {
  const baseTripTotal =
    Number(
      trip.perPerson
    ) *
    travelerCount;

  const roomUpgradeTotal =
    Number(
      room.nightlyRate
    ) *
    nights *
    roomQuantity;

  const diningTotal =
    selectedDiningOptions.reduce(
      (
        total,
        option
      ) =>
        total +
        Number(
          option.pricePerPerson
        ) *
        travelerCount,

      0
    );

  return {
    baseTripTotal,
    roomUpgradeTotal,
    diningTotal,

    totalPrice:
      baseTripTotal +
      roomUpgradeTotal +
      diningTotal,

    currency:
      'USD'
  };
};

const reserveRoomAvailability =
  async ({
    tripId,
    roomCode,
    roomQuantity
  }) => {
    return Trip
      .findOneAndUpdate(
        {
          _id:
            tripId,

          roomTypes: {
            $elemMatch: {
              code:
                roomCode,

              availableUnits: {
                $gte:
                  roomQuantity
              }
            }
          }
        },
        {
          $inc: {
            'roomTypes.$[selectedRoom].availableUnits':
              -roomQuantity
          }
        },
        {
          arrayFilters: [
            {
              'selectedRoom.code':
                roomCode
            }
          ],

          returnDocument:
            'after',

          runValidators:
            true
        }
      )
      .exec();
  };

const restoreRoomAvailability =
  async ({
    tripId,
    roomCode,
    roomQuantity
  }) => {
    return Trip
      .findOneAndUpdate(
        {
          _id:
            tripId,

          roomTypes: {
            $elemMatch: {
              code:
                roomCode
            }
          }
        },
        {
          $inc: {
            'roomTypes.$[selectedRoom].availableUnits':
              roomQuantity
          }
        },
        {
          arrayFilters: [
            {
              'selectedRoom.code':
                roomCode
            }
          ],

          returnDocument:
            'after',

          runValidators:
            true
        }
      )
      .exec();
  };

const buildBookingData = ({
  customerId,
  trip,
  bookingInput,
  contactName,
  contactEmail,
  contactPhone,
  room,
  roomQuantity,
  maxGuests,
  selectedDiningOptions,
  pricing
}) => {
  return {
    bookingReference:
      generateBookingReference(),

    customer:
      customerId,

    trip:
      trip._id,

    tripCode:
      trip.code,

    tripName:
      trip.name,

    resort:
      trip.resort,

    location: {
      city:
        trip.location.city,

      stateOrRegion:
        trip.location
          .stateOrRegion || '',

      country:
        trip.location.country
    },

    startDate:
      trip.start,

    travelerCount:
      bookingInput.travelerCount,

    contactName,

    contactEmail,

    contactPhone,

    room: {
      code:
        room.code,

      name:
        room.name,

      nightlyRate:
        Number(
          room.nightlyRate
        ),

      quantity:
        roomQuantity,

      maxGuests
    },

    diningOptions:
      selectedDiningOptions.map(
        (option) => ({
          code:
            option.code,

          name:
            option.name,

          restaurantName:
            option.restaurantName,

          pricePerPerson:
            Number(
              option.pricePerPerson
            ),

          included:
            option.included
        })
      ),

    pricing
  };
};

module.exports = {
  buildBookingData,
  calculateBookingPricing,
  getDiningSelection,
  getRoomSelection,
  reserveRoomAvailability,
  restoreRoomAvailability
};