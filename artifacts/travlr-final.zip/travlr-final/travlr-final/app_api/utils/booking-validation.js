const MAX_TRAVELERS = 12;

const tripCodePattern =
  /^[A-Za-z0-9-]{3,20}$/;

const roomCodePattern =
  /^[A-Za-z0-9-]{2,20}$/;

const normalizeCode = (value) => {
  if (typeof value !== 'string') {
    return '';
  }

  return value
    .trim()
    .toUpperCase();
};

const normalizeText = (value) => {
  if (typeof value !== 'string') {
    return '';
  }

  return value.trim();
};

const getTravelerCount = (value) => {
  const travelerCount =
    Number(value);

  if (
    !Number.isInteger(travelerCount) ||
    travelerCount < 1 ||
    travelerCount > MAX_TRAVELERS
  ) {
    return null;
  }

  return travelerCount;
};

const validateBookingInput = (
  body = {}
) => {
  const errors = {};

  const tripCode =
    normalizeCode(body.tripCode);

  const roomCode =
    normalizeCode(body.roomCode);

  const travelerCount =
    getTravelerCount(
      body.travelerCount
    );

  if (
    !tripCodePattern.test(
      tripCode
    )
  ) {
    errors.tripCode =
      'A valid trip code is required.';
  }

  if (
    !roomCodePattern.test(
      roomCode
    )
  ) {
    errors.roomCode =
      'A valid room type is required.';
  }

  if (!travelerCount) {
    errors.travelerCount =
      `Traveler count must be a whole number between 1 and ${MAX_TRAVELERS}.`;
  }

  let diningCodes = [];

  if (
    body.diningCodes !== undefined
  ) {
    const submittedDiningCodes =
      Array.isArray(
        body.diningCodes
      )
        ? body.diningCodes
        : [body.diningCodes];

    diningCodes = [
      ...new Set(
        submittedDiningCodes
          .map(normalizeCode)
          .filter(Boolean)
      )
    ];
  }

  if (
    Object.keys(errors).length > 0
  ) {
    return {
      error: {
        message:
          'Booking validation failed.',

        errors
      }
    };
  }

  return {
    data: {
      tripCode,
      roomCode,
      travelerCount,
      diningCodes
    }
  };
};

module.exports = {
  normalizeCode,
  normalizeText,
  validateBookingInput
};