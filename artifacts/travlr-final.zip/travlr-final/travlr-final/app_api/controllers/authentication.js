const passport = require('passport');
const User = require('../models/user');

const PHONE_PATTERN =
  /^[0-9+().\-\s]+$/;

// Registers a new user.
const register = async (req, res) => {
  const name =
    req.body.name?.trim();

  const email =
    req.body.email
      ?.trim()
      .toLowerCase();

  const phone =
    req.body.phone?.trim();

  const password =
    req.body.password;

  if (
    !name ||
    !email ||
    !phone ||
    !password
  ) {
    return res
      .status(400)
      .json({
        message:
          'Name, email, phone, and password are required.'
      });
  }

  if (
    phone.length < 7 ||
    phone.length > 20 ||
    !PHONE_PATTERN.test(phone)
  ) {
    return res
      .status(400)
      .json({
        message:
          'Enter a valid phone number.'
      });
  }

  if (password.length < 8) {
    return res
      .status(400)
      .json({
        message:
          'The password must contain at least eight characters.'
      });
  }

  try {
    const user = new User({
      name,
      email,
      phone
    });

    user.setPassword(password);

    await user.save();

    const token =
      user.generateJWT();

    return res
      .status(200)
      .json({ token });
  } catch (error) {
    if (error.code === 11000) {
      return res
        .status(409)
        .json({
          message:
            'An account already exists for that email address.'
        });
    }

    return res
      .status(400)
      .json({
        message:
          'The account could not be created.'
      });
  }
};

// Logs in an existing user.
const login = (req, res) => {
  const email =
    req.body.email
      ?.trim()
      .toLowerCase();

  const password =
    req.body.password;

  if (!email || !password) {
    return res
      .status(400)
      .json({
        message:
          'Email and password are required.'
      });
  }

  req.body.email = email;

  passport.authenticate(
    'local',
    (error, user, information) => {
      if (error) {
        return res
          .status(500)
          .json({
            message:
              'Authentication failed.'
          });
      }

      if (user) {
        const token =
          user.generateJWT();

        return res
          .status(200)
          .json({ token });
      }

      return res
        .status(401)
        .json(
          information || {
            message:
              'The email or password is incorrect.'
          }
        );
    }
  )(req, res);
};

module.exports = {
  register,
  login
};