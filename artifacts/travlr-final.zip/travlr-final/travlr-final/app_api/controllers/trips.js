const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

const {
  rankTrips
} = require('../utils/trip-recommendation');

const {
  normalizeTripCode,
  normalizeTripInput,
  validateTripInput
} = require('../utils/trip-validation');

/*
 * Converts database failures into controlled API responses.
 */
const handleDatabaseError = (
  res,
  error
) => {
  if (
    error.name ===
      'ValidationError'
  ) {
    const errors =
      Object.fromEntries(
        Object.entries(
          error.errors
        ).map(
          ([
            field,
            details
          ]) => [
            field,
            details.message
          ]
        )
      );

    return res
      .status(400)
      .json({
        message:
          'Trip validation failed.',

        errors
      });
  }

  if (
    error.code === 11000
  ) {
    return res
      .status(409)
      .json({
        message:
          'A trip with that code already exists.'
      });
  }

  console.error(
    'Trip controller error:',
    error
  );

  return res
    .status(500)
    .json({
      message:
        'An unexpected server error occurred.'
    });
};

/*
 * Returns the complete trip list.
 */
const tripsList = async (
  req,
  res
) => {
  try {
    const trips =
      await Trip
        .find({})
        .exec();

    return res
      .status(200)
      .json(trips);
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Returns ranked trip recommendations.
 */
const tripsRecommend = async (
  req,
  res
) => {
  const preferences = {
    maximumPrice:
      req.query.maximumPrice,

    resort:
      req.query.resort,

    startDate:
      req.query.startDate,

    length:
      req.query.length
  };

  const hasPreference =
    Object.values(
      preferences
    ).some(
      (value) =>
        value !== undefined &&
        value !== null &&
        String(value)
          .trim() !== ''
    );

  if (!hasPreference) {
    return res
      .status(400)
      .json({
        message:
          'Provide at least one preference to receive trip recommendations.'
      });
  }

  try {
    const trips =
      await Trip
        .find({})
        .lean()
        .exec();

    const rankedTrips =
      rankTrips(
        trips,
        preferences
      )
        .filter(
          (result) =>
            result.score > 0
        )
        .map(
          (result) => ({
            trip:
              result.trip,

            score:
              result.score,

            matchReasons:
              result.matchReasons
          })
        );

    return res
      .status(200)
      .json({
        preferences,

        count:
          rankedTrips.length,

        recommendations:
          rankedTrips
      });
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Retrieves one trip using its permanent code.
 */
const tripsFindCode = async (
  req,
  res
) => {
  const tripCode =
    normalizeTripCode(
      req.params.tripCode
    );

  if (!tripCode) {
    return res
      .status(400)
      .json({
        message:
          'Trip code is required.'
      });
  }

  try {
    const trip =
      await Trip
        .findOne({
          code:
            tripCode
        })
        .exec();

    if (!trip) {
      return res
        .status(404)
        .json({
          message:
            'Trip code was not found.'
        });
    }

    return res
      .status(200)
      .json(trip);
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Creates a new expanded trip record.
 */
const tripsAddTrip = async (
  req,
  res
) => {
  const tripData =
    normalizeTripInput(
      req.body
    );

  const validationError =
    validateTripInput(
      tripData,
      {
        allowPastStartDate:
          false
      }
    );

  if (validationError) {
    return res
      .status(400)
      .json(
        validationError
      );
  }

  try {
    const savedTrip =
      await Trip.create(
        tripData
      );

    return res
      .status(201)
      .json(
        savedTrip
      );
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Updates every editable trip field.
 */
const tripsUpdateTrip = async (
  req,
  res
) => {
  const tripCode =
    normalizeTripCode(
      req.params.tripCode
    );

  if (!tripCode) {
    return res
      .status(400)
      .json({
        message:
          'Trip code is required.'
      });
  }

  const submittedCode =
    normalizeTripCode(
      req.body?.code
    );

  if (
    submittedCode &&
    submittedCode !== tripCode
  ) {
    return res
      .status(400)
      .json({
        message:
          'Trip code cannot be changed after the trip is created.',

        fields: [
          'code'
        ]
      });
  }

  const tripData =
    normalizeTripInput({
      ...req.body,

      code:
        tripCode
    });

  const validationError =
    validateTripInput(
      tripData,
      {
        allowPastStartDate:
          true
      }
    );

  if (validationError) {
    return res
      .status(400)
      .json(
        validationError
      );
  }

  const updatableTripData = {
    ...tripData
  };

  delete updatableTripData.code;

  try {
    const trip =
      await Trip
        .findOne({
          code:
            tripCode
        })
        .exec();

    if (!trip) {
      return res
        .status(404)
        .json({
          message:
            'Trip code was not found.'
        });
    }

    /*
     * Saving the Mongoose document ensures nested room,
     * dining, and image validators run.
     */
    trip.set(
      updatableTripData
    );

    const updatedTrip =
      await trip.save();

    return res
      .status(200)
      .json(
        updatedTrip
      );
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Deletes a trip using its permanent code.
 */
const tripsDeleteTrip = async (
  req,
  res
) => {
  const tripCode =
    normalizeTripCode(
      req.params.tripCode
    );

  if (!tripCode) {
    return res
      .status(400)
      .json({
        message:
          'Trip code is required.'
      });
  }

  try {
    const deletedTrip =
      await Trip
        .findOneAndDelete({
          code:
            tripCode
        })
        .exec();

    if (!deletedTrip) {
      return res
        .status(404)
        .json({
          message:
            'Trip code was not found.'
        });
    }

    return res
      .status(200)
      .json({
        message:
          'Trip deleted successfully.'
      });
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

module.exports = {
  tripsList,
  tripsRecommend,
  tripsFindCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};
