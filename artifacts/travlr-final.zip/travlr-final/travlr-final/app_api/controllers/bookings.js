const Booking =
  require('../models/booking');

const Trip =
  require('../models/travlr');

const User =
  require('../models/user');

const {
  normalizeCode,
  normalizeText,
  validateBookingInput
} = require('../utils/booking-validation');

const {
  buildBookingData,
  calculateBookingPricing,
  getDiningSelection,
  getRoomSelection,
  reserveRoomAvailability,
  restoreRoomAvailability
} = require('../utils/booking-operations');

const CANCELLATION_WINDOW_DAYS = 7;

const DAY_IN_MILLISECONDS =
  24 * 60 * 60 * 1000;

const emailPattern =
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const phonePattern =
  /^[0-9+().\-\s]{7,20}$/;

const handleDatabaseError = (
  res,
  error
) => {
  if (
    error.name ===
      'ValidationError'
  ) {
    const errors =
      Object.fromEntries(
        Object.entries(
          error.errors
        ).map(
          ([
            field,
            details
          ]) => [
            field,
            details.message
          ]
        )
      );

    return res
      .status(400)
      .json({
        message:
          'Booking validation failed.',

        errors
      });
  }

  if (
    error.name ===
      'CastError'
  ) {
    return res
      .status(400)
      .json({
        message:
          'The booking request contains an invalid identifier.'
      });
  }

  if (error.code === 11000) {
    return res
      .status(409)
      .json({
        message:
          'A booking reference conflict occurred. Please submit the booking again.'
      });
  }

  console.error(
    'Booking controller error:',
    error
  );

  return res
    .status(500)
    .json({
      message:
        'An unexpected server error occurred.'
    });
};

const bookingsCreate = async (
  req,
  res
) => {
  const customerId =
    req.user?._id;

  if (!customerId) {
    return res
      .status(401)
      .json({
        message:
          'Authentication is required.'
      });
  }

  const validation =
    validateBookingInput(
      req.body
    );

  if (validation.error) {
    return res
      .status(400)
      .json(
        validation.error
      );
  }

  const bookingInput =
    validation.data;

  try {
    const customer =
      await User
        .findById(
          customerId
        )
        .select(
          'name email phone'
        )
        .lean()
        .exec();

    if (!customer) {
      return res
        .status(401)
        .json({
          message:
            'The authenticated customer account was not found.'
        });
    }

    const contactName =
      normalizeText(
        customer.name
      );

    const contactEmail =
      normalizeText(
        customer.email
      ).toLowerCase();

    const contactPhone =
      normalizeText(
        customer.phone
      );

    if (
      contactName.length < 2 ||
      contactName.length > 120
    ) {
      return res
        .status(500)
        .json({
          message:
            'The customer account name is not configured correctly.'
        });
    }

    if (
      contactEmail.length > 254 ||
      !emailPattern.test(
        contactEmail
      )
    ) {
      return res
        .status(500)
        .json({
          message:
            'The customer account email is not configured correctly.'
        });
    }

    if (
      !phonePattern.test(
        contactPhone
      )
    ) {
      return res
        .status(500)
        .json({
          message:
            'The customer account phone number is not configured correctly.'
        });
    }

    const trip =
      await Trip
        .findOne({
          code:
            bookingInput.tripCode
        })
        .lean()
        .exec();

    if (!trip) {
      return res
        .status(404)
        .json({
          message:
            'Trip code was not found.'
        });
    }

    const startDate =
      new Date(
        trip.start
      );

    if (
      Number.isNaN(
        startDate.getTime()
      ) ||
      startDate <= new Date()
    ) {
      return res
        .status(409)
        .json({
          message:
            'Bookings are closed for this trip.'
        });
    }

    const roomSelection =
      getRoomSelection(
        trip,
        bookingInput.roomCode,
        bookingInput.travelerCount
      );

    if (roomSelection.error) {
      return res
        .status(
          roomSelection.error.status
        )
        .json({
          message:
            roomSelection.error.message
        });
    }

    const {
      room,
      maxGuests,
      roomQuantity,
      nights
    } = roomSelection.data;

    const diningSelection =
      getDiningSelection(
        trip,
        bookingInput.diningCodes
      );

    if (diningSelection.error) {
      return res
        .status(
          diningSelection.error.status
        )
        .json({
          message:
            diningSelection.error.message
        });
    }

    const selectedDiningOptions =
      diningSelection.data;

    const pricing =
      calculateBookingPricing({
        trip,
        room,

        travelerCount:
          bookingInput.travelerCount,

        roomQuantity,
        nights,
        selectedDiningOptions
      });

    const reservedTrip =
      await reserveRoomAvailability({
        tripId:
          trip._id,

        roomCode:
          room.code,

        roomQuantity
      });

    if (!reservedTrip) {
      return res
        .status(409)
        .json({
          message:
            'The selected room type no longer has enough rooms available.'
        });
    }

    try {
      const booking =
        await Booking.create(
          buildBookingData({
            customerId,
            trip,
            bookingInput,
            contactName,
            contactEmail,
            contactPhone,
            room,
            roomQuantity,
            maxGuests,
            selectedDiningOptions,
            pricing
          })
        );

      return res
        .status(201)
        .json(
          booking
        );
    } catch (error) {
      await restoreRoomAvailability({
        tripId:
          trip._id,

        roomCode:
          room.code,

        roomQuantity
      });

      throw error;
    }
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

const bookingsListForCustomer =
  async (
    req,
    res
  ) => {
    const customerId =
      req.user?._id;

    if (!customerId) {
      return res
        .status(401)
        .json({
          message:
            'Authentication is required.'
        });
    }

    try {
      const bookings =
        await Booking
          .find({
            customer:
              customerId
          })
          .sort({
            createdAt:
              -1
          })
          .exec();

      return res
        .status(200)
        .json(
          bookings
        );
    } catch (error) {
      return handleDatabaseError(
        res,
        error
      );
    }
  };

const bookingsCancel = async (
  req,
  res
) => {
  const customerId =
    req.user?._id;

  const bookingReference =
    normalizeCode(
      req.params.bookingReference
    );

  const cancellationReason =
    normalizeText(
      req.body?.cancellationReason
    );

  if (!customerId) {
    return res
      .status(401)
      .json({
        message:
          'Authentication is required.'
      });
  }

  if (!bookingReference) {
    return res
      .status(400)
      .json({
        message:
          'Booking reference is required.'
      });
  }

  if (
    cancellationReason.length > 500
  ) {
    return res
      .status(400)
      .json({
        message:
          'Cancellation reason cannot exceed 500 characters.'
      });
  }

  try {
    const booking =
      await Booking
        .findOne({
          bookingReference,

          customer:
            customerId
        })
        .lean()
        .exec();

    if (!booking) {
      return res
        .status(404)
        .json({
          message:
            'Booking was not found.'
        });
    }

    if (
      booking.status ===
        'cancelled'
    ) {
      return res
        .status(409)
        .json({
          message:
            'This booking is already cancelled.'
        });
    }

    const cancellationDeadline =
      new Date(
        booking.startDate
      ).getTime() -
      CANCELLATION_WINDOW_DAYS *
      DAY_IN_MILLISECONDS;

    if (
      Date.now() >=
      cancellationDeadline
    ) {
      return res
        .status(409)
        .json({
          message:
            `Bookings must be cancelled at least ${CANCELLATION_WINDOW_DAYS} days before departure.`
        });
    }

    const cancelledBooking =
      await Booking
        .findOneAndUpdate(
          {
            _id:
              booking._id,

            status:
              'confirmed'
          },
          {
            $set: {
              status:
                'cancelled',

              cancelledAt:
                new Date(),

              cancellationReason
            }
          },
          {
            returnDocument:
              'after',

            runValidators:
              true
          }
        )
        .exec();

    if (!cancelledBooking) {
      return res
        .status(409)
        .json({
          message:
            'The booking status changed before the cancellation completed.'
        });
    }

    try {
      const restoredTrip =
        await restoreRoomAvailability({
          tripId:
            booking.trip,

          roomCode:
            booking.room.code,

          roomQuantity:
            booking.room.quantity
        });

      if (!restoredTrip) {
        throw new Error(
          'The trip room inventory was not available for restoration.'
        );
      }
    } catch (error) {
      await Booking
        .findOneAndUpdate(
          {
            _id:
              booking._id,

            status:
              'cancelled'
          },
          {
            $set: {
              status:
                'confirmed',

              cancelledAt:
                null,

              cancellationReason:
                ''
            }
          },
          {
            returnDocument:
              'after',

            runValidators:
              true
          }
        )
        .exec();

      throw error;
    }

    return res
      .status(200)
      .json(
        cancelledBooking
      );
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

module.exports = {
  bookingsCreate,
  bookingsListForCustomer,
  bookingsCancel
};