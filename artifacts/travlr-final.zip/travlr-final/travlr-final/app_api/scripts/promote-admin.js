require('dotenv').config();

const mongoose = require('mongoose');
const User = require('../models/user');

const adminEmail = process.argv[2]?.trim().toLowerCase();
const databaseHost = process.env.DB_HOST || '127.0.0.1';
const databaseUri =
  process.env.DB_URI || `mongodb://${databaseHost}/travlr`;

if (!adminEmail) {
  console.error(
    'Provide the email address of the account to promote.'
  );
  process.exit(1);
}

/*
 * Promotes one existing account to the administrator role.
 * Public registration continues to create customer accounts by default,
 * so administrator access cannot be requested through registration.
 */
const promoteAdmin = async () => {
  try {
    await mongoose.connect(databaseUri);

    const user = await User.findOneAndUpdate(
      {
        email: adminEmail
      },
      {
        $set: {
          role: 'admin'
        }
      },
      {
        returnDocument: 'after',
        runValidators: true
      }
    ).exec();

    if (!user) {
      throw new Error(
        `No account was found for ${adminEmail}.`
      );
    }

    console.log(
      `${user.email} now has the admin role.`
    );
  } catch (error) {
    console.error(
      'Administrator promotion failed:',
      error.message
    );

    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
};

promoteAdmin();