import {
  ComponentFixture,
  TestBed
} from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';

import { Authentication } from '../services/authentication';
import { TripData } from '../services/trip-data';
import { TripListing } from './trip-listing';

describe('TripListing', () => {
  let component: TripListing;
  let fixture: ComponentFixture<TripListing>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TripListing],
      providers: [
        provideRouter([]),
        {
          provide: TripData,
          useValue: {
            getTrips: () => of([])
          }
        },
        {
          provide: Authentication,
          useValue: {
            isLoggedIn: () => false
          }
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(TripListing);
    component = fixture.componentInstance;

    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});