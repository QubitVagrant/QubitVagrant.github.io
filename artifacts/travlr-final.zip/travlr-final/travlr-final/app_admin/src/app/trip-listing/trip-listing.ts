import { CommonModule } from '@angular/common';
import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';
import { Router } from '@angular/router';

import { TripCard } from '../trip-card/trip-card';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  imports: [
    CommonModule,
    TripCard
  ],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css'
})
export class TripListing implements OnInit {
  public trips: Trip[] = [];

  constructor(
    private readonly tripDataService: TripData,
    private readonly router: Router,
    private readonly cdr: ChangeDetectorRef,
    private readonly authenticationService: Authentication
  ) {}

  public ngOnInit(): void {
    this.getTrips();
  }

  private getTrips(): void {
    this.tripDataService
      .getTrips()
      .subscribe({
        next: (trips: Trip[]) => {
          this.trips = trips;
          this.cdr.detectChanges();
        }
      });
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  public addTrip(): void {
    this.router.navigate(['/add-trip']);
  }
}