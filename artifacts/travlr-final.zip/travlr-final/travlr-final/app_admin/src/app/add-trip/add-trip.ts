import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { finalize } from 'rxjs';

import { TripData } from '../services/trip-data';
import { TripForm } from '../trip-form/trip-form';
import {
  createTripForm,
  getTripApiErrorMessage,
  normalizeTripFormValue
} from '../utils/trip-form';

@Component({
  selector: 'app-add-trip',
  imports: [TripForm],
  templateUrl: './add-trip.html'
})
export class AddTrip implements OnInit {
  public addForm!: FormGroup;
  public formError = '';
  public isSubmitting = false;

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly tripDataService: TripData,
    private readonly router: Router
  ) {}

  public ngOnInit(): void {
    this.addForm = createTripForm(this.formBuilder, {
      allowPastStartDate: false
    });
  }

  public onSubmit(): void {
    this.formError = '';
    this.isSubmitting = true;

    const trip = normalizeTripFormValue(
      this.addForm.getRawValue()
    );

    this.tripDataService
      .addTrip(trip)
      .pipe(
        finalize(() => {
          this.isSubmitting = false;
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate(['/trips']);
        },

        error: (error: HttpErrorResponse) => {
          this.formError = getTripApiErrorMessage(
            error,
            'The trip could not be added. Please try again.'
          );
        }
      });
  }

  public cancel(): void {
    this.router.navigate(['/trips']);
  }
}