import { HttpErrorResponse } from '@angular/common/http';
import { CommonModule } from '@angular/common';

import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import { finalize } from 'rxjs';

import {
  Article,
  ArticlePublicationStatus
} from '../models/article';

import { ArticleData } from '../services/article-data';

@Component({
  selector: 'app-edit-article',
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './edit-article.html',
  styleUrl: './edit-article.css'
})
export class EditArticle implements OnInit {
  public editForm!: FormGroup;

  public formError = '';
  public isLoading = true;
  public isSubmitting = false;

  private currentSlug = '';
  private currentArticle: Article | null = null;

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly articleDataService: ArticleData,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly cdr: ChangeDetectorRef
  ) {}

  public ngOnInit(): void {
    this.editForm =
      this.formBuilder.group({
        title: [
          '',
          [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(160)
          ]
        ],

        slug: [
          '',
          [
            Validators.required,
            Validators.maxLength(180),
            Validators.pattern(
              /^[a-z0-9]+(?:-[a-z0-9]+)*$/
            )
          ]
        ],

        summary: [
          '',
          [
            Validators.required,
            Validators.minLength(10),
            Validators.maxLength(500)
          ]
        ],

        content: [
          '',
          [
            Validators.required,
            Validators.minLength(20),
            Validators.maxLength(20000)
          ]
        ],

        image: [
          '',
          [
            Validators.maxLength(255),
            Validators.pattern(
              /^(?:|[^\\/:*?"<>|]+\.(?:jpe?g|png|webp))$/i
            )
          ]
        ],

        publicationStatus: [
          'draft',
          [
            Validators.required
          ]
        ]
      });

    this.currentSlug =
      String(
        this.route.snapshot.paramMap.get(
          'slug'
        ) || ''
      )
        .trim()
        .toLowerCase();

    if (!this.currentSlug) {
      this.formError =
        'An article slug is required.';

      this.isLoading = false;
      this.cdr.detectChanges();

      return;
    }

    this.loadArticle();
  }

  private loadArticle(): void {
    this.formError = '';
    this.isLoading = true;

    this.articleDataService
      .getArticles()
      .subscribe({
        next: (articles: Article[]) => {
          const article =
            articles.find(
              (currentArticle) =>
                currentArticle.slug ===
                this.currentSlug
            );

          if (!article) {
            this.formError =
              'The selected article was not found.';

            this.isLoading = false;
            this.cdr.detectChanges();

            return;
          }

          this.currentArticle = article;

          this.editForm.patchValue({
            title:
              article.title,

            slug:
              article.slug,

            summary:
              article.summary,

            content:
              article.content,

            image:
              article.image || '',

            publicationStatus:
              article.publicationStatus
          });

          this.isLoading = false;
          this.cdr.detectChanges();
        },

        error: (
          error: HttpErrorResponse
        ) => {
          this.formError =
            this.getApiErrorMessage(
              error,
              'The article could not be loaded.'
            );

          this.isLoading = false;
          this.cdr.detectChanges();
        }
      });
  }

  public isInvalid(
    controlName: string
  ): boolean {
    const control =
      this.editForm.get(
        controlName
      );

    return Boolean(
      control &&
      control.invalid &&
      (
        control.touched ||
        control.dirty
      )
    );
  }

  public hasError(
    controlName: string,
    errorName: string
  ): boolean {
    const control =
      this.editForm.get(
        controlName
      );

    return Boolean(
      control &&
      control.hasError(
        errorName
      ) &&
      (
        control.touched ||
        control.dirty
      )
    );
  }

  private getApiErrorMessage(
    error: HttpErrorResponse,
    fallbackMessage: string
  ): string {
    if (
      error.error &&
      typeof error.error.message ===
        'string'
    ) {
      return error.error.message;
    }

    return fallbackMessage;
  }

  public onSubmit(): void {
    this.formError = '';

    if (
      this.editForm.invalid ||
      !this.currentArticle
    ) {
      this.editForm.markAllAsTouched();

      this.formError =
        'Correct the highlighted fields before saving the article.';

      return;
    }

    this.isSubmitting = true;

    const formValue =
      this.editForm.getRawValue();

    const article: Article = {
      ...this.currentArticle,

      title:
        String(
          formValue.title || ''
        ).trim(),

      slug:
        String(
          formValue.slug || ''
        )
          .trim()
          .toLowerCase(),

      summary:
        String(
          formValue.summary || ''
        ).trim(),

      content:
        String(
          formValue.content || ''
        ).trim(),

      image:
        String(
          formValue.image || ''
        ).trim(),

      publicationStatus:
        formValue.publicationStatus as
          ArticlePublicationStatus
    };

    this.articleDataService
      .updateArticle(
        this.currentSlug,
        article
      )
      .pipe(
        finalize(() => {
          this.isSubmitting = false;
          this.cdr.detectChanges();
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate([
            '/articles'
          ]);
        },

        error: (
          error: HttpErrorResponse
        ) => {
          this.formError =
            this.getApiErrorMessage(
              error,
              'The article could not be updated.'
            );

          this.cdr.detectChanges();
        }
      });
  }

  public cancel(): void {
    this.router.navigate([
      '/articles'
    ]);
  }
}