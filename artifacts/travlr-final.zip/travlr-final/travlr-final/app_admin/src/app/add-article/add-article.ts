import { HttpErrorResponse } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import { Router } from '@angular/router';
import { finalize } from 'rxjs';

import {
  Article,
  ArticlePublicationStatus
} from '../models/article';

import { ArticleData } from '../services/article-data';

@Component({
  selector: 'app-add-article',
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './add-article.html',
  styleUrl: './add-article.css'
})
export class AddArticle implements OnInit {
  public addForm!: FormGroup;
  public formError = '';
  public isSubmitting = false;

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly articleDataService: ArticleData,
    private readonly router: Router
  ) {}

  /*
   * Builds the Add Article form with validation.
   */
  public ngOnInit(): void {
    this.addForm =
      this.formBuilder.group({
        title: [
          '',
          [
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(160)
          ]
        ],

        slug: [
          '',
          [
            Validators.maxLength(180),
            Validators.pattern(
              /^[a-z0-9]+(?:-[a-z0-9]+)*$/
            )
          ]
        ],

        summary: [
          '',
          [
            Validators.required,
            Validators.minLength(10),
            Validators.maxLength(500)
          ]
        ],

        content: [
          '',
          [
            Validators.required,
            Validators.minLength(20),
            Validators.maxLength(20000)
          ]
        ],

        image: [
          '',
          [
            Validators.maxLength(255),
            Validators.pattern(
              /^(?:|[^\\/:*?"<>|]+\.(?:jpe?g|png|webp))$/i
            )
          ]
        ],

        publicationStatus: [
          'draft',
          [
            Validators.required
          ]
        ]
      });
  }

  /*
   * Reports whether a field is invalid after interaction.
   */
  public isInvalid(
    controlName: string
  ): boolean {
    const control =
      this.addForm.get(
        controlName
      );

    return Boolean(
      control &&
      control.invalid &&
      (
        control.touched ||
        control.dirty
      )
    );
  }

  /*
   * Reports whether one specific validation rule failed.
   */
  public hasError(
    controlName: string,
    errorName: string
  ): boolean {
    const control =
      this.addForm.get(
        controlName
      );

    return Boolean(
      control &&
      control.hasError(
        errorName
      ) &&
      (
        control.touched ||
        control.dirty
      )
    );
  }

  /*
   * Returns a controlled API error message.
   */
  private getApiErrorMessage(
    error: HttpErrorResponse
  ): string {
    const responseBody =
      error.error;

    if (
      responseBody &&
      typeof responseBody.message ===
        'string'
    ) {
      return responseBody.message;
    }

    return (
      'The article could not be added. Please try again.'
    );
  }

  /*
   * Validates, normalizes, and submits the new article.
   */
  public onSubmit(): void {
    this.formError = '';

    if (this.addForm.invalid) {
      this.addForm.markAllAsTouched();

      this.formError =
        'Correct the highlighted fields before saving the article.';

      return;
    }

    this.isSubmitting = true;

    const formValue =
      this.addForm.getRawValue();

    const article: Article = {
      title:
        String(
          formValue.title || ''
        ).trim(),

      slug:
        String(
          formValue.slug || ''
        )
          .trim()
          .toLowerCase(),

      summary:
        String(
          formValue.summary || ''
        ).trim(),

      content:
        String(
          formValue.content || ''
        ).trim(),

      image:
        String(
          formValue.image || ''
        ).trim(),

      publicationStatus:
        formValue.publicationStatus as
          ArticlePublicationStatus,

      publishedAt:
        null
    };

    this.articleDataService
      .addArticle(article)
      .pipe(
        finalize(() => {
          this.isSubmitting =
            false;
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate([
            '/articles'
          ]);
        },

        error: (
          error: HttpErrorResponse
        ) => {
          this.formError =
            this.getApiErrorMessage(
              error
            );
        }
      });
  }

  /*
   * Returns to the article listing without saving.
   */
  public cancel(): void {
    this.router.navigate([
      '/articles'
    ]);
  }
}