import {
  ComponentFixture,
  TestBed
} from '@angular/core/testing';
import { provideRouter } from '@angular/router';

import { Trip } from '../models/trip';
import { Authentication } from '../services/authentication';
import { TripCard } from './trip-card';

describe('TripCard', () => {
  let component: TripCard;
  let fixture: ComponentFixture<TripCard>;

  const trip: Trip = {
    code: 'TEST100',
    name: 'Test Trip',
    length: '4 nights / 5 days',
    start: '2027-01-01',
    resort: 'Test Resort',
    location: {
      city: 'Test City',
      stateOrRegion: '',
      country: 'Test Country'
    },
    perPerson: 1000,
    image: 'test.jpg',
    gallery: [],
    description: 'A test trip description.',
    details: 'Complete details for the test trip.',
    roomTypes: [],
    diningOptions: []
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TripCard],
      providers: [
        provideRouter([]),
        {
          provide: Authentication,
          useValue: {
            isLoggedIn: () => false
          }
        }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(TripCard);
    component = fixture.componentInstance;

    fixture.componentRef.setInput(
      'trip',
      trip
    );

    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});