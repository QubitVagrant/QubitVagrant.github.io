export interface TripLocation {
  city: string;
  stateOrRegion: string;
  country: string;
}

export interface RoomType {
  code: string;
  name: string;
  description: string;
  image: string;
  nightlyRate: number;
  maxGuests: number;
  availableUnits: number;
}

export interface DiningOption {
  code: string;
  name: string;
  restaurantName: string;
  description: string;
  pricePerPerson: number;
  included: boolean;
}

export interface Trip {
  _id?: string;

  code: string;
  name: string;
  length: string;
  start: string;
  resort: string;

  location: TripLocation;

  perPerson: number;

  image: string;
  gallery: string[];

  description: string;
  details: string;

  roomTypes: RoomType[];
  diningOptions: DiningOption[];

  createdAt?: string;
  updatedAt?: string;
}