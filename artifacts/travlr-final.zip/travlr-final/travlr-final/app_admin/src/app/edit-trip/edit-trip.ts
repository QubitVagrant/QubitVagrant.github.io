import { HttpErrorResponse } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import {
  Component,
  OnInit,
  signal
} from '@angular/core';
import {
  FormBuilder,
  FormGroup
} from '@angular/forms';
import {
  ActivatedRoute,
  Router
} from '@angular/router';
import { finalize } from 'rxjs';

import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import { TripForm } from '../trip-form/trip-form';
import {
  createTripForm,
  getTripApiErrorMessage,
  normalizeTripFormValue,
  populateTripForm
} from '../utils/trip-form';

@Component({
  selector: 'app-edit-trip',
  imports: [
    CommonModule,
    TripForm
  ],
  templateUrl: './edit-trip.html'
})
export class EditTrip implements OnInit {
  public editForm!: FormGroup;
  public tripCode = '';

  public readonly formError = signal('');
  public readonly isLoading = signal(true);
  public readonly isSubmitting = signal(false);

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly tripDataService: TripData
  ) {}

  public ngOnInit(): void {
    this.editForm = createTripForm(this.formBuilder, {
      allowPastStartDate: true
    });

    this.tripCode =
      this.route.snapshot.paramMap
        .get('tripCode')
        ?.trim() || '';

    if (!this.tripCode) {
      this.isLoading.set(false);
      this.formError.set(
        'A trip code was not provided.'
      );
      return;
    }

    this.loadTrip();
  }

  private loadTrip(): void {
    this.formError.set('');
    this.isLoading.set(true);

    this.tripDataService
      .getTrip(this.tripCode)
      .pipe(
        finalize(() => {
          this.isLoading.set(false);
        })
      )
      .subscribe({
        next: (trip: Trip) => {
          populateTripForm(
            this.formBuilder,
            this.editForm,
            trip
          );
        },

        error: (error: HttpErrorResponse) => {
          this.formError.set(
            getTripApiErrorMessage(
              error,
              'The trip could not be loaded.'
            )
          );
        }
      });
  }

  public onSubmit(): void {
    this.formError.set('');
    this.isSubmitting.set(true);

    const trip = normalizeTripFormValue(
      this.editForm.getRawValue()
    );

    this.tripDataService
      .updateTrip(
        this.tripCode,
        trip
      )
      .pipe(
        finalize(() => {
          this.isSubmitting.set(false);
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate(['/trips']);
        },

        error: (error: HttpErrorResponse) => {
          this.formError.set(
            getTripApiErrorMessage(
              error,
              'The trip could not be updated. Please try again.'
            )
          );
        }
      });
  }

  public onDelete(): void {
    const confirmed = window.confirm(
      `Delete ${this.tripCode}? This action cannot be undone.`
    );

    if (!confirmed) {
      return;
    }

    this.formError.set('');
    this.isSubmitting.set(true);

    this.tripDataService
      .deleteTrip(this.tripCode)
      .pipe(
        finalize(() => {
          this.isSubmitting.set(false);
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate(['/trips']);
        },

        error: (error: HttpErrorResponse) => {
          this.formError.set(
            getTripApiErrorMessage(
              error,
              'The trip could not be deleted. Please try again.'
            )
          );
        }
      });
  }

  public cancel(): void {
    this.router.navigate(['/trips']);
  }
}