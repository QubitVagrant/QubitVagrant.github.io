import { CommonModule } from '@angular/common';
import {
  Component,
  Input
} from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule
} from '@angular/forms';

import {
  createRoomTypeForm,
  getRoomTypesArray
} from '../../utils/trip-form';

@Component({
  selector: 'app-room-types',
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './room-types.html',
  styleUrl: '../trip-form.css'
})
export class RoomTypes {
  @Input({ required: true })
  public form!: FormGroup;

  @Input()
  public isEditMode = false;

  constructor(
    private readonly formBuilder: FormBuilder
  ) {}

  public get roomTypes(): FormArray {
    return getRoomTypesArray(this.form);
  }

  public addRoomType(): void {
    this.roomTypes.push(
      createRoomTypeForm(this.formBuilder)
    );
  }

  public removeRoomType(index: number): void {
    this.roomTypes.removeAt(index);
    this.roomTypes.markAsDirty();
    this.roomTypes.updateValueAndValidity();
  }

  public isInvalid(controlPath: string): boolean {
    const control = this.form.get(controlPath);

    return Boolean(
      control &&
      control.invalid &&
      (control.touched || control.dirty)
    );
  }

  public hasError(
    controlPath: string,
    errorName: string
  ): boolean {
    const control = this.form.get(controlPath);

    return Boolean(
      control &&
      control.hasError(errorName) &&
      (control.touched || control.dirty)
    );
  }

  public hasArrayError(errorName: string): boolean {
    const array = this.form.get('roomTypes');

    return Boolean(
      array &&
      array.hasError(errorName) &&
      (array.touched || array.dirty)
    );
  }
}