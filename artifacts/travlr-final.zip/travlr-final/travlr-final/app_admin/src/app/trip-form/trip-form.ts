import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';
import {
  FormGroup,
  ReactiveFormsModule
} from '@angular/forms';

import { DiningOptions } from './dining-options/dining-options';
import { RoomTypes } from './room-types/room-types';

export type TripFormMode = 'add' | 'edit';

@Component({
  selector: 'app-trip-form',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RoomTypes,
    DiningOptions
  ],
  templateUrl: './trip-form.html',
  styleUrl: './trip-form.css'
})
export class TripForm {
  @Input({ required: true })
  public form!: FormGroup;

  @Input()
  public mode: TripFormMode = 'add';

  @Input()
  public formError = '';

  @Input()
  public isSubmitting = false;

  @Output()
  public readonly save = new EventEmitter<void>();

  @Output()
  public readonly cancel = new EventEmitter<void>();

  @Output()
  public readonly deleteTrip = new EventEmitter<void>();

  public validationError = '';

  public get isEditMode(): boolean {
    return this.mode === 'edit';
  }

  public isInvalid(controlPath: string): boolean {
    const control = this.form.get(controlPath);

    return Boolean(
      control &&
      control.invalid &&
      (control.touched || control.dirty)
    );
  }

  public hasError(
    controlPath: string,
    errorName: string
  ): boolean {
    const control = this.form.get(controlPath);

    return Boolean(
      control &&
      control.hasError(errorName) &&
      (control.touched || control.dirty)
    );
  }

  public onSubmit(): void {
    this.validationError = '';

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.validationError =
        'Correct the highlighted fields before saving the trip.';
      return;
    }

    this.save.emit();
  }

  public onCancel(): void {
    this.cancel.emit();
  }

  public onDelete(): void {
    this.deleteTrip.emit();
  }
}