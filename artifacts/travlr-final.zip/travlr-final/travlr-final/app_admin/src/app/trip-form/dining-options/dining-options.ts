import { CommonModule } from '@angular/common';
import {
  Component,
  Input
} from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule
} from '@angular/forms';

import {
  createDiningOptionForm,
  getDiningOptionsArray
} from '../../utils/trip-form';

@Component({
  selector: 'app-dining-options',
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './dining-options.html',
  styleUrl: '../trip-form.css'
})
export class DiningOptions {
  @Input({ required: true })
  public form!: FormGroup;

  @Input()
  public isEditMode = false;

  constructor(
    private readonly formBuilder: FormBuilder
  ) {}

  public get diningOptions(): FormArray {
    return getDiningOptionsArray(this.form);
  }

  public addDiningOption(): void {
    this.diningOptions.push(
      createDiningOptionForm(this.formBuilder)
    );
  }

  public removeDiningOption(index: number): void {
    this.diningOptions.removeAt(index);
    this.diningOptions.markAsDirty();
    this.diningOptions.updateValueAndValidity();
  }

  public isInvalid(controlPath: string): boolean {
    const control = this.form.get(controlPath);

    return Boolean(
      control &&
      control.invalid &&
      (control.touched || control.dirty)
    );
  }

  public hasError(
    controlPath: string,
    errorName: string
  ): boolean {
    const control = this.form.get(controlPath);

    return Boolean(
      control &&
      control.hasError(errorName) &&
      (control.touched || control.dirty)
    );
  }

  public hasArrayError(errorName: string): boolean {
    const array = this.form.get('diningOptions');

    return Boolean(
      array &&
      array.hasError(errorName) &&
      (array.touched || array.dirty)
    );
  }
}