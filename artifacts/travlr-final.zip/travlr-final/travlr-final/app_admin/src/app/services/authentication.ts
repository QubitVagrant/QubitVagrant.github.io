import { DOCUMENT } from '@angular/common';

import {
  HttpClient
} from '@angular/common/http';

import {
  inject,
  Injectable,
  signal
} from '@angular/core';

import {
  Router
} from '@angular/router';

import {
  Observable,
  tap
} from 'rxjs';

import { BROWSER_STORAGE } from '../storage';

import {
  User,
  UserRole
} from '../models/user';

import {
  AuthResponse
} from '../models/auth-response';

/*
 * Describes the account information stored inside the JSON Web Token.
 */
interface TokenPayload {
  email: string;
  name?: string;
  role?: UserRole;
  exp: number;
}

@Injectable({
  providedIn: 'root'
})
export class Authentication {
  private readonly apiBaseUrl =
    'http://localhost:3000/api';

  private readonly tokenKey =
    'travlr-token';

  private readonly lastActivityKey =
    'travlr-last-activity';

  /*
   * Administrators are signed out after twenty minutes
   * without browser activity.
   */
  private readonly idleTimeoutMilliseconds =
    20 * 60 * 1000;

  /*
   * Prevents mouse and scroll events from writing to browser
   * storage hundreds of times per second.
   */
  private readonly activityThrottleMilliseconds =
    1000;

  private readonly http =
    inject(HttpClient);

  private readonly storage =
    inject(BROWSER_STORAGE);

  private readonly router =
    inject(Router);

  private readonly document =
    inject(DOCUMENT);

  /*
   * Keeps the saved token in reactive Angular state.
   */
  private readonly tokenState = signal(
    this.storage.getItem(this.tokenKey) || ''
  );

  /*
   * Watches the JWT's absolute server expiration time.
   */
  private expirationTimer:
    ReturnType<typeof setTimeout> |
    null = null;

  /*
   * Watches the administrator's twenty-minute inactivity period.
   */
  private idleTimer:
    ReturnType<typeof setTimeout> |
    null = null;

  private activityWindow:
    Window |
    null = null;

  private lastActivityWrite = 0;

  private readonly activityEvents = [
    'click',
    'keydown',
    'mousemove',
    'scroll',
    'touchstart'
  ];

  private readonly activityHandler:
    EventListener = () => {
      this.handleActivity();
    };

  private readonly visibilityHandler:
    EventListener = () => {
      if (
        this.document.visibilityState ===
        'visible'
      ) {
        this.handleActivity();
      }
    };

  constructor() {
    const token =
      this.tokenState();

    if (!token) {
      return;
    }

    const payload =
      this.decodeToken(token);

    if (
      !payload ||
      payload.exp * 1000 <=
        Date.now()
    ) {
      this.expireSession();
      return;
    }

    const lastActivity =
      this.getLastActivityTime();

    if (
      lastActivity !== null &&
      Date.now() - lastActivity >=
        this.idleTimeoutMilliseconds
    ) {
      this.expireSession();
      return;
    }

    if (
      lastActivity === null
    ) {
      this.recordActivity(
        Date.now()
      );
    }

    this.scheduleTokenExpiration(
      token
    );

    this.startIdleMonitoring();
  }

  /*
   * Stores a new token and begins both expiration timers.
   */
  public saveToken(
    token: string
  ): void {
    this.storage.setItem(
      this.tokenKey,
      token
    );

    this.tokenState.set(
      token
    );

    this.recordActivity(
      Date.now()
    );

    this.scheduleTokenExpiration(
      token
    );

    this.startIdleMonitoring();
  }

  /*
   * Retrieves the current authentication token.
   */
  public getToken(): string {
    return this.tokenState();
  }

  /*
   * Removes the token, activity record, and active timers.
   */
  public logout(): void {
    this.clearExpirationTimer();
    this.stopIdleMonitoring();

    this.storage.removeItem(
      this.tokenKey
    );

    this.storage.removeItem(
      this.lastActivityKey
    );

    this.tokenState.set('');
  }

  /*
   * Ends an expired or inactive session and returns the
   * administrator to the login page.
   */
  private expireSession(): void {
    this.logout();

    if (
      !this.router.url.startsWith(
        '/login'
      )
    ) {
      void this.router.navigate(
        ['/login'],
        {
          queryParams: {
            sessionExpired: 'true'
          }
        }
      );
    }
  }

  /*
   * Decodes the JWT payload.
   */
  private decodeToken(
    token: string
  ): TokenPayload | null {
    try {
      const tokenParts =
        token.split('.');

      if (
        tokenParts.length !== 3
      ) {
        return null;
      }

      const encodedPayload =
        tokenParts[1]
          .replace(/-/g, '+')
          .replace(/_/g, '/');

      const paddedPayload =
        encodedPayload.padEnd(
          Math.ceil(
            encodedPayload.length / 4
          ) * 4,
          '='
        );

      const payload =
        JSON.parse(
          atob(paddedPayload)
        ) as TokenPayload;

      if (
        !Number.isFinite(
          payload.exp
        )
      ) {
        return null;
      }

      return payload;
    } catch {
      return null;
    }
  }

  /*
   * Returns the saved activity timestamp.
   */
  private getLastActivityTime():
    number |
    null {
    const storedValue =
      this.storage.getItem(
        this.lastActivityKey
      );

    if (!storedValue) {
      return null;
    }

    const activityTime =
      Number(storedValue);

    if (
      !Number.isFinite(
        activityTime
      ) ||
      activityTime <= 0
    ) {
      return null;
    }

    return activityTime;
  }

  /*
   * Records recent administrator activity.
   */
  private recordActivity(
    activityTime: number
  ): void {
    this.storage.setItem(
      this.lastActivityKey,
      activityTime.toString()
    );

    this.lastActivityWrite =
      activityTime;
  }

  /*
   * Processes clicks, keyboard input, scrolling, touch activity,
   * and mouse movement.
   */
  private handleActivity(): void {
    if (
      !this.tokenState()
    ) {
      return;
    }

    const currentTime =
      Date.now();

    const previousActivity =
      this.getLastActivityTime();

    /*
     * Activity after the twenty-minute limit does not revive
     * an already expired session.
     */
    if (
      previousActivity !== null &&
      currentTime -
        previousActivity >=
        this.idleTimeoutMilliseconds
    ) {
      this.expireSession();
      return;
    }

    if (
      currentTime -
        this.lastActivityWrite <
        this.activityThrottleMilliseconds
    ) {
      return;
    }

    this.recordActivity(
      currentTime
    );

    this.scheduleIdleTimeout();
  }

  /*
   * Starts listening for meaningful browser activity.
   */
  private startIdleMonitoring(): void {
    this.stopIdleMonitoring();

    if (
      !this.tokenState()
    ) {
      return;
    }

    const lastActivity =
      this.getLastActivityTime();

    if (
      lastActivity !== null &&
      Date.now() - lastActivity >=
        this.idleTimeoutMilliseconds
    ) {
      this.expireSession();
      return;
    }

    if (
      lastActivity === null
    ) {
      this.recordActivity(
        Date.now()
      );
    }

    this.activityWindow =
      this.document.defaultView;

    if (
      this.activityWindow
    ) {
      for (
        const eventName of
        this.activityEvents
      ) {
        this.activityWindow
          .addEventListener(
            eventName,
            this.activityHandler,
            {
              passive: true
            }
          );
      }
    }

    this.document.addEventListener(
      'visibilitychange',
      this.visibilityHandler
    );

    this.scheduleIdleTimeout();
  }

  /*
   * Stops inactivity monitoring and removes browser listeners.
   */
  private stopIdleMonitoring(): void {
    this.clearIdleTimer();

    if (
      this.activityWindow
    ) {
      for (
        const eventName of
        this.activityEvents
      ) {
        this.activityWindow
          .removeEventListener(
            eventName,
            this.activityHandler
          );
      }
    }

    this.document.removeEventListener(
      'visibilitychange',
      this.visibilityHandler
    );

    this.activityWindow =
      null;
  }

  /*
   * Schedules logout based on the most recent activity timestamp.
   */
  private scheduleIdleTimeout(): void {
    this.clearIdleTimer();

    const lastActivity =
      this.getLastActivityTime();

    if (
      lastActivity === null
    ) {
      return;
    }

    const remainingTime =
      this.idleTimeoutMilliseconds -
      (
        Date.now() -
        lastActivity
      );

    if (
      remainingTime <= 0
    ) {
      this.expireSession();
      return;
    }

    this.idleTimer =
      setTimeout(
        () => {
          const latestActivity =
            this.getLastActivityTime();

          if (
            latestActivity === null ||
            Date.now() -
              latestActivity >=
              this.idleTimeoutMilliseconds
          ) {
            this.expireSession();
            return;
          }

          this.scheduleIdleTimeout();
        },
        remainingTime
      );
  }

  /*
   * Cancels the inactivity timer.
   */
  private clearIdleTimer(): void {
    if (
      this.idleTimer !== null
    ) {
      clearTimeout(
        this.idleTimer
      );

      this.idleTimer =
        null;
    }
  }

  /*
   * Schedules automatic logout at the JWT's absolute expiration.
   */
  private scheduleTokenExpiration(
    token: string
  ): void {
    this.clearExpirationTimer();

    if (!token) {
      return;
    }

    const payload =
      this.decodeToken(token);

    if (!payload) {
      this.expireSession();
      return;
    }

    const remainingMilliseconds =
      payload.exp * 1000 -
      Date.now();

    if (
      remainingMilliseconds <= 0
    ) {
      this.expireSession();
      return;
    }

    /*
     * Browser timers cannot safely exceed approximately
     * twenty-four days.
     */
    const maximumTimerDelay =
      2147000000;

    const timerDelay =
      Math.min(
        remainingMilliseconds,
        maximumTimerDelay
      );

    this.expirationTimer =
      setTimeout(
        () => {
          const activeToken =
            this.tokenState();

          if (
            activeToken !== token
          ) {
            return;
          }

          const activePayload =
            this.decodeToken(
              activeToken
            );

          if (
            !activePayload ||
            activePayload.exp * 1000 <=
              Date.now()
          ) {
            this.expireSession();
            return;
          }

          this.scheduleTokenExpiration(
            activeToken
          );
        },
        timerDelay
      );
  }

  /*
   * Cancels the JWT expiration timer.
   */
  private clearExpirationTimer(): void {
    if (
      this.expirationTimer !== null
    ) {
      clearTimeout(
        this.expirationTimer
      );

      this.expirationTimer =
        null;
    }
  }

  /*
   * Confirms that the token is valid and the inactivity
   * limit has not been reached.
   */
  public isLoggedIn(): boolean {
    const token =
      this.tokenState();

    if (!token) {
      return false;
    }

    const payload =
      this.decodeToken(token);

    if (
      !payload ||
      payload.exp * 1000 <=
        Date.now()
    ) {
      this.expireSession();
      return false;
    }

    const lastActivity =
      this.getLastActivityTime();

    if (
      lastActivity !== null &&
      Date.now() - lastActivity >=
        this.idleTimeoutMilliseconds
    ) {
      this.expireSession();
      return false;
    }

    return true;
  }

  /*
   * Returns the account information stored inside the token.
   */
  public getCurrentUser(): User | null {
    if (
      !this.isLoggedIn()
    ) {
      return null;
    }

    const payload =
      this.decodeToken(
        this.tokenState()
      );

    if (!payload) {
      return null;
    }

    return {
      email:
        payload.email,

      name:
        payload.name,

      password:
        '',

      role:
        payload.role
    };
  }

  /*
   * Reports whether the current token belongs to an administrator.
   */
  public isAdmin(): boolean {
    return (
      this.getCurrentUser()?.role ===
      'admin'
    );
  }

  /*
   * Sends credentials to the API and stores the returned token.
   */
  public login(
    user: User
  ): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(
        `${this.apiBaseUrl}/login`,
        user
      )
      .pipe(
        tap(
          (
            authResponse:
              AuthResponse
          ) => {
            this.saveToken(
              authResponse.token
            );
          }
        )
      );
  }

  /*
   * Retains compatibility with existing Angular code.
   */
  public register(
    user: User
  ): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(
        `${this.apiBaseUrl}/register`,
        user
      )
      .pipe(
        tap(
          (
            authResponse:
              AuthResponse
          ) => {
            this.saveToken(
              authResponse.token
            );
          }
        )
      );
  }
}