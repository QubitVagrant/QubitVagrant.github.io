import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

import { Authentication } from '../services/authentication';

/*
 * Protects the Angular administration pages.
 * Logged-out visitors are sent to the login page, while signed-in
 * customers are logged out because they do not have admin permission.
 */
export const adminGuard: CanActivateFn = () => {
  const authenticationService = inject(Authentication);
  const router = inject(Router);

  if (!authenticationService.isLoggedIn()) {
    return router.createUrlTree(['/login']);
  }

  if (!authenticationService.isAdmin()) {
    authenticationService.logout();

    return router.createUrlTree(['/login'], {
      queryParams: {
        error: 'admin-required'
      }
    });
  }

  return true;
};