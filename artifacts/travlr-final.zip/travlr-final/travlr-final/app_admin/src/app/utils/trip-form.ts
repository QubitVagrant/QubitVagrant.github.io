import { HttpErrorResponse } from '@angular/common/http';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators
} from '@angular/forms';

import {
  DiningOption,
  RoomType,
  Trip
} from '../models/trip';

interface TripFormOptions {
  allowPastStartDate?: boolean;
}

interface TripApiErrorBody {
  message?: string;
  fields?: string[];
  errors?: Record<string, string>;
}

const imageFilenamePattern =
  /^[A-Za-z0-9._-]+\.(?:jpg|jpeg|png|webp)$/i;

const itemCodePattern =
  /^[A-Za-z0-9-]{2,20}$/;

const tripCodePattern =
  /^[A-Za-z0-9-]{3,20}$/;

const tripLengthPattern =
  /^\d+\s+nights?\s*\/\s*\d+\s+days?$/i;

const validDateValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
  if (!control.value) {
    return null;
  }

  const date = new Date(
    String(control.value)
  );

  return Number.isNaN(date.getTime())
    ? { invalidDate: true }
    : null;
};

const todayOrFutureValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
  if (!control.value) {
    return null;
  }

  const selectedDate =
    String(control.value).substring(0, 10);

  const today = new Date();

  const currentDate = [
    today.getFullYear(),
    String(today.getMonth() + 1).padStart(2, '0'),
    String(today.getDate()).padStart(2, '0')
  ].join('-');

  return selectedDate < currentDate
    ? { pastDate: true }
    : null;
};

const integerValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
  if (
    control.value === null ||
    control.value === undefined ||
    control.value === ''
  ) {
    return null;
  }

  return Number.isInteger(
    Number(control.value)
  )
    ? null
    : { integer: true };
};

const uniqueItemCodesValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
  if (!(control instanceof FormArray)) {
    return null;
  }

  const codes = control.controls
    .map((itemControl) =>
      String(
        itemControl.get('code')?.value || ''
      )
        .trim()
        .toUpperCase()
    )
    .filter(Boolean);

  return new Set(codes).size === codes.length
    ? null
    : { duplicateCodes: true };
};

export const createRoomTypeForm = (
  formBuilder: FormBuilder,
  room?: Partial<RoomType>
): FormGroup => {
  return formBuilder.group({
    code: [
      room?.code || '',
      [
        Validators.required,
        Validators.pattern(itemCodePattern)
      ]
    ],

    name: [
      room?.name || '',
      [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(80)
      ]
    ],

    description: [
      room?.description || '',
      [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(500)
      ]
    ],

    image: [
      room?.image || '',
      [
        Validators.required,
        Validators.maxLength(120),
        Validators.pattern(imageFilenamePattern)
      ]
    ],

    nightlyRate: [
      room?.nightlyRate ?? '',
      [
        Validators.required,
        Validators.min(0)
      ]
    ],

    maxGuests: [
      room?.maxGuests ?? '',
      [
        Validators.required,
        Validators.min(1),
        integerValidator
      ]
    ],

    availableUnits: [
      room?.availableUnits ?? '',
      [
        Validators.required,
        Validators.min(0),
        integerValidator
      ]
    ]
  });
};

export const createDiningOptionForm = (
  formBuilder: FormBuilder,
  diningOption?: Partial<DiningOption>
): FormGroup => {
  return formBuilder.group({
    code: [
      diningOption?.code || '',
      [
        Validators.required,
        Validators.pattern(itemCodePattern)
      ]
    ],

    name: [
      diningOption?.name || '',
      [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(80)
      ]
    ],

    restaurantName: [
      diningOption?.restaurantName || '',
      [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(120)
      ]
    ],

    description: [
      diningOption?.description || '',
      [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(500)
      ]
    ],

    pricePerPerson: [
      diningOption?.pricePerPerson ?? '',
      [
        Validators.required,
        Validators.min(0)
      ]
    ],

    included: [
      diningOption?.included ?? false
    ]
  });
};

export const createTripForm = (
  formBuilder: FormBuilder,
  options: TripFormOptions = {}
): FormGroup => {
  const startValidators: ValidatorFn[] = [
    Validators.required,
    validDateValidator
  ];

  if (!options.allowPastStartDate) {
    startValidators.push(
      todayOrFutureValidator
    );
  }

  return formBuilder.group({
    code: [
      '',
      [
        Validators.required,
        Validators.maxLength(20),
        Validators.pattern(tripCodePattern)
      ]
    ],

    name: [
      '',
      [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(80)
      ]
    ],

    length: [
      '',
      [
        Validators.required,
        Validators.maxLength(40),
        Validators.pattern(tripLengthPattern)
      ]
    ],

    start: [
      '',
      startValidators
    ],

    resort: [
      '',
      [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(120)
      ]
    ],

    location: formBuilder.group({
      city: [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(80)
        ]
      ],

      stateOrRegion: [
        '',
        [
          Validators.maxLength(80)
        ]
      ],

      country: [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(80)
        ]
      ]
    }),

    perPerson: [
      '',
      [
        Validators.required,
        Validators.min(0)
      ]
    ],

    image: [
      '',
      [
        Validators.required,
        Validators.maxLength(120),
        Validators.pattern(imageFilenamePattern)
      ]
    ],

    gallery: [
      ''
    ],

    description: [
      '',
      [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(1000)
      ]
    ],

    details: [
      '',
      [
        Validators.required,
        Validators.minLength(20),
        Validators.maxLength(5000)
      ]
    ],

    roomTypes: formBuilder.array(
      [],
      {
        validators: [
          uniqueItemCodesValidator
        ]
      }
    ),

    diningOptions: formBuilder.array(
      [],
      {
        validators: [
          uniqueItemCodesValidator
        ]
      }
    )
  });
};

export const getRoomTypesArray = (
  form: FormGroup
): FormArray => {
  return form.get('roomTypes') as FormArray;
};

export const getDiningOptionsArray = (
  form: FormGroup
): FormArray => {
  return form.get('diningOptions') as FormArray;
};

export const populateTripForm = (
  formBuilder: FormBuilder,
  form: FormGroup,
  trip: Trip
): void => {
  form.patchValue({
    code: trip.code,
    name: trip.name,
    length: trip.length,

    start: String(
      trip.start || ''
    ).substring(0, 10),

    resort: trip.resort,

    location: {
      city:
        trip.location?.city || '',

      stateOrRegion:
        trip.location?.stateOrRegion || '',

      country:
        trip.location?.country || ''
    },

    perPerson: trip.perPerson,
    image: trip.image,

    gallery:
      Array.isArray(trip.gallery)
        ? trip.gallery.join('\n')
        : '',

    description:
      trip.description,

    details:
      trip.details || ''
  });

  const roomTypes =
    getRoomTypesArray(form);

  roomTypes.clear();

  for (const room of trip.roomTypes || []) {
    roomTypes.push(
      createRoomTypeForm(
        formBuilder,
        room
      )
    );
  }

  const diningOptions =
    getDiningOptionsArray(form);

  diningOptions.clear();

  for (
    const option of
    trip.diningOptions || []
  ) {
    diningOptions.push(
      createDiningOptionForm(
        formBuilder,
        option
      )
    );
  }
};

const asRecord = (
  value: unknown
): Record<string, unknown> => {
  if (
    typeof value === 'object' &&
    value !== null &&
    !Array.isArray(value)
  ) {
    return value as Record<string, unknown>;
  }

  return {};
};

const toText = (
  value: unknown
): string => {
  return String(
    value ?? ''
  ).trim();
};

const toCode = (
  value: unknown
): string => {
  return toText(value).toUpperCase();
};

const toNumber = (
  value: unknown
): number => {
  const numericValue =
    Number(value);

  return Number.isFinite(numericValue)
    ? numericValue
    : 0;
};

const normalizeRoomType = (
  value: unknown
): RoomType => {
  const room =
    asRecord(value);

  return {
    code:
      toCode(room['code']),

    name:
      toText(room['name']),

    description:
      toText(room['description']),

    image:
      toText(room['image']),

    nightlyRate:
      toNumber(room['nightlyRate']),

    maxGuests:
      toNumber(room['maxGuests']),

    availableUnits:
      toNumber(room['availableUnits'])
  };
};

const normalizeDiningOption = (
  value: unknown
): DiningOption => {
  const dining =
    asRecord(value);

  return {
    code:
      toCode(dining['code']),

    name:
      toText(dining['name']),

    restaurantName:
      toText(
        dining['restaurantName']
      ),

    description:
      toText(
        dining['description']
      ),

    pricePerPerson:
      toNumber(
        dining['pricePerPerson']
      ),

    included:
      Boolean(
        dining['included']
      )
  };
};

export const normalizeTripFormValue = (
  value: Record<string, unknown>
): Trip => {
  const location =
    asRecord(value['location']);

  const roomTypes =
    Array.isArray(value['roomTypes'])
      ? value['roomTypes']
      : [];

  const diningOptions =
    Array.isArray(value['diningOptions'])
      ? value['diningOptions']
      : [];

  const gallery =
    toText(value['gallery'])
      .split(/\r?\n|,/)
      .map((image) => image.trim())
      .filter(Boolean);

  return {
    code:
      toCode(value['code']),

    name:
      toText(value['name']),

    length:
      toText(value['length']),

    start:
      toText(value['start']),

    resort:
      toText(value['resort']),

    location: {
      city:
        toText(location['city']),

      stateOrRegion:
        toText(
          location['stateOrRegion']
        ),

      country:
        toText(location['country'])
    },

    perPerson:
      toNumber(value['perPerson']),

    image:
      toText(value['image']),

    gallery,

    description:
      toText(value['description']),

    details:
      toText(value['details']),

    roomTypes:
      roomTypes.map(
        normalizeRoomType
      ),

    diningOptions:
      diningOptions.map(
        normalizeDiningOption
      )
  };
};

export const getTripApiErrorMessage = (
  error: HttpErrorResponse,
  fallbackMessage: string
): string => {
  const response =
    error.error as
      | TripApiErrorBody
      | string
      | null;

  if (
    typeof response === 'string' &&
    response.trim()
  ) {
    return response;
  }

  if (
    response &&
    typeof response === 'object'
  ) {
    if (response.errors) {
      const details =
        Object.values(
          response.errors
        );

      if (details.length > 0) {
        return details.join(' ');
      }
    }

    if (response.message) {
      if (
        response.fields &&
        response.fields.length > 0
      ) {
        return (
          `${response.message} ` +
          `Fields: ${response.fields.join(', ')}.`
        );
      }

      return response.message;
    }
  }

  if (error.status === 0) {
    return (
      'The API is unavailable. ' +
      'Confirm the Express server is running.'
    );
  }

  if (error.status === 401) {
    return (
      'Your session has expired. Sign in again.'
    );
  }

  if (error.status === 403) {
    return (
      'Administrator access is required.'
    );
  }

  return fallbackMessage;
};