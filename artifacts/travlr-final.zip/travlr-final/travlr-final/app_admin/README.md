# Travlr Getaways Admin

This directory contains the Angular administrative application for Travlr Getaways.

Administrators can use this interface to manage trip packages and travel blog articles.

## Development

Install dependencies:

npm install

Start the development server:

npm start

Run unit tests:

npm test -- --watch=false

Create a production build:

npm run build