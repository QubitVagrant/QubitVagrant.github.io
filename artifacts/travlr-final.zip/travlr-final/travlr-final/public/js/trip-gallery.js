(function () {
    'use strict';

    const gallery =
        document.querySelector('[data-trip-gallery]');

    if (!gallery) {
        return;
    }

    const mainImage =
        gallery.querySelector('[data-gallery-main]');

    const previousButton =
        gallery.querySelector('[data-gallery-previous]');

    const nextButton =
        gallery.querySelector('[data-gallery-next]');

    const thumbnailContainer =
        gallery.querySelector('[data-gallery-thumbnails]');

    if (!mainImage || !thumbnailContainer) {
        return;
    }

    const originalThumbnails =
        Array.from(
            gallery.querySelectorAll(
                '[data-gallery-thumbnail]'
            )
        );

    const seenSources = new Set();

    const thumbnails =
        originalThumbnails.filter((thumbnail) => {
            const source =
                String(
                    thumbnail.dataset.gallerySrc || ''
                ).trim();

            if (!source || seenSources.has(source)) {
                thumbnail.remove();
                return false;
            }

            seenSources.add(source);
            return true;
        });

    if (thumbnails.length === 0) {
        return;
    }

    if (thumbnails.length === 1) {
        gallery.classList.add(
            'is-single-image'
        );
    }

    let currentIndex = 0;

    const showImage = (index) => {
        if (
            index < 0 ||
            index >= thumbnails.length
        ) {
            return;
        }

        currentIndex = index;

        const selectedThumbnail =
            thumbnails[currentIndex];

        const source =
            selectedThumbnail.dataset.gallerySrc;

        const altText =
            selectedThumbnail.dataset.galleryAlt ||
            mainImage.alt;

        if (source) {
            mainImage.src = source;
        }

        mainImage.alt = altText;

        thumbnails.forEach(
            (thumbnail, thumbnailIndex) => {
                const isActive =
                    thumbnailIndex === currentIndex;

                thumbnail.classList.toggle(
                    'is-active',
                    isActive
                );

                thumbnail.setAttribute(
                    'aria-pressed',
                    isActive ? 'true' : 'false'
                );
            }
        );

        selectedThumbnail.scrollIntoView({
            behavior: 'smooth',
            block: 'nearest',
            inline: 'nearest'
        });
    };

    const showPrevious = () => {
        const nextIndex =
            currentIndex === 0
                ? thumbnails.length - 1
                : currentIndex - 1;

        showImage(nextIndex);
    };

    const showNext = () => {
        const nextIndex =
            currentIndex === thumbnails.length - 1
                ? 0
                : currentIndex + 1;

        showImage(nextIndex);
    };

    thumbnails.forEach(
        (thumbnail, index) => {
            thumbnail.addEventListener(
                'click',
                () => {
                    showImage(index);
                }
            );
        }
    );

    if (previousButton) {
        previousButton.addEventListener(
            'click',
            showPrevious
        );
    }

    if (nextButton) {
        nextButton.addEventListener(
            'click',
            showNext
        );
    }

    gallery.addEventListener(
        'keydown',
        (event) => {
            if (event.key === 'ArrowLeft') {
                event.preventDefault();
                showPrevious();
            }

            if (event.key === 'ArrowRight') {
                event.preventDefault();
                showNext();
            }
        }
    );

    showImage(0);
})();
