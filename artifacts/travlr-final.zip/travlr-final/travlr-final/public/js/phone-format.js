(() => {
  const phoneInput =
    document.getElementById('phone');

  if (!phoneInput) {
    return;
  }

  const formatPhone = (value) => {
    const trimmed = value.trim();

    // Leave international numbers alone.
    if (trimmed.startsWith('+')) {
      return value;
    }

    const digits =
      value.replace(/\D/g, '');

    if (digits.length === 0) {
      return '';
    }

    if (digits.length <= 3) {
      return digits;
    }

    if (digits.length <= 6) {
      return `(${digits.slice(0, 3)}) ${digits.slice(3)}`;
    }

    if (digits.length <= 10) {
      return (
        `(${digits.slice(0, 3)}) ` +
        `${digits.slice(3, 6)}-` +
        `${digits.slice(6)}`
      );
    }

    return value;
  };

  phoneInput.value =
    formatPhone(phoneInput.value);

  phoneInput.addEventListener(
    'input',
    () => {
      phoneInput.value =
        formatPhone(phoneInput.value);
    }
  );
})();
