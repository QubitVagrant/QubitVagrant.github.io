(function () {
			'use strict';

			const form =
				document.getElementById('bookingForm');

			const travelerInput =
				document.getElementById('travelerCount');

			const submitButton =
				document.getElementById('bookingSubmit');

			const roomAvailabilityMessage =
				document.getElementById(
					'bookingRoomAvailabilityMessage'
				);

			if (!form || !travelerInput) {
				return;
			}

			const baseOutput =
				document.getElementById('bookingEstimateBase');

			const roomOutput =
				document.getElementById('bookingEstimateRoom');

			const roomQuantityOutput =
				document.getElementById(
					'bookingEstimateRoomQuantity'
				);

			const diningOutput =
				document.getElementById('bookingEstimateDining');

			const totalOutput =
				document.getElementById('bookingEstimateTotal');

			const currencyFormatter =
				new Intl.NumberFormat('en-US', {
					style: 'currency',
					currency: 'USD'
				});

			const toNumber = (value) => {
				const parsedValue =
					Number.parseFloat(value);

				return Number.isFinite(parsedValue)
					? parsedValue
					: 0;
			};

			const getNightCount = () => {
				const tripLength =
					String(
						form.dataset.tripLength || ''
					);

				const match =
					tripLength.match(
						/(\d+)\s+nights?/i
					);

				if (!match) {
					return 0;
				}

				const nightCount =
					Number.parseInt(
						match[1],
						10
					);

				return Number.isInteger(nightCount)
					? nightCount
					: 0;
			};

			const getTravelerCount = () => {
				const parsedCount =
					Number.parseInt(
						travelerInput.value,
						10
					);

				if (!Number.isInteger(parsedCount)) {
					return 1;
				}

				return Math.min(
					12,
					Math.max(1, parsedCount)
				);
			};

			const calculateEstimate = () => {
				const travelerCount =
					getTravelerCount();

				const tripPrice =
					toNumber(
						form.dataset.tripPrice
					);

				const nightCount =
					getNightCount();

				const selectedRoom =
					form.querySelector(
						'input[name="roomCode"]:checked'
					);

				const selectedDining =
					form.querySelector(
						'input[name="diningCodes"]:checked'
					);

				const baseTripTotal =
					tripPrice *
					travelerCount;

				let roomQuantity = 0;
				let roomUpgradeTotal = 0;
				let hasEnoughRooms = true;
				let availableRooms = 0;

				if (selectedRoom) {
					const nightlyRate =
						toNumber(
							selectedRoom.dataset.nightlyRate
						);

					const maximumGuests =
						Math.max(
							1,
							Number.parseInt(
								selectedRoom.dataset.maxGuests,
								10
							) || 1
						);

					availableRooms =
						Math.max(
							0,
							Number.parseInt(
								selectedRoom.dataset.availableUnits,
								10
							) || 0
						);

					roomQuantity =
						Math.ceil(
							travelerCount /
							maximumGuests
						);

					hasEnoughRooms =
						roomQuantity <=
						availableRooms;

					roomUpgradeTotal =
						nightlyRate *
						nightCount *
						roomQuantity;
				}

				form.dataset.roomInventoryValid =
					hasEnoughRooms
						? 'true'
						: 'false';

				if (roomAvailabilityMessage) {
					if (
						selectedRoom &&
						!hasEnoughRooms
					) {
						const roomWord =
							availableRooms === 1
								? 'room'
								: 'rooms';

						roomAvailabilityMessage.textContent =
							`This room type has only ` +
							`${availableRooms} ${roomWord} available. ` +
							`Choose another room type or reduce the ` +
							`number of travelers.`;

						roomAvailabilityMessage.hidden =
							false;
					} else {
						roomAvailabilityMessage.textContent =
							'';

						roomAvailabilityMessage.hidden =
							true;
					}
				}

				if (
					submitButton &&
					form.dataset.submitting !== 'true'
				) {
					submitButton.disabled =
						!hasEnoughRooms;
				}

				const includedDiningInputs =
					Array.from(
						form.querySelectorAll(
							'input[name="diningCodes"][data-included="true"]'
						)
					);

				const includedDiningTotal =
					includedDiningInputs.reduce(
						(total, option) => {
							return (
								total +
								toNumber(
									option.dataset.pricePerPerson
								) *
								travelerCount
							);
						},
						0
					);

				let diningTotal =
					includedDiningTotal;

				if (
					selectedDining &&
					selectedDining.dataset.included !== 'true'
				) {
					diningTotal +=
						toNumber(
							selectedDining.dataset.pricePerPerson
						) *
						travelerCount;
				}

				const estimatedTotal =
					baseTripTotal +
					roomUpgradeTotal +
					diningTotal;

				if (baseOutput) {
					baseOutput.textContent =
						currencyFormatter.format(
							baseTripTotal
						);
				}

				if (roomOutput) {
					roomOutput.textContent =
						currencyFormatter.format(
							roomUpgradeTotal
						);
				}

				if (roomQuantityOutput) {
					roomQuantityOutput.textContent =
						String(roomQuantity);
				}

				if (diningOutput) {
					diningOutput.textContent =
						currencyFormatter.format(
							diningTotal
						);
				}

				if (totalOutput) {
					totalOutput.textContent =
						currencyFormatter.format(
							estimatedTotal
						);
				}
			};

			travelerInput.addEventListener(
				'input',
				calculateEstimate
			);

			form
				.querySelectorAll(
					'input[name="roomCode"], input[name="diningCodes"]'
				)
				.forEach((input) => {
					input.addEventListener(
						'change',
						calculateEstimate
					);
				});

			form.addEventListener(
				'submit',
				(event) => {
					calculateEstimate();

					if (
						form.dataset.roomInventoryValid ===
						'false'
					) {
						event.preventDefault();

						if (roomAvailabilityMessage) {
							roomAvailabilityMessage.focus();
						}

						return;
					}

					if (
						form.dataset.submitting === 'true'
					) {
						event.preventDefault();
						return;
					}

					form.dataset.submitting = 'true';

					if (submitButton) {
						submitButton.disabled = true;
						submitButton.textContent =
							'Booking...';
					}
				}
			);

			calculateEstimate();
		})();
