(function () {
    'use strict';

    const gallery =
        document.querySelector('[data-trip-gallery]');

    if (!gallery) {
        return;
    }

    const mainImage =
        gallery.querySelector('[data-gallery-main]');

    if (!mainImage) {
        return;
    }

    const thumbnailButtons =
        Array.from(
            gallery.querySelectorAll(
                '[data-gallery-thumbnail]'
            )
        );

    const overlay =
        document.createElement('div');

    overlay.className = 'trip-lightbox';
    overlay.hidden = true;
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute(
        'aria-label',
        'Trip photo viewer'
    );

    overlay.innerHTML = `
        <button
            class="trip-lightbox-close"
            type="button"
            aria-label="Close photo viewer"
        >
            &times;
        </button>

        <button
            class="trip-lightbox-nav trip-lightbox-previous"
            type="button"
            aria-label="Previous photo"
        >
            &#8249;
        </button>

        <img
            class="trip-lightbox-image"
            src=""
            alt=""
        >

        <button
            class="trip-lightbox-nav trip-lightbox-next"
            type="button"
            aria-label="Next photo"
        >
            &#8250;
        </button>
    `;

    document.body.appendChild(overlay);

    const lightboxImage =
        overlay.querySelector('.trip-lightbox-image');

    const closeButton =
        overlay.querySelector('.trip-lightbox-close');

    const previousButton =
        overlay.querySelector('.trip-lightbox-previous');

    const nextButton =
        overlay.querySelector('.trip-lightbox-next');

    let images = [];
    let currentIndex = 0;
    let previousFocus = null;

    const getImages = () => {
        const result = [];
        const seen = new Set();

        const addImage = (src, alt) => {
            if (!src || seen.has(src)) {
                return;
            }

            seen.add(src);

            result.push({
                src,
                alt:
                    alt ||
                    mainImage.alt ||
                    'Trip photo'
            });
        };

        addImage(
            mainImage.getAttribute('src'),
            mainImage.getAttribute('alt')
        );

        thumbnailButtons.forEach((button) => {
            addImage(
                button.dataset.gallerySrc,
                button.dataset.galleryAlt
            );
        });

        return result;
    };

    const showImage = (index) => {
        if (!images.length) {
            return;
        }

        currentIndex =
            (index + images.length) %
            images.length;

        const image =
            images[currentIndex];

        lightboxImage.src =
            image.src;

        lightboxImage.alt =
            image.alt;

        const hasMultipleImages =
            images.length > 1;

        previousButton.hidden =
            !hasMultipleImages;

        nextButton.hidden =
            !hasMultipleImages;
    };

    const openLightbox = () => {
        images = getImages();

        if (!images.length) {
            return;
        }

        const currentSrc =
            mainImage.getAttribute('src');

        const matchingIndex =
            images.findIndex(
                (image) =>
                    image.src === currentSrc
            );

        currentIndex =
            matchingIndex >= 0
                ? matchingIndex
                : 0;

        previousFocus =
            document.activeElement;

        showImage(currentIndex);

        overlay.hidden = false;

        document.body.classList.add(
            'trip-lightbox-open'
        );

        closeButton.focus();
    };

    const closeLightbox = () => {
        if (overlay.hidden) {
            return;
        }

        overlay.hidden = true;

        document.body.classList.remove(
            'trip-lightbox-open'
        );

        if (
            previousFocus &&
            typeof previousFocus.focus ===
                'function'
        ) {
            previousFocus.focus();
        }
    };

    mainImage.setAttribute(
        'tabindex',
        '0'
    );

    mainImage.setAttribute(
        'role',
        'button'
    );

    mainImage.setAttribute(
        'aria-label',
        'Open trip photo in full screen'
    );

    mainImage.addEventListener(
        'click',
        openLightbox
    );

    mainImage.addEventListener(
        'keydown',
        (event) => {
            if (
                event.key === 'Enter' ||
                event.key === ' '
            ) {
                event.preventDefault();
                event.stopPropagation();
                openLightbox();
            }
        }
    );

    closeButton.addEventListener(
        'click',
        closeLightbox
    );

    previousButton.addEventListener(
        'click',
        () => {
            showImage(
                currentIndex - 1
            );
        }
    );

    nextButton.addEventListener(
        'click',
        () => {
            showImage(
                currentIndex + 1
            );
        }
    );

    overlay.addEventListener(
        'click',
        (event) => {
            if (event.target === overlay) {
                closeLightbox();
            }
        }
    );

    document.addEventListener(
        'keydown',
        (event) => {
            if (overlay.hidden) {
                return;
            }

            if (event.key === 'Escape') {
                closeLightbox();
                return;
            }

            if (event.key === 'ArrowLeft') {
                event.preventDefault();

                showImage(
                    currentIndex - 1
                );
            }

            if (event.key === 'ArrowRight') {
                event.preventDefault();

                showImage(
                    currentIndex + 1
                );
            }
        }
    );
})();