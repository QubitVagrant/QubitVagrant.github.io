# Travlr Getaways

Travlr Getaways is a full-stack MEAN travel booking application enhanced for the CS-499 Computer Science Capstone.

The application includes a public travel site, customer accounts and bookings, a REST API backed by MongoDB, and an Angular administrative interface for managing trips and travel articles.

## Technologies

- MongoDB and Mongoose
- Express.js
- Angular
- Node.js
- Handlebars
- Bootstrap
- JSON Web Tokens

## Project Structure

- `app_api` - REST API, MongoDB models, controllers, validation, and seed data
- `app_server` - Express routes, controllers, and Handlebars views
- `app_admin` - Angular administrative application
- `public` - Public stylesheets, JavaScript, and images

## Key Features

- Trip browsing and detailed package information
- Customer registration, authentication, and account management
- Trip booking with room and dining selections
- Server-side pricing and inventory management
- Booking history and cancellation support
- Trip recommendations based on customer preferences
- Administrative trip and travel article management
- Published travel blog articles

## Testing

Angular unit tests can be run from the `app_admin` directory with:

npm test -- --watch=false

A production Angular build can be created with:

npm run build