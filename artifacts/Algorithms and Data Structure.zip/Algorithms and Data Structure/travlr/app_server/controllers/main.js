/* GET home page */
const index = (req, res) => {
  res.render('index', {
    title: 'Travlr Getaways',
    navHome: true
  });
};

/* GET travel blog page */
const news = (req, res) => {
  res.render('news', {
    title: 'Travel Blog',
    navNews: true
  });
};

/* GET combined about and contact page */
const about = (req, res) => {
  res.render('about', {
    title: 'About',
    navAbout: true
  });
};

module.exports = {
  index,
  news,
  about
};