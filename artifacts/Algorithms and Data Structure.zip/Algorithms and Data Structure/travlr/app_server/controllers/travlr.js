/* GET travel page using API */
const apiOptions = {
  server: 'http://localhost:3000'
};

/*
 * Formats a trip date for customer-facing display.
 */
const formatTripDate = (value) => {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return '';
  }

  return date.toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC'
  });
};

/*
 * Adds a readable start date to each trip without changing
 * the original start value used by the algorithm and HTML.
 */
const addFormattedDates = (trips = []) => (
  trips.map((trip) => ({
    ...trip,
    formattedStart: formatTripDate(trip.start)
  }))
);

/*
 * Adds a readable start date to each ranked recommendation.
 */
const addFormattedRecommendationDates = (
  recommendations = []
) => (
  recommendations.map((result) => ({
    ...result,
    trip: {
      ...result.trip,
      formattedStart: formatTripDate(
        result.trip.start
      )
    }
  }))
);

/*
 * Renders the public travel page with either the full trip list
 * or ranked recommendation results.
 */
const renderTravelPage = (
  req,
  res,
  trips,
  options = {}
) => {
  res.render('travel', {
    title: 'Travlr Getaways',
    trips,
    recommendations:
      options.recommendations || [],
    hasRecommendations:
      options.recommendations?.length > 0,
    recommendationAttempted:
      options.recommendationAttempted || false,
    recommendationError:
      options.recommendationError || null,
    preferences:
      options.preferences || {}
  });
};

/*
 * Checks whether the customer supplied at least one recommendation
 * preference through the Travel page form.
 */
const hasRecommendationPreferences = (
  preferences
) => Object.values(preferences).some(
  (value) => (
    value !== undefined &&
    value !== null &&
    String(value).trim() !== ''
  )
);

/*
 * GET travel page.
 *
 * Without preferences, the page displays every trip. When preferences
 * are provided, the API scores and ranks the available trips.
 */
const travel = async (req, res) => {
  const preferences = {
    maximumPrice:
      req.query.maximumPrice || '',
    resort:
      req.query.resort || '',
    startDate:
      req.query.startDate || '',
    length:
      req.query.length || ''
  };

  try {
    const tripsResponse = await fetch(
      `${apiOptions.server}/api/trips`
    );

    const tripData =
      await tripsResponse.json();

    if (!tripsResponse.ok) {
      return res
        .status(tripsResponse.status)
        .render(
          'error',
          {
            message:
              tripData.message ||
              'API lookup error',
            error: {}
          }
        );
    }

    const trips = addFormattedDates(
      tripData
    );

    if (
      !hasRecommendationPreferences(
        preferences
      )
    ) {
      return renderTravelPage(
        req,
        res,
        trips,
        {
          preferences
        }
      );
    }

    const query =
      new URLSearchParams();

    Object.entries(preferences).forEach(
      ([key, value]) => {
        if (
          String(value).trim() !== ''
        ) {
          query.set(key, value);
        }
      }
    );

    const recommendationResponse =
      await fetch(
        `${apiOptions.server}/api/trips/recommendations?${query.toString()}`
      );

    const recommendationData =
      await recommendationResponse.json();

    if (!recommendationResponse.ok) {
      return renderTravelPage(
        req,
        res,
        trips,
        {
          preferences,
          recommendationAttempted: true,
          recommendationError:
            recommendationData.message ||
            'Unable to generate recommendations.'
        }
      );
    }

    const recommendations =
      addFormattedRecommendationDates(
        recommendationData.recommendations
      );

    return renderTravelPage(
      req,
      res,
      trips,
      {
        preferences,
        recommendationAttempted: true,
        recommendations
      }
    );
  } catch (error) {
    return res.status(500).render(
      'error',
      {
        message: 'API lookup error',
        error
      }
    );
  }
};

module.exports = {
  travel
};