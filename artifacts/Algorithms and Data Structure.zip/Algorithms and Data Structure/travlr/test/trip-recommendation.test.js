const assert = require('node:assert/strict');

const {
  parsePrice,
  parseLength,
  parseDate,
  scoreTrip,
  rankTrips
} = require('../app_api/utils/trip-recommendation');

const trips = [
  {
    code: 'GALR210214',
    name: 'Gale Reef',
    resort: 'Emerald Bay, 3 stars',
    perPerson: '799.00',
    start: '2026-02-14',
    length: '3 nights / 4 days'
  },
  {
    code: 'DAWR210315',
    name: "Dawson's Reef",
    resort: 'Blue Lagoon, 4 stars',
    perPerson: '1199.00',
    start: '2026-03-15',
    length: '4 nights / 5 days'
  },
  {
    code: 'CLAR210621',
    name: "Claire's Reef",
    resort: 'Coral Sands, 5 stars',
    perPerson: '1999.00',
    start: '2026-06-21',
    length: '7 nights / 8 days'
  }
];

/*
 * Price parsing tests.
 */
assert.equal(parsePrice('$1,299.00'), 1299);
assert.equal(parsePrice('799.00'), 799);
assert.equal(parsePrice(1200), 1200);
assert.equal(parsePrice('invalid'), null);
assert.equal(parsePrice(''), null);

/*
 * Trip-length parsing tests.
 */
assert.equal(
  parseLength('4 nights / 5 days'),
  4
);

assert.equal(parseLength('7 nights'), 7);
assert.equal(parseLength(3), 3);
assert.equal(parseLength('unknown'), null);
assert.equal(parseLength(''), null);

/*
 * Date parsing tests.
 */
assert.ok(
  parseDate('2026-03-15') instanceof Date
);

assert.equal(
  parseDate('invalid date'),
  null
);

assert.equal(parseDate(''), null);

/*
 * A trip matching every preference should receive 100 points.
 */
const exactMatchResults = rankTrips(
  trips,
  {
    maximumPrice: 1200,
    resort: 'Dawson',
    startDate: '2026-03-12',
    length: 4
  }
);

assert.equal(
  exactMatchResults[0].trip.code,
  'DAWR210315'
);

assert.equal(
  exactMatchResults[0].score,
  100
);

assert.deepEqual(
  exactMatchResults[0].matchReasons,
  [
    'Within the selected budget',
    'Matches the trip or resort name',
    'Starts within 7 days of the preferred date',
    'Matches the preferred trip length'
  ]
);

/*
 * Date scoring should award 20 points within 7 days
 * and 10 points within 30 days.
 */
const dateResults = rankTrips(
  trips,
  {
    startDate: '2026-03-12'
  }
);

assert.equal(
  dateResults[0].trip.code,
  'DAWR210315'
);

assert.equal(
  dateResults[0].score,
  20
);

assert.equal(
  dateResults[1].trip.code,
  'GALR210214'
);

assert.equal(
  dateResults[1].score,
  10
);

/*
 * Trip-name matching should be case-insensitive.
 */
const tripNameResults = rankTrips(
  trips,
  {
    resort: 'gale reef'
  }
);

assert.equal(
  tripNameResults[0].trip.code,
  'GALR210214'
);

assert.equal(
  tripNameResults[0].score,
  30
);

/*
 * Resort-name matching should also be case-insensitive.
 */
const resortNameResults = rankTrips(
  trips,
  {
    resort: 'blue lagoon'
  }
);

assert.equal(
  resortNameResults[0].trip.code,
  'DAWR210315'
);

assert.equal(
  resortNameResults[0].score,
  30
);

/*
 * Only an exact trip-length match should receive 15 points.
 */
const lengthResults = rankTrips(
  trips,
  {
    length: 4
  }
);

assert.equal(
  lengthResults[0].trip.code,
  'DAWR210315'
);

assert.equal(
  lengthResults[0].score,
  15
);

assert.equal(
  lengthResults[1].score,
  0
);

assert.equal(
  lengthResults[2].score,
  0
);

/*
 * Budget matches should receive 35 points.
 */
const budgetResults = rankTrips(
  trips,
  {
    maximumPrice: 800
  }
);

assert.equal(
  budgetResults[0].trip.code,
  'GALR210214'
);

assert.equal(
  budgetResults[0].score,
  35
);

assert.equal(
  budgetResults[1].score,
  0
);

/*
 * scoreTrip should return zero when no preference matches.
 */
const noMatchResult = scoreTrip(
  trips[0],
  {
    maximumPrice: 100,
    resort: 'different resort',
    startDate: parseDate('2027-12-31'),
    length: 10
  }
);

assert.equal(
  noMatchResult.score,
  0
);

assert.deepEqual(
  noMatchResult.matchReasons,
  []
);

/*
 * Equal scores should use lower price as the first tie-breaker.
 */
const priceTieTrips = [
  {
    code: 'HIGH-PRICE',
    name: 'Higher Price Trip',
    resort: 'Test Resort',
    perPerson: '1500.00',
    start: '2026-07-01',
    length: '4 nights'
  },
  {
    code: 'LOW-PRICE',
    name: 'Lower Price Trip',
    resort: 'Test Resort',
    perPerson: '900.00',
    start: '2026-08-01',
    length: '4 nights'
  }
];

const priceTieResults = rankTrips(
  priceTieTrips,
  {
    length: 4
  }
);

assert.equal(
  priceTieResults[0].trip.code,
  'LOW-PRICE'
);

/*
 * Equal scores and equal prices should use earlier date.
 */
const dateTieTrips = [
  {
    code: 'LATE-TRIP',
    name: 'Late Trip',
    resort: 'Test Resort',
    perPerson: '1000.00',
    start: '2026-08-01',
    length: '4 nights'
  },
  {
    code: 'EARLY-TRIP',
    name: 'Early Trip',
    resort: 'Test Resort',
    perPerson: '1000.00',
    start: '2026-07-01',
    length: '4 nights'
  }
];

const dateTieResults = rankTrips(
  dateTieTrips,
  {
    length: 4
  }
);

assert.equal(
  dateTieResults[0].trip.code,
  'EARLY-TRIP'
);

/*
 * Equal scores, prices, and dates should use trip code.
 */
const codeTieTrips = [
  {
    code: 'B-TRIP',
    name: 'Trip B',
    resort: 'Test Resort',
    perPerson: '1000.00',
    start: '2026-07-01',
    length: '4 nights'
  },
  {
    code: 'A-TRIP',
    name: 'Trip A',
    resort: 'Test Resort',
    perPerson: '1000.00',
    start: '2026-07-01',
    length: '4 nights'
  }
];

const codeTieResults = rankTrips(
  codeTieTrips,
  {
    length: 4
  }
);

assert.equal(
  codeTieResults[0].trip.code,
  'A-TRIP'
);

/*
 * Ranking should not change the original trip array.
 */
const originalOrder = trips.map(
  (trip) => trip.code
);

rankTrips(
  trips,
  {
    maximumPrice: 10000
  }
);

assert.deepEqual(
  trips.map((trip) => trip.code),
  originalOrder
);

console.log(
  'Trip recommendation tests passed.'
);