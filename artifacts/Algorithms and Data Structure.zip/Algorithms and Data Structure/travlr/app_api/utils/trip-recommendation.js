/**
 * Ranks trips based on a customer's preferences.
 *
 * Each trip receives a score, and the results are sorted by score.
 * Ties are resolved using price, start date, and trip code so the
 * recommendations stay consistent.
 *
 * Time complexity: O(n log n)
 * Space complexity: O(n)
 */

const SCORE_WEIGHTS = Object.freeze({
  budget: 35,
  resort: 30,
  startDate: 20,
  length: 15
});

/**
 * Converts a price such as "$1,299.00" into the number 1299.
 *
 * @param {string|number} value
 * @returns {number|null}
 */
const parsePrice = (value) => {
  if (value === undefined || value === null || value === '') {
    return null;
  }

  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }

  const normalizedValue = String(value).replace(/[^0-9.-]/g, '');
  const parsedValue = Number.parseFloat(normalizedValue);

  return Number.isFinite(parsedValue) ? parsedValue : null;
};

/**
 * Extracts the number of nights from a trip-length value.
 *
 * Example:
 * "4 nights / 5 days" becomes 4.
 *
 * @param {string|number} value
 * @returns {number|null}
 */
const parseLength = (value) => {
  if (value === undefined || value === null || value === '') {
    return null;
  }

  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : null;
  }

  const text = String(value).trim();

  const nightsMatch = text.match(/(\d+)\s+nights?/i);

  if (nightsMatch) {
    const nights = Number.parseInt(nightsMatch[1], 10);

    return Number.isFinite(nights) ? nights : null;
  }

  const fallbackMatch = text.match(/\d+/);

  if (!fallbackMatch) {
    return null;
  }

  const parsedValue = Number.parseInt(
    fallbackMatch[0],
    10
  );

  return Number.isFinite(parsedValue)
    ? parsedValue
    : null;
};

/**
 * Converts a value into a valid Date object.
 *
 * @param {string|Date} value
 * @returns {Date|null}
 */
const parseDate = (value) => {
  if (!value) {
    return null;
  }

  const parsedDate = value instanceof Date
    ? new Date(value.getTime())
    : new Date(value);

  return Number.isNaN(parsedDate.getTime())
    ? null
    : parsedDate;
};

/**
 * Normalizes text for case-insensitive comparisons.
 *
 * @param {*} value
 * @returns {string}
 */
const normalizeText = (value) => (
  String(value || '').trim().toLowerCase()
);

/**
 * Calculates the absolute number of days between two dates.
 *
 * @param {Date} firstDate
 * @param {Date} secondDate
 * @returns {number}
 */
const getDayDifference = (
  firstDate,
  secondDate
) => {
  const millisecondsPerDay =
    1000 * 60 * 60 * 24;

  return Math.abs(
    firstDate.getTime() -
    secondDate.getTime()
  ) / millisecondsPerDay;
};

/**
 * Scores one trip against the customer's preferences.
 *
 * @param {Object} trip
 * @param {Object} preferences
 * @returns {{
 *   trip: Object,
 *   score: number,
 *   matchReasons: string[],
 *   numericPrice: number|null,
 *   normalizedStartDate: Date|null
 * }}
 */
const scoreTrip = (
  trip,
  preferences
) => {
  let score = 0;
  const matchReasons = [];

  const tripPrice = parsePrice(
    trip.perPerson
  );

  const tripLength = parseLength(
    trip.length
  );

  const tripStartDate = parseDate(
    trip.start
  );

  const tripResort = normalizeText(
    trip.resort
  );

  const tripName = normalizeText(
    trip.name
  );

  if (
    preferences.maximumPrice !== null &&
    tripPrice !== null &&
    tripPrice <= preferences.maximumPrice
  ) {
    score += SCORE_WEIGHTS.budget;

    matchReasons.push(
      'Within the selected budget'
    );
  }

  if (
    preferences.resort &&
    (
      tripResort.includes(
        preferences.resort
      ) ||
      tripName.includes(
        preferences.resort
      )
    )
  ) {
    score += SCORE_WEIGHTS.resort;

    matchReasons.push(
      'Matches the trip or resort name'
    );
  }

  if (
    preferences.startDate &&
    tripStartDate
  ) {
    const dayDifference =
      getDayDifference(
        tripStartDate,
        preferences.startDate
      );

    if (dayDifference <= 7) {
      score += SCORE_WEIGHTS.startDate;

      matchReasons.push(
        'Starts within 7 days of the preferred date'
      );
    } else if (dayDifference <= 30) {
      score += Math.round(
        SCORE_WEIGHTS.startDate / 2
      );

      matchReasons.push(
        'Starts within 30 days of the preferred date'
      );
    }
  }

  if (
    preferences.length !== null &&
    tripLength !== null &&
    tripLength === preferences.length
  ) {
    score += SCORE_WEIGHTS.length;

    matchReasons.push(
      'Matches the preferred trip length'
    );
  }

  return {
    trip,
    score,
    matchReasons,
    numericPrice: tripPrice,
    normalizedStartDate: tripStartDate
  };
};

/**
 * Ranks trips according to customer preferences.
 *
 * A new results array is created so the original trip collection
 * is not changed.
 *
 * @param {Object[]} trips
 * @param {Object} rawPreferences
 * @returns {Object[]}
 */
const rankTrips = (
  trips = [],
  rawPreferences = {}
) => {
  const preferences = {
    maximumPrice: parsePrice(
      rawPreferences.maximumPrice
    ),

    resort: normalizeText(
      rawPreferences.resort
    ),

    startDate: parseDate(
      rawPreferences.startDate
    ),

    length: parseLength(
      rawPreferences.length
    )
  };

  return trips
    .map((trip) => (
      scoreTrip(
        trip,
        preferences
      )
    ))
    .sort((
      firstResult,
      secondResult
    ) => {
      if (
        secondResult.score !==
        firstResult.score
      ) {
        return (
          secondResult.score -
          firstResult.score
        );
      }

      const firstPrice =
        firstResult.numericPrice ??
        Number.MAX_VALUE;

      const secondPrice =
        secondResult.numericPrice ??
        Number.MAX_VALUE;

      if (firstPrice !== secondPrice) {
        return firstPrice - secondPrice;
      }

      const firstDate =
        firstResult.normalizedStartDate
          ? firstResult
            .normalizedStartDate
            .getTime()
          : Number.MAX_VALUE;

      const secondDate =
        secondResult.normalizedStartDate
          ? secondResult
            .normalizedStartDate
            .getTime()
          : Number.MAX_VALUE;

      if (firstDate !== secondDate) {
        return firstDate - secondDate;
      }

      return normalizeText(
        firstResult.trip.code
      ).localeCompare(
        normalizeText(
          secondResult.trip.code
        )
      );
    });
};

module.exports = {
  SCORE_WEIGHTS,
  parsePrice,
  parseLength,
  parseDate,
  scoreTrip,
  rankTrips
};