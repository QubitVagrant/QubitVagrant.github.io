require('dotenv').config();

const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const passport = require('passport');
const handlebars = require('hbs');

/*
 * Registers the MongoDB models and Passport strategy before the API
 * routes load controllers that depend on those models.
 */
require('./app_api/models/db');
require('./app_api/config/passport');

const indexRouter = require('./app_server/routes/index');
const usersRouter = require('./app_server/routes/users');
const travlrRouter = require('./app_server/routes/travlr');
const apiRouter = require('./app_api/routes/index');

const {
  loadCurrentUser
} = require('./app_server/middleware/customer-auth');

const app = express();

/*
 * Configures Handlebars as the view engine and registers the shared
 * header and footer partials used by the public website.
 */
app.set(
  'views',
  path.join(__dirname, 'app_server', 'views')
);

handlebars.registerPartials(
  path.join(__dirname, 'app_server', 'views', 'partials')
);

app.set('view engine', 'hbs');

/*
 * Configures request logging, JSON and form parsing, and cookies.
 */
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

/*
 * Reads the public website authentication cookie and makes the
 * signed-in user available to all Handlebars views.
 */
app.use(loadCurrentUser);

/*
 * Identifies the current public page so the shared navigation
 * highlights the correct menu item.
 */
app.use((req, res, next) => {
  res.locals.navHome = req.path === '/';
  res.locals.navTravel = req.path.startsWith('/travel');
  res.locals.navNews = req.path.startsWith('/news');
  res.locals.navAbout = req.path.startsWith('/about');

  next();
});

/*
 * Makes the public stylesheets, images, and scripts available.
 */
app.use(
  express.static(
    path.join(__dirname, 'public'),
    { index: false }
  )
);

/*
 * Initializes Passport before authentication requests are processed.
 */
app.use(passport.initialize());

/*
 * Connects the public website routes.
 */
app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/travel', travlrRouter);

/*
 * Allows the Angular administrator application on port 4200
 * to communicate with the shared API during local development.
 */
app.use('/api', (req, res, next) => {
  res.header(
    'Access-Control-Allow-Origin',
    'http://localhost:4200'
  );

  res.header(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization'
  );

  res.header(
    'Access-Control-Allow-Methods',
    'GET, POST, PUT, DELETE, OPTIONS'
  );

  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }

  next();
});

/*
 * Makes the REST API available under the /api path.
 */
app.use('/api', apiRouter);

/*
 * Converts unmatched routes into a 404 error.
 */
app.use((req, res, next) => {
  next(createError(404));
});

/*
 * Displays a controlled error page without exposing local file paths,
 * source-code locations, or stack traces to website visitors.
 */
app.use((error, req, res, next) => {
  const status = error.status || 500;
  const isNotFound = status === 404;

  /*
   * Server failures are written to the terminal for debugging but are
   * not included in the HTML response sent to the browser.
   */
  if (status >= 500) {
    console.error(error.stack || error);
  }

  res.status(status);

  res.render('error', {
    title: isNotFound
      ? 'Page Not Found'
      : 'Application Error',

    message: isNotFound
      ? 'Page Not Found'
      : 'Something went wrong while processing your request.',

    error: {
      status
    }
  });
});

module.exports = app;