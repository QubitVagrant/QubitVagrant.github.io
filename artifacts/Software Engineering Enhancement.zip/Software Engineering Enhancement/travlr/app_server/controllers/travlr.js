/* GET travel page using API */
const apiOptions = {
  server: 'http://localhost:3000'
};

const renderTravelPage = (req, res, trips) => {
  res.render('travel', {
    title: 'Travlr Getaways',
    trips
  });
};

const travel = async (req, res) => {
  try {
    const response = await fetch(`${apiOptions.server}/api/trips`);
    const trips = await response.json();

    if (!response.ok) {
      return res.status(response.status).render('error', {
        message: trips.message || 'API lookup error',
        error: {}
      });
    }

    renderTravelPage(req, res, trips);
  } catch (err) {
    res.status(500).render('error', {
      message: 'API lookup error',
      error: err
    });
  }
};

module.exports = {
  travel
};
