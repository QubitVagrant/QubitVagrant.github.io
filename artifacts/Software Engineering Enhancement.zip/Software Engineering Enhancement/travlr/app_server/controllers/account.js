const passport = require('passport');
const User = require('../../app_api/models/user');

const COOKIE_NAME = 'travlr_token';

/*
 * Configures the secure cookie used by the server-rendered public site.
 * The cookie cannot be read through normal browser JavaScript.
 */
const cookieOptions = {
  httpOnly: true,
  sameSite: 'lax',
  secure: process.env.NODE_ENV === 'production',
  maxAge: 60 * 60 * 1000
};

/*
 * Displays the customer registration form.
 */
const showRegister = (req, res) => {
  if (res.locals.isLoggedIn) {
    return res.redirect('/account');
  }

  return res.render('register', {
    title: 'Create Account',
    error: null,
    formData: {}
  });
};

/*
 * Creates a customer account and signs the customer in.
 * The User schema supplies the customer role automatically.
 */
const register = async (req, res) => {
  const name = req.body.name?.trim();
  const email = req.body.email?.trim().toLowerCase();
  const password = req.body.password;
  const confirmPassword = req.body.confirmPassword;

  const formData = {
    name,
    email
  };

  if (!name || !email || !password || !confirmPassword) {
    return res.status(400).render('register', {
      title: 'Create Account',
      error: 'All account fields are required.',
      formData
    });
  }

  if (password !== confirmPassword) {
    return res.status(400).render('register', {
      title: 'Create Account',
      error: 'The passwords do not match.',
      formData
    });
  }

  if (password.length < 8) {
    return res.status(400).render('register', {
      title: 'Create Account',
      error: 'The password must contain at least eight characters.',
      formData
    });
  }

  try {
    const user = new User({
      name,
      email
    });

    user.setPassword(password);

    await user.save();

    const token = user.generateJWT();

    res.cookie(COOKIE_NAME, token, cookieOptions);

    return res.redirect('/account');
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).render('register', {
        title: 'Create Account',
        error: 'An account already exists for that email address.',
        formData
      });
    }

    console.error('Public account registration failed:', error);

    return res.status(500).render('register', {
      title: 'Create Account',
      error: 'The account could not be created. Please try again.',
      formData
    });
  }
};

/*
 * Displays the customer login form.
 */
const showLogin = (req, res) => {
  if (res.locals.isLoggedIn) {
    return res.redirect('/account');
  }

  return res.render('login', {
    title: 'Log In',
    error: null,
    email: ''
  });
};

/*
 * Uses the existing Passport strategy to verify the account credentials.
 * A successful login stores the generated token in an HttpOnly cookie.
 */
const login = (req, res, next) => {
  const email = req.body.email?.trim().toLowerCase();
  const password = req.body.password;

  if (!email || !password) {
    return res.status(400).render('login', {
      title: 'Log In',
      error: 'Email and password are required.',
      email
    });
  }

  req.body.email = email;

  return passport.authenticate(
    'local',
    (error, user, information) => {
      if (error) {
        return next(error);
      }

      if (!user) {
        return res.status(401).render('login', {
          title: 'Log In',
          error:
            information?.message ||
            'The email or password is incorrect.',
          email
        });
      }

      const token = user.generateJWT();

      res.cookie(COOKIE_NAME, token, cookieOptions);

      return res.redirect('/account');
    }
  )(req, res, next);
};

/*
 * Displays the signed-in customer's account information.
 */
const account = (req, res) => {
  return res.render('account', {
    title: 'My Account',
    user: res.locals.currentUser
  });
};

/*
 * Removes the authentication cookie and returns the visitor to the homepage.
 */
const logout = (req, res) => {
  res.clearCookie(COOKIE_NAME, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production'
  });

  return res.redirect('/');
};

module.exports = {
  showRegister,
  register,
  showLogin,
  login,
  account,
  logout
};