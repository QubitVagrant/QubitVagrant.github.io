/* GET home page */
const index = (req, res) => {
  res.render('index', { title: 'Travlr Getaways' });
};

/* GET rooms page */
const rooms = (req, res) => {
  res.render('rooms', { title: 'Rooms' });
};

/* GET meals page */
const meals = (req, res) => {
  res.render('meals', { title: 'Meals' });
};

/* GET news page */
const news = (req, res) => {
  res.render('news', { title: 'News' });
};

/* GET about page */
const about = (req, res) => {
  res.render('about', { title: 'About' });
};

/* GET contact page */
const contact = (req, res) => {
  res.render('contact', { title: 'Contact' });
};

module.exports = {
  index,
  rooms,
  meals,
  news,
  about,
  contact
};