var express = require('express');
var router = express.Router();
const ctrlTravlr = require('../controllers/travlr');

/* GET travel page. */
router.get('/', ctrlTravlr.travel);

module.exports = router;