const express = require('express');
const router = express.Router();

const ctrlMain = require('../controllers/main');
const accountController = require('../controllers/account');

const {
  requireCustomerLogin
} = require('../middleware/customer-auth');

/*
 * Displays the public homepage and the existing informational pages.
 */
router.get('/', ctrlMain.index);
router.get('/rooms', ctrlMain.rooms);
router.get('/meals', ctrlMain.meals);
router.get('/news', ctrlMain.news);
router.get('/about', ctrlMain.about);
router.get('/contact', ctrlMain.contact);

/*
 * Displays and processes customer account registration.
 */
router.get('/register', accountController.showRegister);
router.post('/register', accountController.register);

/*
 * Displays and processes customer login.
 */
router.get('/login', accountController.showLogin);
router.post('/login', accountController.login);

/*
 * Requires a valid customer login before displaying account information.
 */
router.get(
  '/account',
  requireCustomerLogin,
  accountController.account
);

/*
 * Removes the authentication cookie and signs the customer out.
 * POST is used because logging out changes the user's session state.
 */
router.post('/logout', accountController.logout);

module.exports = router;