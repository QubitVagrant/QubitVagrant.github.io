const passport = require('passport');
const User = require('../models/user');

// Controller method to register a new user.
const register = async (req, res) => {
  // Validate message to ensure required fields are present.
  if (!req.body.name || !req.body.email || !req.body.password) {
    return res
      .status(400)
      .json({ message: 'All fields required' });
  }

  try {
    const user = new User();

    user.name = req.body.name;
    user.email = req.body.email;

    user.setPassword(req.body.password);

    await user.save();

    const token = user.generateJWT();

    return res
      .status(200)
      .json({ token });
  } catch (err) {
    return res
      .status(400)
      .json(err);
  }
};

// Controller method to log in an existing user.
const login = (req, res) => {
  // Validate message to ensure email and password are present.
  if (!req.body.email || !req.body.password) {
    return res
      .status(400)
      .json({ message: 'All fields required' });
  }

  // Delegate authentication to Passport.
  passport.authenticate('local', (err, user, info) => {
    if (err) {
      return res
        .status(404)
        .json(err);
    }

    if (user) {
      const token = user.generateJWT();

      return res
        .status(200)
        .json({ token });
    }

    return res
      .status(401)
      .json(info);
  })(req, res);
};

// Export methods that drive endpoints.
module.exports = {
  register,
  login
};