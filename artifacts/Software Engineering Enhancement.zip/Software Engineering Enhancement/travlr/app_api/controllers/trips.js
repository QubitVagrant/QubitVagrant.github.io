const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

/*
 * Defines the fields required for a complete trip record.
 */
const requiredTripFields = [
  'code',
  'name',
  'length',
  'start',
  'resort',
  'perPerson',
  'image',
  'description'
];

/*
 * Defines the accepted formats used by both the API and Angular forms.
 */
const tripCodePattern = /^[A-Za-z0-9-]{3,20}$/;
const tripLengthPattern =
  /^\d+\s+nights?\s*\/\s*\d+\s+days?$/i;
const tripPricePattern = /^\d+(?:\.\d{1,2})?$/;
const tripImagePattern =
  /^[A-Za-z0-9._-]+\.(?:jpg|jpeg|png|webp)$/i;

/*
 * Normalizes a trip code so lookups and stored records use
 * a consistent uppercase format.
 */
const normalizeTripCode = (value) => {
  if (typeof value !== 'string') {
    return '';
  }

  return value.trim().toUpperCase();
};

/*
 * Removes unnecessary whitespace from text values before validation
 * and before the data is stored in MongoDB.
 */
const normalizeTripInput = (body = {}) => ({
  code: normalizeTripCode(body.code),

  name:
    typeof body.name === 'string'
      ? body.name.trim()
      : body.name,

  length:
    typeof body.length === 'string'
      ? body.length.trim()
      : body.length,

  start:
    typeof body.start === 'string'
      ? body.start.trim()
      : body.start,

  resort:
    typeof body.resort === 'string'
      ? body.resort.trim()
      : body.resort,

  perPerson:
    body.perPerson === undefined ||
    body.perPerson === null
      ? body.perPerson
      : String(body.perPerson).trim(),

  image:
    typeof body.image === 'string'
      ? body.image.trim()
      : body.image,

  description:
    typeof body.description === 'string'
      ? body.description.trim()
      : body.description
});

/*
 * Returns today's date in YYYY-MM-DD format using the server's
 * local calendar date.
 */
const getTodayDateString = () => {
  const today = new Date();

  return [
    today.getFullYear(),
    String(today.getMonth() + 1).padStart(2, '0'),
    String(today.getDate()).padStart(2, '0')
  ].join('-');
};

/*
 * Validates a supplied date and returns its YYYY-MM-DD value.
 * Invalid calendar dates, such as February 31, are rejected.
 */
const getValidDateString = (value) => {
  if (
    value === undefined ||
    value === null ||
    value === ''
  ) {
    return null;
  }

  const text = String(value).trim();

  const dateMatch = text.match(
    /^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/
  );

  if (dateMatch) {
    const year = Number(dateMatch[1]);
    const month = Number(dateMatch[2]);
    const day = Number(dateMatch[3]);

    const calendarDate = new Date(
      Date.UTC(year, month - 1, day)
    );

    const isValidCalendarDate =
      calendarDate.getUTCFullYear() === year &&
      calendarDate.getUTCMonth() === month - 1 &&
      calendarDate.getUTCDate() === day;

    if (!isValidCalendarDate) {
      return null;
    }

    /*
     * Full timestamp values must still be parseable.
     */
    if (
      text.length > 10 &&
      Number.isNaN(new Date(text).getTime())
    ) {
      return null;
    }

    return [
      String(year).padStart(4, '0'),
      String(month).padStart(2, '0'),
      String(day).padStart(2, '0')
    ].join('-');
  }

  const parsedDate = new Date(text);

  if (Number.isNaN(parsedDate.getTime())) {
    return null;
  }

  return parsedDate.toISOString().substring(0, 10);
};

/*
 * Checks submitted trip data before it reaches Mongoose.
 * Creation can require a current or future date, while editing
 * may preserve an existing historical date.
 */
const validateTripInput = (
  trip,
  options = {}
) => {
  const {
    allowPastStartDate = true
  } = options;

  const missingFields = requiredTripFields.filter(
    (field) => {
      const value = trip[field];

      return (
        value === undefined ||
        value === null ||
        value === ''
      );
    }
  );

  if (missingFields.length > 0) {
    return {
      message: 'All trip fields are required.',
      fields: missingFields
    };
  }

  const errors = {};

  /*
   * Validate the permanent trip identifier.
   */
  if (!tripCodePattern.test(trip.code)) {
    errors.code =
      'Trip code must contain 3–20 letters, numbers, or hyphens.';
  }

  /*
   * Validate the customer-facing trip name.
   */
  if (
    typeof trip.name !== 'string' ||
    trip.name.length < 3 ||
    trip.name.length > 80
  ) {
    errors.name =
      'Trip name must contain between 3 and 80 characters.';
  }

  /*
   * Require a predictable duration format for filtering
   * and consistent display.
   */
  if (!tripLengthPattern.test(trip.length)) {
    errors.length =
      'Trip length must use a format such as 4 nights / 5 days.';
  } else if (trip.length.length > 40) {
    errors.length =
      'Trip length cannot exceed 40 characters.';
  }

  /*
   * Validate the date and reject historical dates only
   * when a new trip is being created.
   */
  const startDate = getValidDateString(trip.start);

  if (!startDate) {
    errors.start = 'Start date must be a valid date.';
  } else if (
    !allowPastStartDate &&
    startDate < getTodayDateString()
  ) {
    errors.start =
      'Start date cannot be in the past.';
  }

  /*
   * Validate the resort description.
   */
  if (
    typeof trip.resort !== 'string' ||
    trip.resort.length < 3 ||
    trip.resort.length > 120
  ) {
    errors.resort =
      'Resort information must contain between 3 and 120 characters.';
  }

  /*
   * Require a nonnegative price with no more than
   * two decimal places.
   */
  const priceText = String(trip.perPerson);
  const price = Number(priceText);

  if (
    !tripPricePattern.test(priceText) ||
    !Number.isFinite(price) ||
    price < 0
  ) {
    errors.perPerson =
      'Price per person must be a nonnegative number with no more than two decimal places.';
  }

  /*
   * Restrict image values to safe filenames and supported
   * customer-facing image formats.
   */
  if (
    typeof trip.image !== 'string' ||
    trip.image.length > 120 ||
    !tripImagePattern.test(trip.image)
  ) {
    errors.image =
      'Image must be a valid JPG, JPEG, PNG, or WebP filename.';
  }

  /*
   * Require a meaningful but reasonably sized description.
   */
  if (
    typeof trip.description !== 'string' ||
    trip.description.length < 10 ||
    trip.description.length > 1000
  ) {
    errors.description =
      'Description must contain between 10 and 1,000 characters.';
  }

  if (Object.keys(errors).length > 0) {
    return {
      message: 'Trip validation failed.',
      errors
    };
  }

  return null;
};

/*
 * Converts database failures into controlled API responses while
 * keeping internal implementation details out of client responses.
 */
const handleDatabaseError = (res, error) => {
  if (error.name === 'ValidationError') {
    const errors = Object.fromEntries(
      Object.entries(error.errors).map(
        ([field, details]) => [
          field,
          details.message
        ]
      )
    );

    return res.status(400).json({
      message: 'Trip validation failed.',
      errors
    });
  }

  if (error.code === 11000) {
    return res.status(409).json({
      message:
        'A trip with that code already exists.'
    });
  }

  console.error('Trip controller error:', error);

  return res.status(500).json({
    message:
      'An unexpected server error occurred.'
  });
};

/*
 * Returns the complete trip list.
 */
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).exec();

    return res.status(200).json(trips);
  } catch (error) {
    return handleDatabaseError(res, error);
  }
};

/*
 * Retrieves one trip using the permanent code supplied in the URL.
 */
const tripsFindCode = async (req, res) => {
  const tripCode = normalizeTripCode(
    req.params.tripCode
  );

  if (!tripCode) {
    return res.status(400).json({
      message: 'Trip code is required.'
    });
  }

  try {
    const trip = await Trip.findOne({
      code: tripCode
    }).exec();

    if (!trip) {
      return res.status(404).json({
        message: 'Trip code was not found.'
      });
    }

    return res.status(200).json(trip);
  } catch (error) {
    return handleDatabaseError(res, error);
  }
};

/*
 * Validates a new trip and requires its start date to be
 * today or a future date.
 */
const tripsAddTrip = async (req, res) => {
  const tripData = normalizeTripInput(req.body);

  const validationError = validateTripInput(
    tripData,
    {
      allowPastStartDate: false
    }
  );

  if (validationError) {
    return res.status(400).json(
      validationError
    );
  }

  try {
    const savedTrip = await Trip.create(
      tripData
    );

    return res.status(201).json(savedTrip);
  } catch (error) {
    return handleDatabaseError(res, error);
  }
};

/*
 * Updates the trip identified by the URL code.
 * The permanent trip code cannot be changed through the request body.
 * Historical start dates remain valid for existing records.
 */
const tripsUpdateTrip = async (req, res) => {
  const tripCode = normalizeTripCode(
    req.params.tripCode
  );

  if (!tripCode) {
    return res.status(400).json({
      message: 'Trip code is required.'
    });
  }

  const submittedCode = normalizeTripCode(
    req.body?.code
  );

  if (
    submittedCode &&
    submittedCode !== tripCode
  ) {
    return res.status(400).json({
      message:
        'Trip code cannot be changed after the trip is created.',
      fields: ['code']
    });
  }

  /*
   * The URL code is authoritative even when the body omits
   * or repeats the trip code.
   */
  const tripData = normalizeTripInput({
    ...req.body,
    code: tripCode
  });

  const validationError = validateTripInput(
    tripData,
    {
      allowPastStartDate: true
    }
  );

  if (validationError) {
    return res.status(400).json(
      validationError
    );
  }

  /*
   * Remove the permanent code from the update object so MongoDB
   * never receives an instruction to modify it.
   */
  const updatableTripData = {
    ...tripData
  };

  delete updatableTripData.code;

  try {
    const updatedTrip =
      await Trip.findOneAndUpdate(
        {
          code: tripCode
        },
        {
          $set: updatableTripData
        },
        {
          returnDocument: 'after',
          runValidators: true
        }
      ).exec();

    if (!updatedTrip) {
      return res.status(404).json({
        message: 'Trip code was not found.'
      });
    }

    return res.status(200).json(
      updatedTrip
    );
  } catch (error) {
    return handleDatabaseError(res, error);
  }
};

/*
 * Deletes the trip identified by the permanent code
 * supplied in the URL.
 */
const tripsDeleteTrip = async (req, res) => {
  const tripCode = normalizeTripCode(
    req.params.tripCode
  );

  if (!tripCode) {
    return res.status(400).json({
      message: 'Trip code is required.'
    });
  }

  try {
    const deletedTrip =
      await Trip.findOneAndDelete({
        code: tripCode
      }).exec();

    if (!deletedTrip) {
      return res.status(404).json({
        message: 'Trip code was not found.'
      });
    }

    return res.status(200).json({
      message: 'Trip deleted successfully.'
    });
  } catch (error) {
    return handleDatabaseError(res, error);
  }
};

module.exports = {
  tripsList,
  tripsFindCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};