const jwt = require('jsonwebtoken');

/*
 * Verifies the Bearer token included with a protected request.
 * A valid token identifies the signed-in user for later authorization checks.
 */
const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader) {
    return res.status(401).json({
      message: 'Authorization token is required.'
    });
  }

  const [scheme, token] = authHeader.trim().split(/\s+/);

  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({
      message: 'Authorization header must use a Bearer token.'
    });
  }

  jwt.verify(token, process.env.JWT_SECRET, (error, user) => {
    if (error) {
      return res.status(401).json({
        message: 'Authorization token is invalid or expired.'
      });
    }

    req.user = user;
    next();
  });
};

/*
 * Allows trip-management requests only when the authenticated
 * account contains the administrator role.
 */
const requireAdmin = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({
      message: 'Authentication is required.'
    });
  }

  if (req.user.role !== 'admin') {
    return res.status(403).json({
      message: 'Administrator access is required.'
    });
  }

  next();
};

module.exports = {
  authenticateJWT,
  requireAdmin
};