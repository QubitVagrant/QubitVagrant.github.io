const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

/*
 * Defines user accounts used for login and authorization.
 * New accounts receive the customer role by default so public registration
 * cannot grant access to administrator-only features.
 */
const userSchema = new mongoose.Schema({
  email: {
    type: String,
    unique: true,
    required: true
  },
  name: {
    type: String,
    required: true
  },
  role: {
    type: String,
    enum: ['customer', 'admin'],
    default: 'customer',
    required: true
  },
  hash: String,
  salt: String
});

/*
 * Creates a unique salt and password hash so the original password
 * is never stored in the database.
 */
userSchema.methods.setPassword = function(password) {
  this.salt = crypto.randomBytes(16).toString('hex');

  this.hash = crypto
    .pbkdf2Sync(password, this.salt, 1000, 64, 'sha512')
    .toString('hex');
};

/*
 * Hashes the submitted password with the saved salt and compares
 * the result with the stored password hash.
 */
userSchema.methods.validPassword = function(password) {
  const hash = crypto
    .pbkdf2Sync(password, this.salt, 1000, 64, 'sha512')
    .toString('hex');

  return this.hash === hash;
};

/*
 * Creates a one-hour authentication token containing the user's identity
 * and role. The server will use the role to authorize administrator actions.
 */
userSchema.methods.generateJWT = function() {
  return jwt.sign(
    {
      _id: this._id,
      email: this.email,
      name: this.name,
      role: this.role
    },
    process.env.JWT_SECRET,
    { expiresIn: '1h' }
  );
};

/*
 * Registers and exports the model so controllers and Passport can use it.
 */
const User = mongoose.model('users', userSchema);

module.exports = User;