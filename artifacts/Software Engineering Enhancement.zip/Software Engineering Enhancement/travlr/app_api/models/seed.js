// Import required packages and files
const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const Trip = require('./travlr');

// Define the database connection
const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;

// Read trip data from the JSON file created in Module 3
const tripsPath = path.join(__dirname, '..', '..', 'app_server', 'data', 'trips.json');
const trips = JSON.parse(fs.readFileSync(tripsPath, 'utf8'));

// Seed the MongoDB database with trip data
const seedDB = async () => {
  try {
    // Connect to MongoDB
    await mongoose.connect(dbURI);
    console.log(`Mongoose connected to ${dbURI}`);

    // Clear existing trip documents to avoid duplicates
    await Trip.deleteMany({});
    console.log('Existing trips removed');

    // Insert trips from trips.json into the trips collection
    await Trip.insertMany(trips);
    console.log(`${trips.length} trips inserted`);

    // Confirm how many documents exist after seeding
    const count = await Trip.countDocuments();
    console.log(`Trips collection now contains ${count} documents`);
  } catch (err) {
    // Display any seed errors
    console.error('Seed error:', err);
  } finally {
    // Close the database connection
    await mongoose.connection.close();
    console.log('Mongoose disconnected');
  }
};

// Run the seed function
seedDB();
