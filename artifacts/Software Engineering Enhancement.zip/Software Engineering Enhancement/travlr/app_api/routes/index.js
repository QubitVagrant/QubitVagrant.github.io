const express = require('express');
const router = express.Router();

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');
const {
  authenticateJWT,
  requireAdmin
} = require('../middleware/auth');

/*
 * Public authentication routes allow users to create an account
 * and sign in without already having an authentication token.
 */
router
  .route('/register')
  .post(authController.register);

router
  .route('/login')
  .post(authController.login);

/*
 * Anyone may view the trip list. Creating a trip requires both
 * a valid login token and the administrator role.
 */
router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(
    authenticateJWT,
    requireAdmin,
    tripsController.tripsAddTrip
  );

/*
 * Anyone may retrieve one trip by its code. Updating or deleting
 * the trip is restricted to authenticated administrator accounts.
 */
router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindCode)
  .put(
    authenticateJWT,
    requireAdmin,
    tripsController.tripsUpdateTrip
  )
  .delete(
    authenticateJWT,
    requireAdmin,
    tripsController.tripsDeleteTrip
  );

module.exports = router;