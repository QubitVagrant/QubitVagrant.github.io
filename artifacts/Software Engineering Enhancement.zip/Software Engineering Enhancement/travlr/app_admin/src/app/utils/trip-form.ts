import { HttpErrorResponse } from '@angular/common/http';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators
} from '@angular/forms';

import { Trip } from '../models/trip';

interface TripFormOptions {
  allowPastStartDate?: boolean;
}

/*
 * Confirms that a supplied value can be parsed as a real date.
 */
const validDateValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
  if (!control.value) {
    return null;
  }

  const date = new Date(String(control.value));

  return Number.isNaN(date.getTime())
    ? { invalidDate: true }
    : null;
};

/*
 * Prevents a newly created trip from using a date earlier than today.
 * Existing trips may retain historical dates when they are edited.
 */
const todayOrFutureValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
  if (!control.value) {
    return null;
  }

  const selectedDate = String(control.value).substring(0, 10);
  const today = new Date();

  const currentDate = [
    today.getFullYear(),
    String(today.getMonth() + 1).padStart(2, '0'),
    String(today.getDate()).padStart(2, '0')
  ].join('-');

  return selectedDate < currentDate
    ? { pastDate: true }
    : null;
};

/*
 * Creates the shared form used by both Add Trip and Edit Trip.
 * Options allow Edit Trip to preserve an existing historical date
 * while Add Trip requires today or a future date.
 */
export const createTripForm = (
  formBuilder: FormBuilder,
  options: TripFormOptions = {}
): FormGroup => {
  const startValidators: ValidatorFn[] = [
    Validators.required,
    validDateValidator
  ];

  if (!options.allowPastStartDate) {
    startValidators.push(todayOrFutureValidator);
  }

  return formBuilder.group({
    code: [
      '',
      [
        Validators.required,
        Validators.maxLength(20),
        Validators.pattern(/^[A-Za-z0-9-]{3,20}$/)
      ]
    ],

    name: [
      '',
      [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(80)
      ]
    ],

    length: [
      '',
      [
        Validators.required,
        Validators.maxLength(40),
        Validators.pattern(
          /^\d+\s+nights?\s*\/\s*\d+\s+days?$/i
        )
      ]
    ],

    start: [
      '',
      startValidators
    ],

    resort: [
      '',
      [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(120)
      ]
    ],

    perPerson: [
      '',
      [
        Validators.required,
        Validators.pattern(/^\d+(?:\.\d{1,2})?$/)
      ]
    ],

    image: [
      '',
      [
        Validators.required,
        Validators.maxLength(120),
        Validators.pattern(
          /^[A-Za-z0-9._-]+\.(?:jpg|jpeg|png|webp)$/i
        )
      ]
    ],

    description: [
      '',
      [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(1000)
      ]
    ]
  });
};

/*
 * Trims text fields and normalizes the trip code before the completed
 * form is sent to the API.
 */
export const normalizeTripFormValue = (
  value: Record<string, unknown>
): Trip => {
  return {
    code: String(value['code'] ?? '')
      .trim()
      .toUpperCase(),

    name: String(value['name'] ?? '').trim(),

    length: String(value['length'] ?? '').trim(),

    start: String(value['start'] ?? '').trim(),

    resort: String(value['resort'] ?? '').trim(),

    perPerson: String(value['perPerson'] ?? '').trim(),

    image: String(value['image'] ?? '').trim(),

    description: String(
      value['description'] ?? ''
    ).trim()
  } as Trip;
};

/*
 * Converts API failures into messages that administrators can understand
 * without exposing internal database information.
 */
export const getTripApiErrorMessage = (
  error: HttpErrorResponse,
  fallbackMessage: string
): string => {
  const response = error.error as
    | {
        message?: string;
        fields?: string[];
        errors?: Record<string, string>;
      }
    | string
    | null;

  if (
    typeof response === 'string' &&
    response.trim()
  ) {
    return response;
  }

  if (
    response &&
    typeof response === 'object'
  ) {
    if (response.errors) {
      const details = Object.values(
        response.errors
      );

      if (details.length > 0) {
        return details.join(' ');
      }
    }

    if (response.message) {
      if (
        response.fields &&
        response.fields.length > 0
      ) {
        return (
          `${response.message} ` +
          `Fields: ${response.fields.join(', ')}.`
        );
      }

      return response.message;
    }
  }

  if (error.status === 0) {
    return (
      'The API is unavailable. ' +
      'Confirm the Express server is running.'
    );
  }

  if (error.status === 401) {
    return 'Your session has expired. Sign in again.';
  }

  if (error.status === 403) {
    return 'Administrator access is required.';
  }

  return fallbackMessage;
};