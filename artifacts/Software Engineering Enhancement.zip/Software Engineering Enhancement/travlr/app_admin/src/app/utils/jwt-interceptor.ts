import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';

import { Authentication } from '../services/authentication';

export const jwtInterceptor: HttpInterceptorFn = (req, next) => {
  const authenticationService = inject(Authentication);

  const isAuthApi =
    req.url.includes('/login') ||
    req.url.includes('/register');

  if (authenticationService.isLoggedIn() && !isAuthApi) {
    const token = authenticationService.getToken();

    req = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  return next(req);
};