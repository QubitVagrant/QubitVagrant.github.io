import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  Router,
  RouterLink,
  RouterLinkActive
} from '@angular/router';

import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-navbar',
  imports: [
    CommonModule,
    RouterLink,
    RouterLinkActive
  ],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css'
})
export class Navbar {
  constructor(
    private readonly authenticationService: Authentication,
    private readonly router: Router
  ) {}

  /*
   * Reports whether a valid authentication token is currently stored.
   */
  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  /*
   * Shows administrator navigation only for an account whose token
   * contains the admin role.
   */
  public isAdmin(): boolean {
    return this.authenticationService.isAdmin();
  }

  /*
   * Prevents a redundant Sign In link from appearing while the
   * administrator login page is already displayed.
   */
  public isLoginPage(): boolean {
    return this.router.url.startsWith('/login');
  }

  /*
   * Removes the administrator token and returns to the login page.
   */
  public onLogout(): void {
    this.authenticationService.logout();
    this.router.navigate(['/login']);
  }
}