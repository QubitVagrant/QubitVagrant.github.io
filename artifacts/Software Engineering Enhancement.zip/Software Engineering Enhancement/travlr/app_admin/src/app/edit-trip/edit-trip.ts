import { HttpErrorResponse } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import {
  Component,
  OnInit,
  signal
} from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule
} from '@angular/forms';
import {
  ActivatedRoute,
  Router
} from '@angular/router';
import { finalize } from 'rxjs';

import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import {
  createTripForm,
  getTripApiErrorMessage,
  normalizeTripFormValue
} from '../utils/trip-form';

@Component({
  selector: 'app-edit-trip',
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTrip implements OnInit {
  public editForm!: FormGroup;
  public tripCode = '';

  /*
   * Signals ensure that asynchronous API results immediately update
   * the page after a trip is loaded, updated, or deleted.
   */
  public readonly formError = signal('');
  public readonly isLoading = signal(true);
  public readonly isSubmitting = signal(false);

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly tripDataService: TripData
  ) {}

  /*
   * Builds the shared trip form and loads the selected trip.
   * Existing trips may keep a historical start date when edited.
   */
  public ngOnInit(): void {
    this.editForm = createTripForm(
      this.formBuilder,
      {
        allowPastStartDate: true
      }
    );

    this.tripCode =
      this.route.snapshot.paramMap
        .get('tripCode')
        ?.trim() || '';

    if (!this.tripCode) {
      this.isLoading.set(false);

      this.formError.set(
        'A trip code was not provided.'
      );

      return;
    }

    this.tripDataService
      .getTrip(this.tripCode)
      .pipe(
        finalize(() => {
          this.isLoading.set(false);
        })
      )
      .subscribe({
        next: (trip: Trip) => {
          this.editForm.patchValue({
            code: trip.code,
            name: trip.name,
            length: trip.length,
            start: trip.start
              ? String(trip.start).substring(0, 10)
              : '',
            resort: trip.resort,
            perPerson: trip.perPerson,
            image: trip.image,
            description: trip.description
          });
        },

        error: (error: HttpErrorResponse) => {
          this.formError.set(
            getTripApiErrorMessage(
              error,
              'The trip could not be loaded.'
            )
          );
        }
      });
  }

  /*
   * Reports whether a form control is invalid after the
   * administrator has interacted with it.
   */
  public isInvalid(controlName: string): boolean {
    const control = this.editForm.get(controlName);

    return Boolean(
      control &&
      control.invalid &&
      (control.touched || control.dirty)
    );
  }

  /*
   * Reports whether a specific validation rule failed.
   */
  public hasError(
    controlName: string,
    errorName: string
  ): boolean {
    const control = this.editForm.get(controlName);

    return Boolean(
      control &&
      control.hasError(errorName) &&
      (control.touched || control.dirty)
    );
  }

  /*
   * Validates and updates the selected trip.
   */
  public onSubmit(): void {
    this.formError.set('');

    if (this.editForm.invalid) {
      this.editForm.markAllAsTouched();

      this.formError.set(
        'Correct the highlighted fields before saving the trip.'
      );

      return;
    }

    this.isSubmitting.set(true);

    const trip = normalizeTripFormValue(
      this.editForm.getRawValue()
    );

    this.tripDataService
      .updateTrip(this.tripCode, trip)
      .pipe(
        finalize(() => {
          this.isSubmitting.set(false);
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate(['/trips']);
        },

        error: (error: HttpErrorResponse) => {
          this.formError.set(
            getTripApiErrorMessage(
              error,
              'The trip could not be updated. Please try again.'
            )
          );
        }
      });
  }

  /*
   * Confirms the destructive action before deleting
   * the selected trip.
   */
  public onDelete(): void {
    const confirmed = window.confirm(
      `Delete ${this.tripCode}? ` +
      'This action cannot be undone.'
    );

    if (!confirmed) {
      return;
    }

    this.formError.set('');
    this.isSubmitting.set(true);

    this.tripDataService
      .deleteTrip(this.tripCode)
      .pipe(
        finalize(() => {
          this.isSubmitting.set(false);
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate(['/trips']);
        },

        error: (error: HttpErrorResponse) => {
          this.formError.set(
            getTripApiErrorMessage(
              error,
              'The trip could not be deleted. Please try again.'
            )
          );
        }
      });
  }
}