import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { Authentication } from '../services/authentication';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login implements OnInit {
  private readonly authenticationService = inject(Authentication);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  public formError = '';

  public credentials: User = {
    email: '',
    password: ''
  };

  /*
   * Displays a clear message when a non-administrator account
   * is redirected away from a protected administration page.
   */
  public ngOnInit(): void {
    if (
      this.route.snapshot.queryParamMap.get('error') ===
      'admin-required'
    ) {
      this.formError =
        'This portal is restricted to Travlr administrators.';
    }
  }

  /*
   * Authenticates the submitted account and allows access only when
   * the returned token contains the administrator role.
   */
  public onLoginSubmit(): void {
    this.formError = '';

    this.credentials.email =
      this.credentials.email.trim().toLowerCase();

    if (
      !this.credentials.email ||
      !this.credentials.password
    ) {
      this.formError = 'Email and password are required.';
      return;
    }

    this.authenticationService
      .login(this.credentials)
      .subscribe({
        next: () => {
          if (this.authenticationService.isAdmin()) {
            this.router.navigate(['/trips']);
            return;
          }

          /*
           * Valid customer credentials are not enough to enter the
           * employee portal, so the temporary Angular token is removed.
           */
          this.authenticationService.logout();
          this.credentials.password = '';

          this.formError =
            'This portal is restricted to Travlr administrators. ' +
            'Customers should use the public Travlr website.';
        },
        error: () => {
          this.credentials.password = '';

          this.formError =
            'Sign in failed. Check your email and password.';
        }
      });
  }
}