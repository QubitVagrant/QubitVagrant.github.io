import { HttpErrorResponse } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule
} from '@angular/forms';
import { Router } from '@angular/router';
import { finalize } from 'rxjs';

import { TripData } from '../services/trip-data';
import {
  createTripForm,
  getTripApiErrorMessage,
  normalizeTripFormValue
} from '../utils/trip-form';

@Component({
  selector: 'app-add-trip',
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css'
})
export class AddTrip implements OnInit {
  public addForm!: FormGroup;
  public formError = '';
  public isSubmitting = false;

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly tripDataService: TripData,
    private readonly router: Router
  ) {}

  /*
   * Builds the Add Trip form using the shared validation rules.
   * New trips must use today's date or a future start date.
   */
  public ngOnInit(): void {
    this.addForm = createTripForm(
      this.formBuilder,
      {
        allowPastStartDate: false
      }
    );
  }

  /*
   * Reports whether a control is invalid after the administrator
   * has interacted with it or attempted to submit the form.
   */
  public isInvalid(controlName: string): boolean {
    const control = this.addForm.get(controlName);

    return Boolean(
      control &&
      control.invalid &&
      (control.touched || control.dirty)
    );
  }

  /*
   * Reports whether a specific validation rule failed.
   */
  public hasError(
    controlName: string,
    errorName: string
  ): boolean {
    const control = this.addForm.get(controlName);

    return Boolean(
      control &&
      control.hasError(errorName) &&
      (control.touched || control.dirty)
    );
  }

  /*
   * Validates and normalizes the trip before sending it to the API.
   * API failures are displayed directly on the page.
   */
  public onSubmit(): void {
    this.formError = '';

    if (this.addForm.invalid) {
      this.addForm.markAllAsTouched();

      this.formError =
        'Correct the highlighted fields before saving the trip.';

      return;
    }

    this.isSubmitting = true;

    const trip = normalizeTripFormValue(
      this.addForm.getRawValue()
    );

    this.tripDataService
      .addTrip(trip)
      .pipe(
        finalize(() => {
          this.isSubmitting = false;
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate(['/trips']);
        },

        error: (error: HttpErrorResponse) => {
          this.formError = getTripApiErrorMessage(
            error,
            'The trip could not be added. Please try again.'
          );
        }
      });
  }
}