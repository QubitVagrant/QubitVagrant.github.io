import { Routes } from '@angular/router';

import { TripListing } from './trip-listing/trip-listing';
import { AddTrip } from './add-trip/add-trip';
import { EditTrip } from './edit-trip/edit-trip';
import { Login } from './login/login';
import { adminGuard } from './utils/admin-guard';

/*
 * Starts the Angular employee portal on the login page.
 * All trip-management pages require an administrator token.
 */
export const routes: Routes = [
  {
    path: 'login',
    component: Login
  },
  {
    path: 'trips',
    component: TripListing,
    canActivate: [adminGuard]
  },
  {
    path: 'add-trip',
    component: AddTrip,
    canActivate: [adminGuard]
  },
  {
    path: 'edit-trip/:tripCode',
    component: EditTrip,
    canActivate: [adminGuard]
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'login'
  }
];