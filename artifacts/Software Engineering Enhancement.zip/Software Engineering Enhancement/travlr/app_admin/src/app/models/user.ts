/*
 * Describes the account information used by the Angular application.
 * The role determines whether the signed-in account may use admin features.
 */
export type UserRole = 'customer' | 'admin';

export interface User {
  email: string;
  name?: string;
  password: string;
  role?: UserRole;
}