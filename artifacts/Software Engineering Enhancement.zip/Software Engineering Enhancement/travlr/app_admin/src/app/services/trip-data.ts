import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Trip } from '../models/trip';

interface DeleteTripResponse {
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class TripData {
  private readonly apiBaseUrl =
    'http://localhost:3000/api/trips';

  constructor(
    private readonly http: HttpClient
  ) {}

  /*
   * Retrieves every trip from the shared Express API.
   * The cache-busting value prevents stale trip lists after an update.
   */
  public getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(
      `${this.apiBaseUrl}?cb=${Date.now()}`
    );
  }

  /*
   * Retrieves one trip using its unique trip code.
   */
  public getTrip(tripCode: string): Observable<Trip> {
    const encodedTripCode =
      encodeURIComponent(tripCode.trim());

    return this.http.get<Trip>(
      `${this.apiBaseUrl}/${encodedTripCode}`
    );
  }

  /*
   * Creates a new trip using the validated administrator form data.
   */
  public addTrip(formData: Trip): Observable<Trip> {
    return this.http.post<Trip>(
      this.apiBaseUrl,
      formData
    );
  }

  /*
   * Updates the trip identified by its original code.
   */
  public updateTrip(
    tripCode: string,
    formData: Trip
  ): Observable<Trip> {
    const encodedTripCode =
      encodeURIComponent(tripCode.trim());

    return this.http.put<Trip>(
      `${this.apiBaseUrl}/${encodedTripCode}`,
      formData
    );
  }

  /*
   * Deletes the trip identified by its unique code.
   */
  public deleteTrip(
    tripCode: string
  ): Observable<DeleteTripResponse> {
    const encodedTripCode =
      encodeURIComponent(tripCode.trim());

    return this.http.delete<DeleteTripResponse>(
      `${this.apiBaseUrl}/${encodedTripCode}`
    );
  }
}