import {
  inject,
  Injectable,
  signal
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {
  Observable,
  tap
} from 'rxjs';

import { BROWSER_STORAGE } from '../storage';
import {
  User,
  UserRole
} from '../models/user';
import { AuthResponse } from '../models/auth-response';

/*
 * Describes the account information stored inside the JSON Web Token.
 */
interface TokenPayload {
  email: string;
  name?: string;
  role?: UserRole;
  exp: number;
}

@Injectable({
  providedIn: 'root'
})
export class Authentication {
  private readonly apiBaseUrl =
    'http://localhost:3000/api';

  private readonly tokenKey =
    'travlr-token';

  /*
   * Retrieves Angular services without constructor decorators.
   */
  private readonly http =
    inject(HttpClient);

  private readonly storage =
    inject(BROWSER_STORAGE);

  /*
   * Keeps the saved token in reactive Angular state.
   * Updating this signal immediately refreshes navbar authentication links.
   */
  private readonly tokenState = signal(
    this.storage.getItem(this.tokenKey) || ''
  );

  /*
   * Stores the authentication token in both browser storage
   * and reactive application state.
   */
  public saveToken(token: string): void {
    this.storage.setItem(
      this.tokenKey,
      token
    );

    this.tokenState.set(token);
  }

  /*
   * Retrieves the current authentication token from reactive state.
   */
  public getToken(): string {
    return this.tokenState();
  }

  /*
   * Removes the authentication token from browser storage
   * and immediately updates components such as the navbar.
   */
  public logout(): void {
    this.storage.removeItem(this.tokenKey);
    this.tokenState.set('');
  }

  /*
   * Decodes the JWT payload so Angular can read the account identity,
   * expiration time, and role without modifying the token.
   */
  private decodeToken(
    token: string
  ): TokenPayload | null {
    try {
      const tokenParts = token.split('.');

      if (tokenParts.length !== 3) {
        return null;
      }

      const encodedPayload = tokenParts[1]
        .replace(/-/g, '+')
        .replace(/_/g, '/');

      const paddedPayload = encodedPayload.padEnd(
        Math.ceil(
          encodedPayload.length / 4
        ) * 4,
        '='
      );

      return JSON.parse(
        atob(paddedPayload)
      ) as TokenPayload;
    } catch {
      return null;
    }
  }

  /*
   * Confirms that a token exists and has not expired.
   * Reading tokenState makes this method reactive inside templates.
   */
  public isLoggedIn(): boolean {
    const token = this.tokenState();

    if (!token) {
      return false;
    }

    const payload =
      this.decodeToken(token);

    if (
      !payload ||
      payload.exp <= Date.now() / 1000
    ) {
      this.logout();
      return false;
    }

    return true;
  }

  /*
   * Returns the account information stored inside the current token.
   */
  public getCurrentUser(): User | null {
    if (!this.isLoggedIn()) {
      return null;
    }

    const payload = this.decodeToken(
      this.tokenState()
    );

    if (!payload) {
      return null;
    }

    return {
      email: payload.email,
      name: payload.name,
      password: '',
      role: payload.role
    };
  }

  /*
   * Reports whether the current token belongs to an administrator.
   * Tokens without an administrator role are denied admin access.
   */
  public isAdmin(): boolean {
    return (
      this.getCurrentUser()?.role ===
      'admin'
    );
  }

  /*
   * Sends credentials to the API and stores the returned token.
   * Saving the token signal immediately changes Sign In to Log Out.
   */
  public login(
    user: User
  ): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(
        `${this.apiBaseUrl}/login`,
        user
      )
      .pipe(
        tap(
          (
            authResponse: AuthResponse
          ) => {
            this.saveToken(
              authResponse.token
            );
          }
        )
      );
  }

  /*
   * Retains compatibility with existing Angular code.
   * Public customer registration occurs on the port 3000 website.
   */
  public register(
    user: User
  ): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(
        `${this.apiBaseUrl}/register`,
        user
      )
      .pipe(
        tap(
          (
            authResponse: AuthResponse
          ) => {
            this.saveToken(
              authResponse.token
            );
          }
        )
      );
  }
}