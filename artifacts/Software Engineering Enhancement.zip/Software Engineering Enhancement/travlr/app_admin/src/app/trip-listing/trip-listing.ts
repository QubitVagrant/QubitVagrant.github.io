import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import { TripCard } from '../trip-card/trip-card';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  imports: [CommonModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css'
})
export class TripListing implements OnInit {
  trips: Trip[] = [];
  message: string = '';

  constructor(
    private tripDataService: TripData,
    private router: Router,
    private cdr: ChangeDetectorRef,
    private authenticationService: Authentication
  ) {}

  private getTrips(): void {
    this.tripDataService.getTrips().subscribe({
      next: (trips: Trip[]) => {
        console.log('Trips loaded:', trips);
        this.trips = trips;
        this.cdr.detectChanges();
      },
      error: (error: any) => {
        console.log('TripDataService Error: ', error);
      }
    });
  }

  public isLoggedIn(): boolean {
    return this.authenticationService.isLoggedIn();
  }

  addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  ngOnInit(): void {
    this.getTrips();
  }
}