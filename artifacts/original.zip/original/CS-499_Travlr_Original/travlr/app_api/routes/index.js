const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (authHeader == null) {
    return res
      .status(401)
      .json({ message: 'Auth Header is required but NOT PRESENT!' });
  }

  const authHeaderParts = authHeader.split(' ');

  if (authHeaderParts.length !== 2) {
    return res
      .status(401)
      .json({ message: 'Auth Header is malformed!' });
  }

  const token = authHeaderParts[1];

  if (token == null) {
    return res
      .status(401)
      .json({ message: 'Bearer token is required but NOT PRESENT!' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res
        .status(401)
        .json({ message: 'JWT verification failed!' });
    }

    req.user = user;
    next();
  });
};

router
  .route('/register')
  .post(authController.register);

router
  .route('/login')
  .post(authController.login);

router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(authenticateJWT, tripsController.tripsAddTrip);

router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindCode)
  .put(authenticateJWT, tripsController.tripsUpdateTrip)
  .delete(authenticateJWT, tripsController.tripsDeleteTrip);

module.exports = router;