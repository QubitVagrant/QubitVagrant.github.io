const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

/* GET all trips */
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).exec();
    if (!trips || trips.length === 0) {
      return res.status(404).json({ message: 'No trips found' });
    }
    return res.status(200).json(trips);
  } catch (err) {
    return res.status(500).json(err);
  }
};

/* GET one trip by code */
const tripsFindCode = async (req, res) => {
  if (!req.params.tripCode) {
    return res.status(400).json({ message: 'Trip code is required' });
  }

  try {
    const trips = await Trip.find({ code: req.params.tripCode }).exec();

    if (!trips || trips.length === 0) {
      return res.status(404).json({ message: 'Trip code not found' });
    }

    return res.status(200).json(trips[0]);
  } catch (err) {
    return res.status(500).json(err);
  }
};

/* POST add a trip */
const tripsAddTrip = async (req, res) => {
  try {
    const newTrip = new Trip({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    });

    const savedTrip = await newTrip.save();
    return res.status(201).json(savedTrip);
  } catch (err) {
    return res.status(500).json(err);
  }
};

/* PUT update a trip */
const tripsUpdateTrip = async (req, res) => {
  if (!req.params.tripCode) {
    return res.status(400).json({ message: 'Trip code is required' });
  }

  try {
    const updatedTrip = await Trip.findOneAndUpdate(
      { code: req.params.tripCode },
      {
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description
      },
      { new: true }
    ).exec();

    if (!updatedTrip) {
      return res.status(404).json({ message: 'Trip code not found' });
    }

    return res.status(200).json(updatedTrip);
  } catch (err) {
    return res.status(500).json(err);
  }
};

/* DELETE one trip by code */
const tripsDeleteTrip = async (req, res) => {
  if (!req.params.tripCode) {
    return res.status(400).json({ message: 'Trip code is required' });
  }

  try {
    const deletedTrip = await Trip.findOneAndDelete({
      code: req.params.tripCode
    }).exec();

    if (!deletedTrip) {
      return res.status(404).json({ message: 'Trip code not found' });
    }

    return res.status(200).json({ message: 'Trip deleted successfully' });
  } catch (err) {
    return res.status(500).json(err);
  }
};

module.exports = {
  tripsList,
  tripsFindCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};