import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { Authentication } from '../services/authentication';
import { User } from '../models/user';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  public formError = '';

  public credentials: User = {
    email: '',
    password: ''
  };

  constructor(
    private authenticationService: Authentication,
    private router: Router
  ) {}

  public onLoginSubmit(): void {
    this.formError = '';

    if (!this.credentials.email || !this.credentials.password) {
      this.formError = 'All fields are required.';
      return;
    }

    this.authenticationService.login(this.credentials).subscribe({
      next: () => {
        this.router.navigate(['']);
      },
      error: (err) => {
        console.error('Login error:', err);
        this.formError = 'Login failed. Please check your email and password.';
      }
    });
  }
}