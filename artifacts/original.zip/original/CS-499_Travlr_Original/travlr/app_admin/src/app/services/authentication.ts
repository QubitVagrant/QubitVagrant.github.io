import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

import { BROWSER_STORAGE } from '../storage';
import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';

@Injectable({
  providedIn: 'root'
})
export class Authentication {
  private apiBaseUrl = 'http://localhost:3000/api';
  private tokenKey = 'travlr-token';

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  public saveToken(token: string): void {
    this.storage.setItem(this.tokenKey, token);
  }

  public getToken(): string {
    return this.storage.getItem(this.tokenKey) || '';
  }

  public logout(): void {
    this.storage.removeItem(this.tokenKey);
  }

  public isLoggedIn(): boolean {
    const token = this.getToken();

    if (!token) {
      return false;
    }

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > Date.now() / 1000;
    } catch (error) {
      return false;
    }
  }

  public getCurrentUser(): User | null {
    if (!this.isLoggedIn()) {
      return null;
    }

    const token = this.getToken();
    const payload = JSON.parse(atob(token.split('.')[1]));

    return {
      email: payload.email,
      name: payload.name,
      password: ''
    };
  }

  public login(user: User): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(`${this.apiBaseUrl}/login`, user)
      .pipe(
        tap((authResponse: AuthResponse) => {
          this.saveToken(authResponse.token);
        })
      );
  }

  public register(user: User): Observable<AuthResponse> {
    return this.http
      .post<AuthResponse>(`${this.apiBaseUrl}/register`, user)
      .pipe(
        tap((authResponse: AuthResponse) => {
          this.saveToken(authResponse.token);
        })
      );
  }
}