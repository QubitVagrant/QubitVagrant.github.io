import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

import { TripData } from '../services/trip-data';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTrip implements OnInit {
  editForm!: FormGroup;
  tripCode: string = '';

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private tripDataService: TripData
  ) {}

  ngOnInit(): void {
    this.tripCode = this.route.snapshot.paramMap.get('tripCode') || '';

    this.editForm = this.formBuilder.group({
      code: ['', Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required]
    });

    this.tripDataService.getTrip(this.tripCode).subscribe({
      next: (trip: Trip) => {
        this.editForm.patchValue({
          code: trip.code,
          name: trip.name,
          length: trip.length,
          start: trip.start ? trip.start.substring(0, 10) : '',
          resort: trip.resort,
          perPerson: trip.perPerson,
          image: trip.image,
          description: trip.description
        });
      },
      error: (error: any) => {
        console.log('Error loading trip: ', error);
      }
    });
  }

  onSubmit(): void {
    if (this.editForm.valid) {
      this.tripDataService.updateTrip(this.tripCode, this.editForm.value as Trip).subscribe({
        next: () => {
          this.router.navigate(['']);
        },
        error: (error: any) => {
          console.log('Error updating trip: ', error);
        }
      });
    }
  }

  onDelete(): void {
    if (confirm('Are you sure you want to delete this trip?')) {
      this.tripDataService.deleteTrip(this.tripCode).subscribe({
        next: () => {
          this.router.navigate(['']);
        },
        error: (error: any) => {
          console.log('Error deleting trip: ', error);
        }
      });
    }
  }
}