/*
 * Server-rendered customer booking controller.
 *
 * The public website cannot read the HttpOnly authentication cookie
 * through browser JavaScript, so these actions forward the cookie token
 * to the REST API as a Bearer token.
 */
const apiOptions = {
  server:
    process.env.API_SERVER ||
    `http://localhost:${process.env.PORT || 3000}`
};

const COOKIE_NAME = 'travlr_token';

/*
 * Safely reads JSON returned by the REST API.
 */
const readApiResponse = async (
  response
) => {
  const responseText =
    await response.text();

  if (!responseText) {
    return {};
  }

  try {
    return JSON.parse(
      responseText
    );
  } catch (error) {
    return {
      message: responseText
    };
  }
};

/*
 * Normalizes customer-submitted text.
 */
const normalizeText = (value) => {
  if (typeof value !== 'string') {
    return '';
  }

  return value.trim();
};

/*
 * Normalizes permanent trip, room, dining, and booking codes.
 */
const normalizeCode = (value) => {
  return normalizeText(value)
    .toUpperCase();
};

/*
 * Converts dining form values into an array.
 *
 * Express supplies one selected option as a string and multiple
 * selected options as an array.
 */
const normalizeDiningCodes = (
  value
) => {
  if (Array.isArray(value)) {
    return [
      ...new Set(
        value
          .map(normalizeCode)
          .filter(Boolean)
      )
    ];
  }

  const normalizedCode =
    normalizeCode(value);

  return normalizedCode
    ? [normalizedCode]
    : [];
};

/*
 * Redirects back to a trip page with a controlled booking error.
 */
const redirectToTripError = (
  res,
  tripCode,
  message
) => {
  const safeTripCode =
    tripCode || '';

  const encodedMessage =
    encodeURIComponent(
      message ||
      'The booking could not be completed.'
    );

  return res.redirect(
    `/travel/${encodeURIComponent(
      safeTripCode
    )}?bookingError=${encodedMessage}`
  );
};

/*
 * Creates a booking through the REST API for the signed-in customer.
 *
 * The customer email is not accepted from the browser. The API
 * retrieves it from the authenticated customer account.
 */
const createBooking = async (
  req,
  res
) => {
  const token =
    req.cookies?.[COOKIE_NAME];

  const tripCode =
    normalizeCode(
      req.params.tripCode
    );

  if (!token) {
    return res.redirect('/login');
  }

  if (!tripCode) {
    return res
      .status(400)
      .render(
        'error',
        {
          message:
            'Trip code is required.',

          error: {}
        }
      );
  }

  const bookingData = {
    tripCode,

    roomCode:
      normalizeCode(
        req.body.roomCode
      ),

    travelerCount:
      req.body.travelerCount,

    contactName:
      normalizeText(
        req.body.contactName
      ),

    contactPhone:
      normalizeText(
        req.body.contactPhone
      ),

    diningCodes:
      normalizeDiningCodes(
        req.body.diningCodes
      )
  };

  try {
    const bookingResponse =
      await fetch(
        `${apiOptions.server}/api/bookings`,
        {
          method: 'POST',

          headers: {
            Authorization:
              `Bearer ${token}`,

            'Content-Type':
              'application/json',

            Accept:
              'application/json'
          },

          body:
            JSON.stringify(
              bookingData
            )
        }
      );

    const bookingResult =
      await readApiResponse(
        bookingResponse
      );

    if (
      bookingResponse.status === 401 ||
      bookingResponse.status === 403
    ) {
      res.clearCookie(
        COOKIE_NAME,
        {
          httpOnly: true,
          sameSite: 'lax',
          secure:
            process.env.NODE_ENV ===
            'production'
        }
      );

      return res.redirect('/login');
    }

    if (!bookingResponse.ok) {
      return redirectToTripError(
        res,
        tripCode,
        bookingResult.message
      );
    }

    if (
      !bookingResult.bookingReference
    ) {
      return redirectToTripError(
        res,
        tripCode,
        'The booking was processed, but its reference could not be returned.'
      );
    }

    return res.redirect(
      `/account?bookingReference=${encodeURIComponent(
        bookingResult.bookingReference
      )}`
    );
  } catch (error) {
    console.error(
      'Public booking request failed:',
      error
    );

    return redirectToTripError(
      res,
      tripCode,
      'The booking service is currently unavailable.'
    );
  }
};

/*
 * Cancels one customer booking through the REST API.
 */
const cancelBooking = async (
  req,
  res
) => {
  const token =
    req.cookies?.[COOKIE_NAME];

  const bookingReference =
    normalizeCode(
      req.params.bookingReference
    );

  if (!token) {
    return res.redirect('/login');
  }

  if (!bookingReference) {
    return res
      .status(400)
      .render(
        'error',
        {
          message:
            'Booking reference is required.',

          error: {}
        }
      );
  }

  const cancellationReason =
    normalizeText(
      req.body.cancellationReason
    );

  try {
    const cancellationResponse =
      await fetch(
        `${apiOptions.server}/api/bookings/${encodeURIComponent(
          bookingReference
        )}/cancel`,
        {
          method: 'PATCH',

          headers: {
            Authorization:
              `Bearer ${token}`,

            'Content-Type':
              'application/json',

            Accept:
              'application/json'
          },

          body:
            JSON.stringify({
              cancellationReason
            })
        }
      );

    const cancellationResult =
      await readApiResponse(
        cancellationResponse
      );

    if (
      cancellationResponse.status ===
        401 ||
      cancellationResponse.status ===
        403
    ) {
      res.clearCookie(
        COOKIE_NAME,
        {
          httpOnly: true,
          sameSite: 'lax',
          secure:
            process.env.NODE_ENV ===
            'production'
        }
      );

      return res.redirect('/login');
    }

    if (!cancellationResponse.ok) {
      const encodedMessage =
        encodeURIComponent(
          cancellationResult.message ||
          'The booking could not be cancelled.'
        );

      return res.redirect(
        `/account?bookingError=${encodedMessage}`
      );
    }

    return res.redirect(
      `/account?cancelledReference=${encodeURIComponent(
        bookingReference
      )}`
    );
  } catch (error) {
    console.error(
      'Public booking cancellation failed:',
      error
    );

    return res.redirect(
      '/account?bookingError=' +
      encodeURIComponent(
        'The cancellation service is currently unavailable.'
      )
    );
  }
};

module.exports = {
  createBooking,
  cancelBooking
};