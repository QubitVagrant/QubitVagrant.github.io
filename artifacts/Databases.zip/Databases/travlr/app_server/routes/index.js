const express = require('express');
const router = express.Router();

const ctrlMain =
  require('../controllers/main');

const accountController =
  require('../controllers/account');

const bookingsController =
  require('../controllers/bookings');

const {
  requireCustomerLogin
} = require('../middleware/customer-auth');

/*
 * Displays the public homepage and informational pages.
 */
router.get(
  '/',
  ctrlMain.index
);

router.get(
  '/news',
  ctrlMain.news
);

/*
 * Displays one published Travel Blog article by its slug.
 */
router.get(
  '/news/:slug',
  ctrlMain.articleDetails
);

router.get(
  '/about',
  ctrlMain.about
);

/*
 * Displays and processes customer account registration.
 */
router.get(
  '/register',
  accountController.showRegister
);

router.post(
  '/register',
  accountController.register
);

/*
 * Displays and processes customer login.
 */
router.get(
  '/login',
  accountController.showLogin
);

router.post(
  '/login',
  accountController.login
);

/*
 * Requires a valid customer login before displaying account
 * information and booking history.
 */
router.get(
  '/account',
  requireCustomerLogin,
  accountController.account
);

/*
 * Creates a booking from the customer-facing trip-details form.
 */
router.post(
  '/travel/:tripCode/book',
  requireCustomerLogin,
  bookingsController.createBooking
);

/*
 * Cancels a booking belonging to the signed-in customer.
 */
router.post(
  '/account/bookings/:bookingReference/cancel',
  requireCustomerLogin,
  bookingsController.cancelBooking
);

/*
 * Removes the authentication cookie and signs the customer out.
 * POST is used because logging out changes the user's session state.
 */
router.post(
  '/logout',
  accountController.logout
);

module.exports = router;