import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Article } from '../models/article';

@Injectable({
  providedIn: 'root'
})
export class ArticleData {
  private readonly apiBaseUrl =
    'http://localhost:3000/api/articles';

  constructor(
    private readonly http: HttpClient
  ) {}

  /*
   * Retrieves every article for the administrator,
   * including drafts and published articles.
   */
  public getArticles(): Observable<Article[]> {
    return this.http.get<Article[]>(
      `${this.apiBaseUrl}/admin?cb=${Date.now()}`
    );
  }

  /*
   * Creates a new Travel Blog article.
   */
  public addArticle(
    formData: Article
  ): Observable<Article> {
    return this.http.post<Article>(
      this.apiBaseUrl,
      formData
    );
  }

  /*
   * Updates an article using its original slug.
   */
  public updateArticle(
    currentSlug: string,
    formData: Article
  ): Observable<Article> {
    const encodedSlug =
      encodeURIComponent(
        currentSlug.trim()
      );

    return this.http.put<Article>(
      `${this.apiBaseUrl}/${encodedSlug}`,
      formData
    );
  }

  /*
   * Deletes an article using its permanent slug.
   *
   * The API returns HTTP 204 with no response body.
   */
  public deleteArticle(
    slug: string
  ): Observable<void> {
    const encodedSlug =
      encodeURIComponent(
        slug.trim()
      );

    return this.http.delete<void>(
      `${this.apiBaseUrl}/${encodedSlug}`
    );
  }
}