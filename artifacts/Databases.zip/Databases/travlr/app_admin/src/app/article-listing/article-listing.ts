import {
  ChangeDetectorRef,
  Component,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

import {
  Article,
  ArticlePublicationStatus
} from '../models/article';

import { ArticleData } from '../services/article-data';
import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-article-listing',
  imports: [
    CommonModule
  ],
  templateUrl: './article-listing.html',
  styleUrl: './article-listing.css'
})
export class ArticleListing implements OnInit {
  articles: Article[] = [];

  message = '';
  errorMessage = '';
  loading = false;
  changingSlug = '';

  constructor(
    private readonly articleDataService: ArticleData,
    private readonly router: Router,
    private readonly cdr: ChangeDetectorRef,
    private readonly authenticationService: Authentication
  ) {}

  /*
   * Retrieves published and draft articles for the administrator.
   */
  private getArticles(): void {
    this.loading = true;
    this.errorMessage = '';

    this.articleDataService
      .getArticles()
      .subscribe({
        next: (articles: Article[]) => {
          this.articles = articles;
          this.loading = false;
          this.cdr.detectChanges();
        },

        error: (error: unknown) => {
          console.error(
            'ArticleData service error:',
            error
          );

          this.errorMessage =
            this.getErrorMessage(
              error,
              'Travel Blog articles could not be loaded.'
            );

          this.loading = false;
          this.cdr.detectChanges();
        }
      });
  }

  /*
   * Extracts a controlled API error message.
   */
  private getErrorMessage(
    error: unknown,
    fallbackMessage: string
  ): string {
    if (
      typeof error === 'object' &&
      error !== null &&
      'error' in error
    ) {
      const responseError =
        (
          error as {
            error?: {
              message?: unknown;
            };
          }
        ).error;

      if (
        typeof responseError?.message ===
        'string'
      ) {
        return responseError.message;
      }
    }

    return fallbackMessage;
  }

  public isLoggedIn(): boolean {
    return this.authenticationService
      .isLoggedIn();
  }

  /*
   * Opens the Add Article page.
   */
  public addArticle(): void {
    this.router.navigate([
      'add-article'
    ]);
  }

  /*
   * Opens the Edit Article page using the article slug.
   */
  public editArticle(
    article: Article
  ): void {
    this.router.navigate([
      'edit-article',
      article.slug
    ]);
  }

  /*
   * Publishes a draft or returns a published article to draft status.
   */
  public togglePublication(
    article: Article
  ): void {
    const nextStatus:
      ArticlePublicationStatus =
      article.publicationStatus ===
        'published'
        ? 'draft'
        : 'published';

    const updatedArticle: Article = {
      ...article,
      publicationStatus:
        nextStatus
    };

    this.message = '';
    this.errorMessage = '';
    this.changingSlug =
      article.slug;

    this.articleDataService
      .updateArticle(
        article.slug,
        updatedArticle
      )
      .subscribe({
        next: (savedArticle: Article) => {
          this.articles =
            this.articles.map(
              (currentArticle) =>
                currentArticle.slug ===
                article.slug
                  ? savedArticle
                  : currentArticle
            );

          this.message =
            nextStatus === 'published'
              ? `"${savedArticle.title}" was published.`
              : `"${savedArticle.title}" was moved to drafts.`;

          this.changingSlug = '';
          this.cdr.detectChanges();
        },

        error: (error: unknown) => {
          this.errorMessage =
            this.getErrorMessage(
              error,
              'The article status could not be changed.'
            );

          this.changingSlug = '';
          this.cdr.detectChanges();
        }
      });
  }

  /*
   * Deletes one article after administrator confirmation.
   */
  public deleteArticle(
    article: Article
  ): void {
    const confirmed =
      window.confirm(
        `Delete "${article.title}"? This action cannot be undone.`
      );

    if (!confirmed) {
      return;
    }

    this.message = '';
    this.errorMessage = '';
    this.changingSlug =
      article.slug;

    this.articleDataService
      .deleteArticle(
        article.slug
      )
      .subscribe({
        next: () => {
          this.articles =
            this.articles.filter(
              (currentArticle) =>
                currentArticle.slug !==
                article.slug
            );

          this.message =
            `"${article.title}" was deleted.`;

          this.changingSlug = '';
          this.cdr.detectChanges();
        },

        error: (error: unknown) => {
          this.errorMessage =
            this.getErrorMessage(
              error,
              'The article could not be deleted.'
            );

          this.changingSlug = '';
          this.cdr.detectChanges();
        }
      });
  }

  public ngOnInit(): void {
    this.getArticles();
  }
}