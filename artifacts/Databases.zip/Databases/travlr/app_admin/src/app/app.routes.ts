import { Routes } from '@angular/router';

import { TripListing } from './trip-listing/trip-listing';
import { AddTrip } from './add-trip/add-trip';
import { EditTrip } from './edit-trip/edit-trip';

import { ArticleListing } from './article-listing/article-listing';
import { AddArticle } from './add-article/add-article';
import { EditArticle } from './edit-article/edit-article';

import { Login } from './login/login';
import { adminGuard } from './utils/admin-guard';

/*
 * Starts the Angular employee portal on the login page.
 * All content-management pages require an administrator token.
 */
export const routes: Routes = [
  {
    path: 'login',
    component: Login
  },
  {
    path: 'trips',
    component: TripListing,
    canActivate: [adminGuard]
  },
  {
    path: 'add-trip',
    component: AddTrip,
    canActivate: [adminGuard]
  },
  {
    path: 'edit-trip/:tripCode',
    component: EditTrip,
    canActivate: [adminGuard]
  },
  {
    path: 'articles',
    component: ArticleListing,
    canActivate: [adminGuard]
  },
  {
    path: 'add-article',
    component: AddArticle,
    canActivate: [adminGuard]
  },
  {
    path: 'edit-article/:slug',
    component: EditArticle,
    canActivate: [adminGuard]
  },
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: 'login'
  }
];