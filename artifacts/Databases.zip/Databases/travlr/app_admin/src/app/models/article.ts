export type ArticlePublicationStatus =
  'draft' |
  'published';

/*
 * Represents one Travel Blog article returned by the Express API.
 */
export interface Article {
  _id?: string;

  title: string;
  slug: string;
  summary: string;
  content: string;
  image: string;
  category: string;

  publicationStatus:
    ArticlePublicationStatus;

  publishedAt:
    string | null;

  createdAt?: string;
  updatedAt?: string;
}