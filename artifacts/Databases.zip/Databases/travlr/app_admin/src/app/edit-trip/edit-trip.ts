import { HttpErrorResponse } from '@angular/common/http';
import { CommonModule } from '@angular/common';

import {
  Component,
  OnInit,
  signal
} from '@angular/core';

import {
  FormArray,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule
} from '@angular/forms';

import {
  ActivatedRoute,
  Router
} from '@angular/router';

import { finalize } from 'rxjs';

import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

import {
  createDiningOptionForm,
  createRoomTypeForm,
  createTripForm,
  getDiningOptionsArray,
  getRoomTypesArray,
  getTripApiErrorMessage,
  normalizeTripFormValue,
  populateTripForm
} from '../utils/trip-form';

@Component({
  selector: 'app-edit-trip',
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTrip implements OnInit {
  public editForm!: FormGroup;
  public tripCode = '';

  /*
   * Signals ensure asynchronous API results update the page
   * immediately after loading, updating, or deleting a trip.
   */
  public readonly formError =
    signal('');

  public readonly isLoading =
    signal(true);

  public readonly isSubmitting =
    signal(false);

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly tripDataService: TripData
  ) {}

  /*
   * Builds the expanded trip form and loads the selected trip.
   * Existing trips may retain a historical start date.
   */
  public ngOnInit(): void {
    this.editForm = createTripForm(
      this.formBuilder,
      {
        allowPastStartDate: true
      }
    );

    this.tripCode =
      this.route.snapshot.paramMap
        .get('tripCode')
        ?.trim() || '';

    if (!this.tripCode) {
      this.isLoading.set(false);

      this.formError.set(
        'A trip code was not provided.'
      );

      return;
    }

    this.loadTrip();
  }

  /*
   * Retrieves the selected trip and loads every field,
   * including location, rooms, dining, and availability.
   */
  private loadTrip(): void {
    this.formError.set('');
    this.isLoading.set(true);

    this.tripDataService
      .getTrip(this.tripCode)
      .pipe(
        finalize(() => {
          this.isLoading.set(false);
        })
      )
      .subscribe({
        next: (trip: Trip) => {
          populateTripForm(
            this.formBuilder,
            this.editForm,
            trip
          );
        },

        error: (
          error: HttpErrorResponse
        ) => {
          this.formError.set(
            getTripApiErrorMessage(
              error,
              'The trip could not be loaded.'
            )
          );
        }
      });
  }

  /*
   * Returns the room type collection from the trip form.
   */
  public get roomTypes(): FormArray {
    return getRoomTypesArray(
      this.editForm
    );
  }

  /*
   * Returns the dining option collection from the trip form.
   */
  public get diningOptions(): FormArray {
    return getDiningOptionsArray(
      this.editForm
    );
  }

  /*
   * Adds an empty room type editor.
   */
  public addRoomType(): void {
    this.roomTypes.push(
      createRoomTypeForm(
        this.formBuilder
      )
    );
  }

  /*
   * Removes one room type editor.
   */
  public removeRoomType(
    index: number
  ): void {
    this.roomTypes.removeAt(
      index
    );

    this.roomTypes.markAsDirty();
    this.roomTypes.updateValueAndValidity();
  }

  /*
   * Adds an empty dining option editor.
   */
  public addDiningOption(): void {
    this.diningOptions.push(
      createDiningOptionForm(
        this.formBuilder
      )
    );
  }

  /*
   * Removes one dining option editor.
   */
  public removeDiningOption(
    index: number
  ): void {
    this.diningOptions.removeAt(
      index
    );

    this.diningOptions.markAsDirty();
    this.diningOptions.updateValueAndValidity();
  }

  /*
   * Reports whether a control is invalid after the administrator
   * interacts with it.
   *
   * Nested controls may use paths such as:
   * location.city
   * roomTypes.0.code
   * diningOptions.0.name
   */
  public isInvalid(
    controlPath: string
  ): boolean {
    const control =
      this.editForm.get(
        controlPath
      );

    return Boolean(
      control &&
      control.invalid &&
      (
        control.touched ||
        control.dirty
      )
    );
  }

  /*
   * Reports whether a specific validation rule failed.
   */
  public hasError(
    controlPath: string,
    errorName: string
  ): boolean {
    const control =
      this.editForm.get(
        controlPath
      );

    return Boolean(
      control &&
      control.hasError(
        errorName
      ) &&
      (
        control.touched ||
        control.dirty
      )
    );
  }

  /*
   * Reports a validation error assigned to the complete trip form.
   */
  public hasFormError(
    errorName: string
  ): boolean {
    return Boolean(
      this.editForm.hasError(
        errorName
      ) &&
      (
        this.editForm.touched ||
        this.editForm.dirty
      )
    );
  }

  /*
   * Reports a validation error assigned to a FormArray.
   */
  public hasArrayError(
    arrayName:
      'roomTypes' |
      'diningOptions',
    errorName: string
  ): boolean {
    const array =
      this.editForm.get(
        arrayName
      );

    return Boolean(
      array &&
      array.hasError(
        errorName
      ) &&
      (
        array.touched ||
        array.dirty
      )
    );
  }

  /*
   * Validates and updates the selected trip using its original
   * trip code as the API identifier.
   */
  public onSubmit(): void {
    this.formError.set('');

    if (this.editForm.invalid) {
      this.editForm.markAllAsTouched();

      this.formError.set(
        'Correct the highlighted fields before saving the trip.'
      );

      return;
    }

    this.isSubmitting.set(true);

    const trip =
      normalizeTripFormValue(
        this.editForm.getRawValue()
      );

    this.tripDataService
      .updateTrip(
        this.tripCode,
        trip
      )
      .pipe(
        finalize(() => {
          this.isSubmitting.set(false);
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate([
            '/trips'
          ]);
        },

        error: (
          error: HttpErrorResponse
        ) => {
          this.formError.set(
            getTripApiErrorMessage(
              error,
              'The trip could not be updated. Please try again.'
            )
          );
        }
      });
  }

  /*
   * Confirms the destructive action before deleting the trip.
   */
  public onDelete(): void {
    const confirmed =
      window.confirm(
        `Delete ${this.tripCode}? ` +
        'This action cannot be undone.'
      );

    if (!confirmed) {
      return;
    }

    this.formError.set('');
    this.isSubmitting.set(true);

    this.tripDataService
      .deleteTrip(
        this.tripCode
      )
      .pipe(
        finalize(() => {
          this.isSubmitting.set(false);
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate([
            '/trips'
          ]);
        },

        error: (
          error: HttpErrorResponse
        ) => {
          this.formError.set(
            getTripApiErrorMessage(
              error,
              'The trip could not be deleted. Please try again.'
            )
          );
        }
      });
  }

  /*
   * Returns to the trip listing without saving.
   */
  public cancel(): void {
    this.router.navigate([
      '/trips'
    ]);
  }
}