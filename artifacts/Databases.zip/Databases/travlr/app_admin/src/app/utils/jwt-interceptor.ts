import {
  HttpErrorResponse,
  HttpInterceptorFn
} from '@angular/common/http';

import { inject } from '@angular/core';
import { Router } from '@angular/router';

import {
  catchError,
  throwError
} from 'rxjs';

import { Authentication } from '../services/authentication';

/*
 * Adds the administrator JWT to protected API requests.
 * A rejected or expired token clears the session and redirects
 * the administrator to the login page.
 */
export const jwtInterceptor: HttpInterceptorFn = (
  req,
  next
) => {
  const authenticationService =
    inject(Authentication);

  const router =
    inject(Router);

  const isAuthApi =
    req.url.includes('/login') ||
    req.url.includes('/register');

  const token =
    authenticationService.getToken();

  if (
    token &&
    authenticationService.isLoggedIn() &&
    !isAuthApi
  ) {
    req = req.clone({
      setHeaders: {
        Authorization:
          `Bearer ${token}`
      }
    });
  }

  return next(req).pipe(
    catchError(
      (
        error: HttpErrorResponse
      ) => {
        if (
          error.status === 401 &&
          !isAuthApi
        ) {
          authenticationService.logout();

          void router.navigate(
            ['/login'],
            {
              queryParams: {
                sessionExpired: 'true'
              }
            }
          );
        }

        return throwError(
          () => error
        );
      }
    )
  );
};