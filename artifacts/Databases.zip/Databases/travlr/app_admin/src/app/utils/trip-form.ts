import { HttpErrorResponse } from '@angular/common/http';

import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormGroup,
  ValidationErrors,
  ValidatorFn,
  Validators
} from '@angular/forms';

import {
  DiningOption,
  RoomType,
  Trip
} from '../models/trip';

interface TripFormOptions {
  allowPastStartDate?: boolean;
}

const imageFilenamePattern =
  /^[A-Za-z0-9._-]+\.(?:jpg|jpeg|png|webp)$/i;

const itemCodePattern =
  /^[A-Za-z0-9-]{2,20}$/;

/*
 * Confirms that a supplied value can be parsed as a real date.
 */
const validDateValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
  if (!control.value) {
    return null;
  }

  const date = new Date(
    String(control.value)
  );

  return Number.isNaN(date.getTime())
    ? { invalidDate: true }
    : null;
};

/*
 * Prevents a newly created trip from using a date before today.
 */
const todayOrFutureValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
  if (!control.value) {
    return null;
  }

  const selectedDate =
    String(control.value).substring(
      0,
      10
    );

  const today = new Date();

  const currentDate = [
    today.getFullYear(),

    String(
      today.getMonth() + 1
    ).padStart(2, '0'),

    String(
      today.getDate()
    ).padStart(2, '0')
  ].join('-');

  return selectedDate < currentDate
    ? { pastDate: true }
    : null;
};

/*
 * Requires numeric fields to contain whole numbers.
 */
const integerValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
  if (
    control.value === null ||
    control.value === undefined ||
    control.value === ''
  ) {
    return null;
  }

  const value =
    Number(control.value);

  return Number.isInteger(value)
    ? null
    : { integer: true };
};

/*
 * Prevents duplicate room or dining codes inside one trip.
 */
const uniqueItemCodesValidator: ValidatorFn = (
  control: AbstractControl
): ValidationErrors | null => {
  if (!(control instanceof FormArray)) {
    return null;
  }

  const codes =
    control.controls
      .map((itemControl) =>
        String(
          itemControl.get('code')?.value ||
            ''
        )
          .trim()
          .toUpperCase()
      )
      .filter(
        (code) =>
          code.length > 0
      );

  return new Set(codes).size ===
    codes.length
    ? null
    : { duplicateCodes: true };
};

/*
 * Creates one room type editor.
 *
 * maxGuests controls how many travelers one room can hold.
 * availableUnits controls how many rooms can still be booked.
 */
export const createRoomTypeForm = (
  formBuilder: FormBuilder,
  room?: Partial<RoomType>
): FormGroup => {
  return formBuilder.group({
    code: [
      room?.code || '',
      [
        Validators.required,
        Validators.pattern(
          itemCodePattern
        )
      ]
    ],

    name: [
      room?.name || '',
      [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(80)
      ]
    ],

    description: [
      room?.description || '',
      [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(500)
      ]
    ],

    image: [
      room?.image || '',
      [
        Validators.required,
        Validators.maxLength(120),
        Validators.pattern(
          imageFilenamePattern
        )
      ]
    ],

    nightlyRate: [
      room?.nightlyRate ?? '',
      [
        Validators.required,
        Validators.min(0)
      ]
    ],

    maxGuests: [
      room?.maxGuests ?? '',
      [
        Validators.required,
        Validators.min(1),
        integerValidator
      ]
    ],

    availableUnits: [
      room?.availableUnits ?? '',
      [
        Validators.required,
        Validators.min(0),
        integerValidator
      ]
    ]
  });
};

/*
 * Creates one dining option editor.
 */
export const createDiningOptionForm = (
  formBuilder: FormBuilder,
  diningOption?: Partial<DiningOption>
): FormGroup => {
  return formBuilder.group({
    code: [
      diningOption?.code || '',
      [
        Validators.required,
        Validators.pattern(
          itemCodePattern
        )
      ]
    ],

    name: [
      diningOption?.name || '',
      [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(80)
      ]
    ],

    restaurantName: [
      diningOption?.restaurantName || '',
      [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(120)
      ]
    ],

    description: [
      diningOption?.description || '',
      [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(500)
      ]
    ],

    pricePerPerson: [
      diningOption?.pricePerPerson ?? '',
      [
        Validators.required,
        Validators.min(0)
      ]
    ],

    included: [
      diningOption?.included ?? false
    ]
  });
};

/*
 * Creates the shared form used by Add Trip and Edit Trip.
 */
export const createTripForm = (
  formBuilder: FormBuilder,
  options: TripFormOptions = {}
): FormGroup => {
  const startValidators: ValidatorFn[] = [
    Validators.required,
    validDateValidator
  ];

  if (!options.allowPastStartDate) {
    startValidators.push(
      todayOrFutureValidator
    );
  }

  return formBuilder.group({
    code: [
      '',
      [
        Validators.required,
        Validators.maxLength(20),
        Validators.pattern(
          /^[A-Za-z0-9-]{3,20}$/
        )
      ]
    ],

    name: [
      '',
      [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(80)
      ]
    ],

    length: [
      '',
      [
        Validators.required,
        Validators.maxLength(40),
        Validators.pattern(
          /^\d+\s+nights?\s*\/\s*\d+\s+days?$/i
        )
      ]
    ],

    start: [
      '',
      startValidators
    ],

    resort: [
      '',
      [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(120)
      ]
    ],

    location: formBuilder.group({
      city: [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(80)
        ]
      ],

      stateOrRegion: [
        '',
        [
          Validators.maxLength(80)
        ]
      ],

      country: [
        '',
        [
          Validators.required,
          Validators.minLength(2),
          Validators.maxLength(80)
        ]
      ]
    }),

    perPerson: [
      '',
      [
        Validators.required,
        Validators.min(0)
      ]
    ],

    image: [
      '',
      [
        Validators.required,
        Validators.maxLength(120),
        Validators.pattern(
          imageFilenamePattern
        )
      ]
    ],

    /*
     * Gallery filenames are entered one per line.
     */
    gallery: [
      ''
    ],

    description: [
      '',
      [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(1000)
      ]
    ],

    details: [
      '',
      [
        Validators.required,
        Validators.minLength(20),
        Validators.maxLength(5000)
      ]
    ],

    roomTypes: formBuilder.array(
      [],
      {
        validators: [
          uniqueItemCodesValidator
        ]
      }
    ),

    diningOptions: formBuilder.array(
      [],
      {
        validators: [
          uniqueItemCodesValidator
        ]
      }
    )
  });
};

/*
 * Returns the room type FormArray from a trip form.
 */
export const getRoomTypesArray = (
  form: FormGroup
): FormArray => {
  return form.get(
    'roomTypes'
  ) as FormArray;
};

/*
 * Returns the dining option FormArray from a trip form.
 */
export const getDiningOptionsArray = (
  form: FormGroup
): FormArray => {
  return form.get(
    'diningOptions'
  ) as FormArray;
};

/*
 * Loads an existing trip into the shared edit form.
 */
export const populateTripForm = (
  formBuilder: FormBuilder,
  form: FormGroup,
  trip: Trip
): void => {
  form.patchValue({
    code:
      trip.code,

    name:
      trip.name,

    length:
      trip.length,

    start:
      String(
        trip.start || ''
      ).substring(0, 10),

    resort:
      trip.resort,

    location: {
      city:
        trip.location?.city || '',

      stateOrRegion:
        trip.location
          ?.stateOrRegion || '',

      country:
        trip.location?.country || ''
    },

    perPerson:
      trip.perPerson,

    image:
      trip.image,

    gallery:
      Array.isArray(
        trip.gallery
      )
        ? trip.gallery.join('\n')
        : '',

    description:
      trip.description,

    details:
      trip.details || ''
  });

  const roomTypes =
    getRoomTypesArray(form);

  roomTypes.clear();

  for (
    const room of
    trip.roomTypes || []
  ) {
    roomTypes.push(
      createRoomTypeForm(
        formBuilder,
        room
      )
    );
  }

  const diningOptions =
    getDiningOptionsArray(form);

  diningOptions.clear();

  for (
    const option of
    trip.diningOptions || []
  ) {
    diningOptions.push(
      createDiningOptionForm(
        formBuilder,
        option
      )
    );
  }
};

/*
 * Converts an unknown object into a record that can be read safely.
 */
const asRecord = (
  value: unknown
): Record<string, unknown> => {
  if (
    typeof value === 'object' &&
    value !== null &&
    !Array.isArray(value)
  ) {
    return value as Record<
      string,
      unknown
    >;
  }

  return {};
};

/*
 * Converts a form value into a valid numeric value.
 */
const toNumber = (
  value: unknown
): number => {
  const numericValue =
    Number(value);

  return Number.isFinite(
    numericValue
  )
    ? numericValue
    : 0;
};

/*
 * Trims text fields, normalizes codes, and converts numeric fields
 * before the completed form is sent to the API.
 */
export const normalizeTripFormValue = (
  value: Record<string, unknown>
): Trip => {
  const location =
    asRecord(
      value['location']
    );

  const roomTypes =
    Array.isArray(
      value['roomTypes']
    )
      ? value['roomTypes']
      : [];

  const diningOptions =
    Array.isArray(
      value['diningOptions']
    )
      ? value['diningOptions']
      : [];

  const gallery =
    String(
      value['gallery'] ?? ''
    )
      .split(/\r?\n|,/)
      .map(
        (image) =>
          image.trim()
      )
      .filter(
        (image) =>
          image.length > 0
      );

  return {
    code:
      String(
        value['code'] ?? ''
      )
        .trim()
        .toUpperCase(),

    name:
      String(
        value['name'] ?? ''
      ).trim(),

    length:
      String(
        value['length'] ?? ''
      ).trim(),

    start:
      String(
        value['start'] ?? ''
      ).trim(),

    resort:
      String(
        value['resort'] ?? ''
      ).trim(),

    location: {
      city:
        String(
          location['city'] ?? ''
        ).trim(),

      stateOrRegion:
        String(
          location[
            'stateOrRegion'
          ] ?? ''
        ).trim(),

      country:
        String(
          location['country'] ?? ''
        ).trim()
    },

    perPerson:
      toNumber(
        value['perPerson']
      ),

    image:
      String(
        value['image'] ?? ''
      ).trim(),

    gallery,

    description:
      String(
        value['description'] ?? ''
      ).trim(),

    details:
      String(
        value['details'] ?? ''
      ).trim(),

    roomTypes:
      roomTypes.map(
        (
          roomValue
        ): RoomType => {
          const room =
            asRecord(
              roomValue
            );

          return {
            code:
              String(
                room['code'] ?? ''
              )
                .trim()
                .toUpperCase(),

            name:
              String(
                room['name'] ?? ''
              ).trim(),

            description:
              String(
                room[
                  'description'
                ] ?? ''
              ).trim(),

            image:
              String(
                room['image'] ?? ''
              ).trim(),

            nightlyRate:
              toNumber(
                room[
                  'nightlyRate'
                ]
              ),

            maxGuests:
              toNumber(
                room[
                  'maxGuests'
                ]
              ),

            availableUnits:
              toNumber(
                room[
                  'availableUnits'
                ]
              )
          };
        }
      ),

    diningOptions:
      diningOptions.map(
        (
          diningValue
        ): DiningOption => {
          const dining =
            asRecord(
              diningValue
            );

          return {
            code:
              String(
                dining['code'] ?? ''
              )
                .trim()
                .toUpperCase(),

            name:
              String(
                dining['name'] ?? ''
              ).trim(),

            restaurantName:
              String(
                dining[
                  'restaurantName'
                ] ?? ''
              ).trim(),

            description:
              String(
                dining[
                  'description'
                ] ?? ''
              ).trim(),

            pricePerPerson:
              toNumber(
                dining[
                  'pricePerPerson'
                ]
              ),

            included:
              Boolean(
                dining['included']
              )
          };
        }
      )
  };
};

/*
 * Converts API failures into messages administrators can understand
 * without exposing internal database information.
 */
export const getTripApiErrorMessage = (
  error: HttpErrorResponse,
  fallbackMessage: string
): string => {
  const response = error.error as
    | {
        message?: string;
        fields?: string[];
        errors?: Record<
          string,
          string
        >;
      }
    | string
    | null;

  if (
    typeof response === 'string' &&
    response.trim()
  ) {
    return response;
  }

  if (
    response &&
    typeof response === 'object'
  ) {
    if (response.errors) {
      const details =
        Object.values(
          response.errors
        );

      if (details.length > 0) {
        return details.join(' ');
      }
    }

    if (response.message) {
      if (
        response.fields &&
        response.fields.length > 0
      ) {
        return (
          `${response.message} ` +
          `Fields: ${response.fields.join(', ')}.`
        );
      }

      return response.message;
    }
  }

  if (error.status === 0) {
    return (
      'The API is unavailable. ' +
      'Confirm the Express server is running.'
    );
  }

  if (error.status === 401) {
    return (
      'Your session has expired. Sign in again.'
    );
  }

  if (error.status === 403) {
    return (
      'Administrator access is required.'
    );
  }

  return fallbackMessage;
};