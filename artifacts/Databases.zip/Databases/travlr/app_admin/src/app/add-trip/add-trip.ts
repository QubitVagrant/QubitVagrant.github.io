import { HttpErrorResponse } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';

import {
  FormArray,
  FormBuilder,
  FormGroup,
  ReactiveFormsModule
} from '@angular/forms';

import { Router } from '@angular/router';
import { finalize } from 'rxjs';

import { TripData } from '../services/trip-data';

import {
  createDiningOptionForm,
  createRoomTypeForm,
  createTripForm,
  getDiningOptionsArray,
  getRoomTypesArray,
  getTripApiErrorMessage,
  normalizeTripFormValue
} from '../utils/trip-form';

@Component({
  selector: 'app-add-trip',
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css'
})
export class AddTrip implements OnInit {
  public addForm!: FormGroup;
  public formError = '';
  public isSubmitting = false;

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly tripDataService: TripData,
    private readonly router: Router
  ) {}

  /*
   * Builds the expanded Add Trip form.
   * New trips must use today's date or a future start date.
   */
  public ngOnInit(): void {
    this.addForm = createTripForm(
      this.formBuilder,
      {
        allowPastStartDate: false
      }
    );
  }

  /*
   * Returns the room type collection from the trip form.
   */
  public get roomTypes(): FormArray {
    return getRoomTypesArray(
      this.addForm
    );
  }

  /*
   * Returns the dining option collection from the trip form.
   */
  public get diningOptions(): FormArray {
    return getDiningOptionsArray(
      this.addForm
    );
  }

  /*
   * Adds an empty room type editor.
   */
  public addRoomType(): void {
    this.roomTypes.push(
      createRoomTypeForm(
        this.formBuilder
      )
    );
  }

  /*
   * Removes one room type editor.
   */
  public removeRoomType(
    index: number
  ): void {
    this.roomTypes.removeAt(
      index
    );

    this.roomTypes.markAsDirty();
    this.roomTypes.updateValueAndValidity();
  }

  /*
   * Adds an empty dining option editor.
   */
  public addDiningOption(): void {
    this.diningOptions.push(
      createDiningOptionForm(
        this.formBuilder
      )
    );
  }

  /*
   * Removes one dining option editor.
   */
  public removeDiningOption(
    index: number
  ): void {
    this.diningOptions.removeAt(
      index
    );

    this.diningOptions.markAsDirty();
    this.diningOptions.updateValueAndValidity();
  }

  /*
   * Reports whether a control is invalid after the administrator
   * interacts with it or attempts to submit the form.
   *
   * Nested controls may use paths such as:
   * location.city
   * roomTypes.0.code
   * diningOptions.0.name
   */
  public isInvalid(
    controlPath: string
  ): boolean {
    const control =
      this.addForm.get(
        controlPath
      );

    return Boolean(
      control &&
      control.invalid &&
      (
        control.touched ||
        control.dirty
      )
    );
  }

  /*
   * Reports whether a specific validation rule failed.
   */
  public hasError(
    controlPath: string,
    errorName: string
  ): boolean {
    const control =
      this.addForm.get(
        controlPath
      );

    return Boolean(
      control &&
      control.hasError(
        errorName
      ) &&
      (
        control.touched ||
        control.dirty
      )
    );
  }

  /*
   * Reports a validation error assigned to the complete trip form.
   */
  public hasFormError(
    errorName: string
  ): boolean {
    return Boolean(
      this.addForm.hasError(
        errorName
      ) &&
      (
        this.addForm.touched ||
        this.addForm.dirty
      )
    );
  }

  /*
   * Reports a validation error assigned to a FormArray.
   */
  public hasArrayError(
    arrayName: 'roomTypes' | 'diningOptions',
    errorName: string
  ): boolean {
    const array =
      this.addForm.get(
        arrayName
      );

    return Boolean(
      array &&
      array.hasError(
        errorName
      ) &&
      (
        array.touched ||
        array.dirty
      )
    );
  }

  /*
   * Validates and normalizes the expanded trip before sending it
   * to the API.
   */
  public onSubmit(): void {
    this.formError = '';

    if (this.addForm.invalid) {
      this.addForm.markAllAsTouched();

      this.formError =
        'Correct the highlighted fields before saving the trip.';

      return;
    }

    this.isSubmitting = true;

    const trip =
      normalizeTripFormValue(
        this.addForm.getRawValue()
      );

    this.tripDataService
      .addTrip(trip)
      .pipe(
        finalize(() => {
          this.isSubmitting = false;
        })
      )
      .subscribe({
        next: () => {
          this.router.navigate([
            '/trips'
          ]);
        },

        error: (
          error: HttpErrorResponse
        ) => {
          this.formError =
            getTripApiErrorMessage(
              error,
              'The trip could not be added. Please try again.'
            );
        }
      });
  }

  /*
   * Returns to the trip listing without saving.
   */
  public cancel(): void {
    this.router.navigate([
      '/trips'
    ]);
  }
}