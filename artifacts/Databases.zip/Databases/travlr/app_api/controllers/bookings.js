const crypto = require('crypto');

const Booking =
  require('../models/booking');

const Trip =
  require('../models/travlr');

const User =
  require('../models/user');

const MAX_TRAVELERS = 12;
const CANCELLATION_WINDOW_DAYS = 7;

const DAY_IN_MILLISECONDS =
  24 * 60 * 60 * 1000;

const tripCodePattern =
  /^[A-Za-z0-9-]{3,20}$/;

const roomCodePattern =
  /^[A-Za-z0-9-]{2,20}$/;

const emailPattern =
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const phonePattern =
  /^[0-9+().\-\s]{7,20}$/;

/*
 * Converts stored and submitted codes to one consistent format.
 */
const normalizeCode = (value) => {
  if (typeof value !== 'string') {
    return '';
  }

  return value
    .trim()
    .toUpperCase();
};

/*
 * Trims customer-entered text fields.
 */
const normalizeText = (value) => {
  if (typeof value !== 'string') {
    return '';
  }

  return value.trim();
};

/*
 * Converts and validates the requested number of travelers.
 */
const getTravelerCount = (value) => {
  const travelerCount =
    Number(value);

  if (
    !Number.isInteger(
      travelerCount
    ) ||
    travelerCount < 1 ||
    travelerCount > MAX_TRAVELERS
  ) {
    return null;
  }

  return travelerCount;
};

/*
 * Extracts the number of nights from values such as:
 * 4 nights / 5 days
 */
const getTripNightCount = (
  length
) => {
  if (typeof length !== 'string') {
    return null;
  }

  const match =
    length.match(
      /^(\d+)\s+nights?/i
    );

  if (!match) {
    return null;
  }

  const nights =
    Number(match[1]);

  return (
    Number.isInteger(nights) &&
    nights > 0
  )
    ? nights
    : null;
};

/*
 * Generates a readable booking reference without exposing
 * the MongoDB document identifier.
 */
const generateBookingReference = () => {
  const timestamp =
    Date.now()
      .toString(36)
      .toUpperCase();

  const randomCode =
    crypto
      .randomBytes(4)
      .toString('hex')
      .toUpperCase();

  return (
    `TVL-${timestamp}-${randomCode}`
  );
};

/*
 * Validates and normalizes booking form data before any
 * room availability or price calculations occur.
 */
const validateBookingInput = (
  body = {}
) => {
  const errors = {};

  const tripCode =
    normalizeCode(
      body.tripCode
    );

  const roomCode =
    normalizeCode(
      body.roomCode
    );

  const travelerCount =
    getTravelerCount(
      body.travelerCount
    );

  const contactName =
    normalizeText(
      body.contactName
    );

  const contactPhone =
    normalizeText(
      body.contactPhone
    );

  if (
    !tripCodePattern.test(
      tripCode
    )
  ) {
    errors.tripCode =
      'A valid trip code is required.';
  }

  if (
    !roomCodePattern.test(
      roomCode
    )
  ) {
    errors.roomCode =
      'A valid room type is required.';
  }

  if (!travelerCount) {
    errors.travelerCount =
      `Traveler count must be a whole number between 1 and ${MAX_TRAVELERS}.`;
  }

  if (
    contactName.length < 2 ||
    contactName.length > 120
  ) {
    errors.contactName =
      'Contact name must contain between 2 and 120 characters.';
  }

  if (
    !phonePattern.test(
      contactPhone
    )
  ) {
    errors.contactPhone =
      'A valid contact phone number is required.';
  }

  let diningCodes = [];

  if (
    body.diningCodes !== undefined
  ) {
    const submittedDiningCodes =
      Array.isArray(
        body.diningCodes
      )
        ? body.diningCodes
        : [body.diningCodes];

    diningCodes = [
      ...new Set(
        submittedDiningCodes
          .map(normalizeCode)
          .filter(Boolean)
      )
    ];
  }

  if (
    Object.keys(
      errors
    ).length > 0
  ) {
    return {
      error: {
        message:
          'Booking validation failed.',

        errors
      }
    };
  }

  return {
    data: {
      tripCode,
      roomCode,
      travelerCount,
      contactName,
      contactPhone,
      diningCodes
    }
  };
};

/*
 * Converts database failures into controlled API responses.
 */
const handleDatabaseError = (
  res,
  error
) => {
  if (
    error.name ===
      'ValidationError'
  ) {
    const errors =
      Object.fromEntries(
        Object.entries(
          error.errors
        ).map(
          ([
            field,
            details
          ]) => [
            field,
            details.message
          ]
        )
      );

    return res
      .status(400)
      .json({
        message:
          'Booking validation failed.',

        errors
      });
  }

  if (
    error.name ===
      'CastError'
  ) {
    return res
      .status(400)
      .json({
        message:
          'The booking request contains an invalid identifier.'
      });
  }

  if (error.code === 11000) {
    return res
      .status(409)
      .json({
        message:
          'A booking reference conflict occurred. Please submit the booking again.'
      });
  }

  console.error(
    'Booking controller error:',
    error
  );

  return res
    .status(500)
    .json({
      message:
        'An unexpected server error occurred.'
    });
};

/*
 * Restores booked rooms after a failed booking write
 * or a successful cancellation.
 */
const restoreRoomAvailability =
  async ({
    tripId,
    roomCode,
    roomQuantity
  }) => {
    return Trip
      .findOneAndUpdate(
        {
          _id:
            tripId,

          roomTypes: {
            $elemMatch: {
              code:
                roomCode
            }
          }
        },
        {
          $inc: {
            'roomTypes.$[selectedRoom].availableUnits':
              roomQuantity
          }
        },
        {
          arrayFilters: [
            {
              'selectedRoom.code':
                roomCode
            }
          ],

          returnDocument:
            'after',

          runValidators:
            true
        }
      )
      .exec();
  };

/*
 * Creates a booking for the authenticated customer.
 *
 * Prices are calculated using trusted trip data from MongoDB.
 * The contact email is read from the authenticated user record.
 *
 * Only room inventory is changed. The number of rooms required
 * is calculated from travelerCount and maxGuests.
 */
const bookingsCreate = async (
  req,
  res
) => {
  const customerId =
    req.user?._id;

  if (!customerId) {
    return res
      .status(401)
      .json({
        message:
          'Authentication is required.'
      });
  }

  const validation =
    validateBookingInput(
      req.body
    );

  if (validation.error) {
    return res
      .status(400)
      .json(
        validation.error
      );
  }

  const bookingInput =
    validation.data;

  try {
    const customer =
      await User
        .findById(
          customerId
        )
        .select('email')
        .lean()
        .exec();

    if (!customer) {
      return res
        .status(401)
        .json({
          message:
            'The authenticated customer account was not found.'
        });
    }

    const contactEmail =
      normalizeText(
        customer.email
      ).toLowerCase();

    if (
      contactEmail.length > 254 ||
      !emailPattern.test(
        contactEmail
      )
    ) {
      return res
        .status(500)
        .json({
          message:
            'The customer account email is not configured correctly.'
        });
    }

    const trip =
      await Trip
        .findOne({
          code:
            bookingInput.tripCode
        })
        .lean()
        .exec();

    if (!trip) {
      return res
        .status(404)
        .json({
          message:
            'Trip code was not found.'
        });
    }

    const startDate =
      new Date(
        trip.start
      );

    if (
      Number.isNaN(
        startDate.getTime()
      ) ||
      startDate <= new Date()
    ) {
      return res
        .status(409)
        .json({
          message:
            'Bookings are closed for this trip.'
        });
    }

    const roomTypes =
      Array.isArray(
        trip.roomTypes
      )
        ? trip.roomTypes
        : [];

    const room =
      roomTypes.find(
        (roomType) =>
          normalizeCode(
            roomType.code
          ) === bookingInput.roomCode
      );

    if (!room) {
      return res
        .status(400)
        .json({
          message:
            'The selected room type is not available for this trip.'
        });
    }

    const maxGuests =
      Number(
        room.maxGuests
      );

    if (
      !Number.isInteger(
        maxGuests
      ) ||
      maxGuests < 1
    ) {
      return res
        .status(500)
        .json({
          message:
            'The selected room occupancy is not configured correctly.'
        });
    }

    /*
     * One room is reserved for each complete or partial group
     * that fits within maxGuests.
     *
     * With a maximum of 2 guests per room:
     * 1-2 travelers require 1 room.
     * 3-4 travelers require 2 rooms.
     */
    const roomQuantity =
      Math.ceil(
        bookingInput.travelerCount /
        maxGuests
      );

    const nights =
      getTripNightCount(
        trip.length
      );

    if (!nights) {
      return res
        .status(500)
        .json({
          message:
            'The trip duration is not configured correctly.'
        });
    }

    const diningOptions =
      Array.isArray(
        trip.diningOptions
      )
        ? trip.diningOptions
        : [];

    const requestedDiningOptions =
      bookingInput.diningCodes.map(
        (diningCode) =>
          diningOptions.find(
            (option) =>
              normalizeCode(
                option.code
              ) === diningCode
          )
      );

    if (
      requestedDiningOptions.some(
        (option) =>
          !option
      )
    ) {
      return res
        .status(400)
        .json({
          message:
            'One or more selected dining options are not available for this trip.'
        });
    }

    /*
     * Included dining options are added automatically.
     * Customer-selected upgrades are added without duplicates.
     */
    const selectedDiningMap =
      new Map();

    diningOptions
      .filter(
        (option) =>
          option.included
      )
      .forEach(
        (option) => {
          selectedDiningMap.set(
            normalizeCode(
              option.code
            ),
            option
          );
        }
      );

    requestedDiningOptions
      .forEach(
        (option) => {
          selectedDiningMap.set(
            normalizeCode(
              option.code
            ),
            option
          );
        }
      );

    const selectedDiningOptions = [
      ...selectedDiningMap.values()
    ];

    /*
     * All prices are calculated on the server.
     */
    const baseTripTotal =
      Number(
        trip.perPerson
      ) *
      bookingInput.travelerCount;

    const roomUpgradeTotal =
      Number(
        room.nightlyRate
      ) *
      nights *
      roomQuantity;

    const diningTotal =
      selectedDiningOptions.reduce(
        (
          total,
          option
        ) =>
          total +
          Number(
            option.pricePerPerson
          ) *
          bookingInput.travelerCount,

        0
      );

    const totalPrice =
      baseTripTotal +
      roomUpgradeTotal +
      diningTotal;

    /*
     * This atomic update succeeds only when the selected
     * room type still has enough available rooms.
     */
    const reservedTrip =
      await Trip
        .findOneAndUpdate(
          {
            _id:
              trip._id,

            roomTypes: {
              $elemMatch: {
                code:
                  room.code,

                availableUnits: {
                  $gte:
                    roomQuantity
                }
              }
            }
          },
          {
            $inc: {
              'roomTypes.$[selectedRoom].availableUnits':
                -roomQuantity
            }
          },
          {
            arrayFilters: [
              {
                'selectedRoom.code':
                  room.code
              }
            ],

            returnDocument:
              'after',

            runValidators:
              true
          }
        )
        .exec();

    if (!reservedTrip) {
      return res
        .status(409)
        .json({
          message:
            'The selected room type no longer has enough rooms available.'
        });
    }

    try {
      const booking =
        await Booking.create({
          bookingReference:
            generateBookingReference(),

          customer:
            customerId,

          trip:
            trip._id,

          tripCode:
            trip.code,

          tripName:
            trip.name,

          resort:
            trip.resort,

          location: {
            city:
              trip.location.city,

            stateOrRegion:
              trip.location
                .stateOrRegion || '',

            country:
              trip.location.country
          },

          startDate:
            trip.start,

          travelerCount:
            bookingInput.travelerCount,

          contactName:
            bookingInput.contactName,

          contactEmail,

          contactPhone:
            bookingInput.contactPhone,

          room: {
            code:
              room.code,

            name:
              room.name,

            nightlyRate:
              Number(
                room.nightlyRate
              ),

            quantity:
              roomQuantity,

            maxGuests
          },

          diningOptions:
            selectedDiningOptions.map(
              (option) => ({
                code:
                  option.code,

                name:
                  option.name,

                restaurantName:
                  option.restaurantName,

                pricePerPerson:
                  Number(
                    option.pricePerPerson
                  ),

                included:
                  option.included
              })
            ),

          pricing: {
            baseTripTotal,
            roomUpgradeTotal,
            diningTotal,
            totalPrice,
            currency:
              'USD'
          }
        });

      return res
        .status(201)
        .json(
          booking
        );
    } catch (error) {
      /*
       * Restore reserved rooms if the booking document cannot
       * be saved.
       */
      await restoreRoomAvailability({
        tripId:
          trip._id,

        roomCode:
          room.code,

        roomQuantity
      });

      throw error;
    }
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Returns all bookings belonging to the authenticated customer.
 */
const bookingsListForCustomer =
  async (
    req,
    res
  ) => {
    const customerId =
      req.user?._id;

    if (!customerId) {
      return res
        .status(401)
        .json({
          message:
            'Authentication is required.'
        });
    }

    try {
      const bookings =
        await Booking
          .find({
            customer:
              customerId
          })
          .sort({
            createdAt:
              -1
          })
          .exec();

      return res
        .status(200)
        .json(
          bookings
        );
    } catch (error) {
      return handleDatabaseError(
        res,
        error
      );
    }
  };

/*
 * Cancels a confirmed booking belonging to the authenticated
 * customer and restores the rooms reserved by the booking.
 */
const bookingsCancel = async (
  req,
  res
) => {
  const customerId =
    req.user?._id;

  const bookingReference =
    normalizeCode(
      req.params.bookingReference
    );

  const cancellationReason =
    normalizeText(
      req.body?.cancellationReason
    );

  if (!customerId) {
    return res
      .status(401)
      .json({
        message:
          'Authentication is required.'
      });
  }

  if (!bookingReference) {
    return res
      .status(400)
      .json({
        message:
          'Booking reference is required.'
      });
  }

  if (
    cancellationReason.length > 500
  ) {
    return res
      .status(400)
      .json({
        message:
          'Cancellation reason cannot exceed 500 characters.'
      });
  }

  try {
    const booking =
      await Booking
        .findOne({
          bookingReference,

          customer:
            customerId
        })
        .lean()
        .exec();

    if (!booking) {
      return res
        .status(404)
        .json({
          message:
            'Booking was not found.'
        });
    }

    if (
      booking.status ===
        'cancelled'
    ) {
      return res
        .status(409)
        .json({
          message:
            'This booking is already cancelled.'
        });
    }

    const cancellationDeadline =
      new Date(
        booking.startDate
      ).getTime() -
      CANCELLATION_WINDOW_DAYS *
      DAY_IN_MILLISECONDS;

    if (
      Date.now() >=
      cancellationDeadline
    ) {
      return res
        .status(409)
        .json({
          message:
            `Bookings must be cancelled at least ${CANCELLATION_WINDOW_DAYS} days before departure.`
        });
    }

    /*
     * The confirmed-status condition prevents simultaneous
     * cancellation requests from restoring rooms twice.
     */
    const cancelledBooking =
      await Booking
        .findOneAndUpdate(
          {
            _id:
              booking._id,

            status:
              'confirmed'
          },
          {
            $set: {
              status:
                'cancelled',

              cancelledAt:
                new Date(),

              cancellationReason
            }
          },
          {
            returnDocument:
              'after',

            runValidators:
              true
          }
        )
        .exec();

    if (!cancelledBooking) {
      return res
        .status(409)
        .json({
          message:
            'The booking status changed before the cancellation completed.'
        });
    }

    try {
      const restoredTrip =
        await restoreRoomAvailability({
          tripId:
            booking.trip,

          roomCode:
            booking.room.code,

          roomQuantity:
            booking.room.quantity
        });

      if (!restoredTrip) {
        throw new Error(
          'The trip room inventory was not available for restoration.'
        );
      }
    } catch (error) {
      /*
       * Restore confirmed status if room inventory cannot
       * be returned successfully.
       */
      await Booking
        .findOneAndUpdate(
          {
            _id:
              booking._id,

            status:
              'cancelled'
          },
          {
            $set: {
              status:
                'confirmed',

              cancelledAt:
                null,

              cancellationReason:
                ''
            }
          },
          {
            returnDocument:
              'after',

            runValidators:
              true
          }
        )
        .exec();

      throw error;
    }

    return res
      .status(200)
      .json(
        cancelledBooking
      );
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

module.exports = {
  bookingsCreate,
  bookingsListForCustomer,
  bookingsCancel
};