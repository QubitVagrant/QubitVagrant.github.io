const Article = require('../models/article');

const slugPattern =
  /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

const ARTICLE_STATUSES = [
  'draft',
  'published'
];

/*
 * Trims submitted text.
 */
const normalizeText = (value) => {
  if (typeof value !== 'string') {
    return '';
  }

  return value.trim();
};

/*
 * Converts a submitted slug or title into a URL-safe slug.
 */
const normalizeSlug = (value) => {
  return normalizeText(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
};

/*
 * Safely converts an optional publication date.
 */
const normalizePublishedAt = (value) => {
  if (!value) {
    return null;
  }

  const date = new Date(value);

  return Number.isNaN(date.getTime())
    ? null
    : date;
};

/*
 * Validates and normalizes article data before it is written
 * to MongoDB.
 */
const validateArticleInput = (
  body = {},
  existingArticle = null
) => {
  const errors = {};

  const title = normalizeText(
    body.title
  );

  const submittedSlug =
    normalizeText(body.slug);

  const slug = normalizeSlug(
    submittedSlug || title
  );

  const summary = normalizeText(
    body.summary
  );

  const content = normalizeText(
    body.content
  );

  const image = normalizeText(
    body.image
  );

  const category = normalizeText(
    body.category
  );

  const publicationStatus =
    normalizeText(
      body.publicationStatus
    ).toLowerCase() || 'draft';

  if (
    title.length < 3 ||
    title.length > 160
  ) {
    errors.title =
      'Article title must contain between 3 and 160 characters.';
  }

  if (
    !slugPattern.test(slug) ||
    slug.length > 180
  ) {
    errors.slug =
      'Article slug must contain lowercase letters, numbers, and hyphens.';
  }

  if (
    summary.length < 10 ||
    summary.length > 500
  ) {
    errors.summary =
      'Article summary must contain between 10 and 500 characters.';
  }

  if (
    content.length < 20 ||
    content.length > 20000
  ) {
    errors.content =
      'Article content must contain between 20 and 20,000 characters.';
  }

  if (image.length > 255) {
    errors.image =
      'Article image path cannot exceed 255 characters.';
  }

  if (
    category.length < 2 ||
    category.length > 80
  ) {
    errors.category =
      'Article category must contain between 2 and 80 characters.';
  }

  if (
    !ARTICLE_STATUSES.includes(
      publicationStatus
    )
  ) {
    errors.publicationStatus =
      'Article status must be draft or published.';
  }

  if (
    Object.keys(errors).length > 0
  ) {
    return {
      error: {
        message:
          'Article validation failed.',
        errors
      }
    };
  }

  let publishedAt =
    normalizePublishedAt(
      body.publishedAt
    );

  if (
    publicationStatus ===
      'published' &&
    !publishedAt
  ) {
    publishedAt =
      existingArticle?.publishedAt ||
      new Date();
  }

  if (
    publicationStatus === 'draft' &&
    existingArticle?.publishedAt
  ) {
    publishedAt =
      existingArticle.publishedAt;
  }

  return {
    data: {
      title,
      slug,
      summary,
      content,
      image,
      category,
      publicationStatus,
      publishedAt
    }
  };
};

/*
 * Converts database failures into controlled API responses.
 */
const handleDatabaseError = (
  res,
  error
) => {
  if (
    error.name === 'ValidationError'
  ) {
    const errors = Object.fromEntries(
      Object.entries(
        error.errors
      ).map(
        ([field, details]) => [
          field,
          details.message
        ]
      )
    );

    return res.status(400).json({
      message:
        'Article validation failed.',
      errors
    });
  }

  if (error.code === 11000) {
    return res.status(409).json({
      message:
        'An article already uses that slug.'
    });
  }

  console.error(
    'Article controller error:',
    error
  );

  return res.status(500).json({
    message:
      'An unexpected server error occurred.'
  });
};

/*
 * Returns published Travel Blog articles for the public website.
 */
const articlesListPublished = async (
  req,
  res
) => {
  const category = normalizeText(
    req.query.category
  );

  const query = {
    publicationStatus: 'published'
  };

  if (category) {
    query.category = category;
  }

  try {
    const articles =
      await Article.find(query)
        .sort({
          publishedAt: -1,
          createdAt: -1
        })
        .lean()
        .exec();

    return res
      .status(200)
      .json(articles);
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Returns one published article by its permanent slug.
 */
const articlesFindPublishedBySlug =
  async (
    req,
    res
  ) => {
    const slug = normalizeSlug(
      req.params.slug
    );

    if (!slugPattern.test(slug)) {
      return res.status(400).json({
        message:
          'A valid article slug is required.'
      });
    }

    try {
      const article =
        await Article.findOne({
          slug,
          publicationStatus:
            'published'
        })
          .lean()
          .exec();

      if (!article) {
        return res.status(404).json({
          message:
            'Article was not found.'
        });
      }

      return res
        .status(200)
        .json(article);
    } catch (error) {
      return handleDatabaseError(
        res,
        error
      );
    }
  };

/*
 * Returns every article, including drafts, for the administrator.
 */
const articlesListAll = async (
  req,
  res
) => {
  try {
    const articles =
      await Article.find({})
        .sort({
          updatedAt: -1,
          createdAt: -1
        })
        .lean()
        .exec();

    return res
      .status(200)
      .json(articles);
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Creates one Travel Blog article for the administrator.
 */
const articlesAddArticle = async (
  req,
  res
) => {
  const validation =
    validateArticleInput(
      req.body
    );

  if (validation.error) {
    return res.status(400).json(
      validation.error
    );
  }

  try {
    const article =
      await Article.create(
        validation.data
      );

    return res
      .status(201)
      .json(article);
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Updates one article by its current permanent slug.
 */
const articlesUpdateArticle = async (
  req,
  res
) => {
  const currentSlug = normalizeSlug(
    req.params.slug
  );

  if (
    !slugPattern.test(
      currentSlug
    )
  ) {
    return res.status(400).json({
      message:
        'A valid article slug is required.'
    });
  }

  try {
    const existingArticle =
      await Article.findOne({
        slug: currentSlug
      }).exec();

    if (!existingArticle) {
      return res.status(404).json({
        message:
          'Article was not found.'
      });
    }

    const validation =
      validateArticleInput(
        req.body,
        existingArticle
      );

    if (validation.error) {
      return res.status(400).json(
        validation.error
      );
    }

    Object.assign(
      existingArticle,
      validation.data
    );

    const updatedArticle =
      await existingArticle.save();

    return res
      .status(200)
      .json(updatedArticle);
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Deletes one article by its permanent slug.
 */
const articlesDeleteArticle = async (
  req,
  res
) => {
  const slug = normalizeSlug(
    req.params.slug
  );

  if (!slugPattern.test(slug)) {
    return res.status(400).json({
      message:
        'A valid article slug is required.'
    });
  }

  try {
    const deletedArticle =
      await Article.findOneAndDelete({
        slug
      })
        .lean()
        .exec();

    if (!deletedArticle) {
      return res.status(404).json({
        message:
          'Article was not found.'
      });
    }

    return res.status(204).send();
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

module.exports = {
  articlesListPublished,
  articlesFindPublishedBySlug,
  articlesListAll,
  articlesAddArticle,
  articlesUpdateArticle,
  articlesDeleteArticle
};