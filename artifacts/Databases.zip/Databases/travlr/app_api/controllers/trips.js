const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

const {
  rankTrips
} = require('../utils/trip-recommendation');

const tripCodePattern =
  /^[A-Za-z0-9-]{3,20}$/;

const roomCodePattern =
  /^[A-Za-z0-9-]{2,20}$/;

const tripLengthPattern =
  /^\d+\s+nights?\s*\/\s*\d+\s+days?$/i;

const tripPricePattern =
  /^\d+(?:\.\d{1,2})?$/;

const imageFilenamePattern =
  /^[A-Za-z0-9._-]+\.(?:jpg|jpeg|png|webp)$/i;

/*
 * Reports whether a required value is missing.
 */
const isMissing = (value) =>
  value === undefined ||
  value === null ||
  value === '';

/*
 * Trims text while preserving non-string values for validation.
 */
const normalizeText = (value) =>
  typeof value === 'string'
    ? value.trim()
    : value;

/*
 * Converts submitted numeric values into JavaScript numbers.
 */
const normalizeNumber = (value) => {
  if (isMissing(value)) {
    return value;
  }

  return Number(
    String(value).trim()
  );
};

/*
 * Converts checkbox and API values into booleans.
 */
const normalizeBoolean = (value) => {
  if (typeof value === 'boolean') {
    return value;
  }

  if (typeof value === 'string') {
    return (
      value
        .trim()
        .toLowerCase() === 'true'
    );
  }

  return Boolean(value);
};

/*
 * Normalizes a trip code into its stored uppercase format.
 */
const normalizeTripCode = (value) => {
  if (typeof value !== 'string') {
    return '';
  }

  return value
    .trim()
    .toUpperCase();
};

/*
 * Normalizes gallery filenames.
 */
const normalizeGallery = (value) => {
  if (
    value === undefined ||
    value === null
  ) {
    return [];
  }

  if (typeof value === 'string') {
    return value
      .split(/\r?\n|,/)
      .map(
        (image) =>
          image.trim()
      )
      .filter(Boolean);
  }

  if (!Array.isArray(value)) {
    return value;
  }

  return value
    .map(
      (image) =>
        normalizeText(image)
    )
    .filter(Boolean);
};

/*
 * Normalizes room types before validation and storage.
 *
 * maxGuests is the maximum number of travelers allowed
 * in one room.
 *
 * availableUnits is the number of rooms currently available.
 */
const normalizeRoomTypes = (value) => {
  if (
    value === undefined ||
    value === null
  ) {
    return [];
  }

  if (!Array.isArray(value)) {
    return value;
  }

  return value.map(
    (roomValue) => {
      const room =
        roomValue &&
        typeof roomValue === 'object' &&
        !Array.isArray(roomValue)
          ? roomValue
          : {};

      return {
        code:
          typeof room.code === 'string'
            ? room.code
                .trim()
                .toUpperCase()
            : room.code,

        name:
          normalizeText(
            room.name
          ),

        description:
          normalizeText(
            room.description
          ),

        image:
          normalizeText(
            room.image
          ),

        nightlyRate:
          normalizeNumber(
            room.nightlyRate
          ),

        maxGuests:
          normalizeNumber(
            room.maxGuests
          ),

        availableUnits:
          normalizeNumber(
            room.availableUnits
          )
      };
    }
  );
};

/*
 * Normalizes dining options before validation and storage.
 */
const normalizeDiningOptions = (
  value
) => {
  if (
    value === undefined ||
    value === null
  ) {
    return [];
  }

  if (!Array.isArray(value)) {
    return value;
  }

  return value.map(
    (optionValue) => {
      const option =
        optionValue &&
        typeof optionValue === 'object' &&
        !Array.isArray(optionValue)
          ? optionValue
          : {};

      return {
        code:
          typeof option.code === 'string'
            ? option.code
                .trim()
                .toUpperCase()
            : option.code,

        name:
          normalizeText(
            option.name
          ),

        restaurantName:
          normalizeText(
            option.restaurantName
          ),

        description:
          normalizeText(
            option.description
          ),

        pricePerPerson:
          normalizeNumber(
            option.pricePerPerson
          ),

        included:
          normalizeBoolean(
            option.included
          )
      };
    }
  );
};

/*
 * Normalizes every field used by the expanded Angular editor.
 */
const normalizeTripInput = (
  body = {}
) => {
  const location =
    body.location &&
    typeof body.location === 'object' &&
    !Array.isArray(body.location)
      ? body.location
      : {};

  return {
    code:
      normalizeTripCode(
        body.code
      ),

    name:
      normalizeText(
        body.name
      ),

    length:
      normalizeText(
        body.length
      ),

    start:
      normalizeText(
        body.start
      ),

    resort:
      normalizeText(
        body.resort
      ),

    location: {
      city:
        normalizeText(
          location.city
        ),

      stateOrRegion:
        normalizeText(
          location.stateOrRegion
        ) || '',

      country:
        normalizeText(
          location.country
        )
    },

    perPerson:
      normalizeNumber(
        body.perPerson
      ),

    image:
      normalizeText(
        body.image
      ),

    gallery:
      normalizeGallery(
        body.gallery
      ),

    description:
      normalizeText(
        body.description
      ),

    details:
      normalizeText(
        body.details
      ),

    roomTypes:
      normalizeRoomTypes(
        body.roomTypes
      ),

    diningOptions:
      normalizeDiningOptions(
        body.diningOptions
      )
  };
};

/*
 * Returns today's local date in YYYY-MM-DD format.
 */
const getTodayDateString = () => {
  const today = new Date();

  return [
    today.getFullYear(),

    String(
      today.getMonth() + 1
    ).padStart(2, '0'),

    String(
      today.getDate()
    ).padStart(2, '0')
  ].join('-');
};

/*
 * Validates a supplied date and returns its YYYY-MM-DD value.
 */
const getValidDateString = (
  value
) => {
  if (isMissing(value)) {
    return null;
  }

  const text =
    String(value).trim();

  const dateMatch = text.match(
    /^(\d{4})-(\d{2})-(\d{2})(?:T.*)?$/
  );

  if (dateMatch) {
    const year =
      Number(dateMatch[1]);

    const month =
      Number(dateMatch[2]);

    const day =
      Number(dateMatch[3]);

    const calendarDate =
      new Date(
        Date.UTC(
          year,
          month - 1,
          day
        )
      );

    const isValidCalendarDate =
      calendarDate.getUTCFullYear() ===
        year &&
      calendarDate.getUTCMonth() ===
        month - 1 &&
      calendarDate.getUTCDate() ===
        day;

    if (!isValidCalendarDate) {
      return null;
    }

    if (
      text.length > 10 &&
      Number.isNaN(
        new Date(text).getTime()
      )
    ) {
      return null;
    }

    return [
      String(year).padStart(
        4,
        '0'
      ),

      String(month).padStart(
        2,
        '0'
      ),

      String(day).padStart(
        2,
        '0'
      )
    ].join('-');
  }

  const parsedDate =
    new Date(text);

  if (
    Number.isNaN(
      parsedDate.getTime()
    )
  ) {
    return null;
  }

  return parsedDate
    .toISOString()
    .substring(0, 10);
};

/*
 * Reports duplicate codes within one embedded option collection.
 */
const hasDuplicateCodes = (
  items
) => {
  const codes =
    items.map(
      (item) =>
        String(
          item?.code || ''
        )
          .trim()
          .toUpperCase()
    );

  return (
    new Set(codes).size !==
    codes.length
  );
};

/*
 * Validates room inventory and occupancy settings.
 */
const validateRoomTypes = (
  roomTypes,
  errors
) => {
  if (!Array.isArray(roomTypes)) {
    errors.roomTypes =
      'Room types must be supplied as an array.';

    return;
  }

  if (roomTypes.length < 1) {
    errors.roomTypes =
      'At least one room type is required.';

    return;
  }

  if (
    hasDuplicateCodes(
      roomTypes
    )
  ) {
    errors.roomTypes =
      'Room type codes must be unique within a trip.';
  }

  roomTypes.forEach(
    (room, index) => {
      const fieldPrefix =
        `roomTypes.${index}`;

      if (
        typeof room.code !==
          'string' ||
        !roomCodePattern.test(
          room.code
        )
      ) {
        errors[
          `${fieldPrefix}.code`
        ] =
          'Room code must contain 2-20 letters, numbers, or hyphens.';
      }

      if (
        typeof room.name !==
          'string' ||
        room.name.length < 2 ||
        room.name.length > 80
      ) {
        errors[
          `${fieldPrefix}.name`
        ] =
          'Room name must contain between 2 and 80 characters.';
      }

      if (
        typeof room.description !==
          'string' ||
        room.description.length < 10 ||
        room.description.length > 1000
      ) {
        errors[
          `${fieldPrefix}.description`
        ] =
          'Room description must contain between 10 and 1,000 characters.';
      }

      if (
        typeof room.image !==
          'string' ||
        room.image.length > 120 ||
        !imageFilenamePattern.test(
          room.image
        )
      ) {
        errors[
          `${fieldPrefix}.image`
        ] =
          'Room image must be a valid JPG, JPEG, PNG, or WebP filename.';
      }

      const nightlyRateText =
        String(
          room.nightlyRate
        );

      if (
        !Number.isFinite(
          room.nightlyRate
        ) ||
        room.nightlyRate < 0 ||
        !tripPricePattern.test(
          nightlyRateText
        )
      ) {
        errors[
          `${fieldPrefix}.nightlyRate`
        ] =
          'Nightly rate must be a nonnegative number with no more than two decimal places.';
      }

      if (
        !Number.isInteger(
          room.maxGuests
        ) ||
        room.maxGuests < 1
      ) {
        errors[
          `${fieldPrefix}.maxGuests`
        ] =
          'Maximum guests per room must be a whole number of at least 1.';
      }

      if (
        !Number.isInteger(
          room.availableUnits
        ) ||
        room.availableUnits < 0
      ) {
        errors[
          `${fieldPrefix}.availableUnits`
        ] =
          'Available rooms must be a nonnegative whole number.';
      }
    }
  );
};

/*
 * Validates the complete expanded trip object.
 */
const validateTripInput = (
  trip,
  options = {}
) => {
  const {
    allowPastStartDate = true
  } = options;

  const missingFields = [];

  const requiredFields = [
    'code',
    'name',
    'length',
    'start',
    'resort',
    'perPerson',
    'image',
    'description',
    'details'
  ];

  requiredFields.forEach(
    (field) => {
      if (
        isMissing(
          trip[field]
        )
      ) {
        missingFields.push(
          field
        );
      }
    }
  );

  if (
    isMissing(
      trip.location?.city
    )
  ) {
    missingFields.push(
      'location.city'
    );
  }

  if (
    isMissing(
      trip.location?.country
    )
  ) {
    missingFields.push(
      'location.country'
    );
  }

  if (
    missingFields.length > 0
  ) {
    return {
      message:
        'All required trip fields must be completed.',

      fields:
        missingFields
    };
  }

  const errors = {};

  if (
    !tripCodePattern.test(
      trip.code
    )
  ) {
    errors.code =
      'Trip code must contain 3-20 letters, numbers, or hyphens.';
  }

  if (
    typeof trip.name !==
      'string' ||
    trip.name.length < 3 ||
    trip.name.length > 80
  ) {
    errors.name =
      'Trip name must contain between 3 and 80 characters.';
  }

  if (
    !tripLengthPattern.test(
      trip.length
    )
  ) {
    errors.length =
      'Trip length must use a format such as 4 nights / 5 days.';
  } else if (
    trip.length.length > 40
  ) {
    errors.length =
      'Trip length cannot exceed 40 characters.';
  }

  const startDate =
    getValidDateString(
      trip.start
    );

  if (!startDate) {
    errors.start =
      'Start date must be a valid date.';
  } else if (
    !allowPastStartDate &&
    startDate <
      getTodayDateString()
  ) {
    errors.start =
      'Start date cannot be in the past.';
  }

  if (
    typeof trip.resort !==
      'string' ||
    trip.resort.length < 3 ||
    trip.resort.length > 120
  ) {
    errors.resort =
      'Resort information must contain between 3 and 120 characters.';
  }

  if (
    typeof trip.location.city !==
      'string' ||
    trip.location.city.length < 2 ||
    trip.location.city.length > 80
  ) {
    errors['location.city'] =
      'City must contain between 2 and 80 characters.';
  }

  if (
    typeof trip.location
      .stateOrRegion !==
      'string' ||
    trip.location
      .stateOrRegion.length > 80
  ) {
    errors[
      'location.stateOrRegion'
    ] =
      'State or region cannot exceed 80 characters.';
  }

  if (
    typeof trip.location.country !==
      'string' ||
    trip.location.country.length < 2 ||
    trip.location.country.length > 80
  ) {
    errors['location.country'] =
      'Country must contain between 2 and 80 characters.';
  }

  const priceText =
    String(
      trip.perPerson
    );

  if (
    !Number.isFinite(
      trip.perPerson
    ) ||
    trip.perPerson < 0 ||
    !tripPricePattern.test(
      priceText
    )
  ) {
    errors.perPerson =
      'Price per person must be a nonnegative number with no more than two decimal places.';
  }

  if (
    typeof trip.image !==
      'string' ||
    trip.image.length > 120 ||
    !imageFilenamePattern.test(
      trip.image
    )
  ) {
    errors.image =
      'Image must be a valid JPG, JPEG, PNG, or WebP filename.';
  }

  if (
    !Array.isArray(
      trip.gallery
    )
  ) {
    errors.gallery =
      'Gallery must be an array of image filenames.';
  } else if (
    trip.gallery.some(
      (image) =>
        typeof image !==
          'string' ||
        image.length > 120 ||
        !imageFilenamePattern.test(
          image
        )
    )
  ) {
    errors.gallery =
      'Gallery images must use valid JPG, JPEG, PNG, or WebP filenames.';
  }

  if (
    typeof trip.description !==
      'string' ||
    trip.description.length < 10 ||
    trip.description.length > 1000
  ) {
    errors.description =
      'Description must contain between 10 and 1,000 characters.';
  }

  if (
    typeof trip.details !==
      'string' ||
    trip.details.length < 20 ||
    trip.details.length > 5000
  ) {
    errors.details =
      'Trip details must contain between 20 and 5,000 characters.';
  }

  validateRoomTypes(
    trip.roomTypes,
    errors
  );

  if (
    !Array.isArray(
      trip.diningOptions
    )
  ) {
    errors.diningOptions =
      'Dining options must be supplied as an array.';
  }

  if (
    Object.keys(
      errors
    ).length > 0
  ) {
    return {
      message:
        'Trip validation failed.',

      errors
    };
  }

  return null;
};

/*
 * Converts database failures into controlled API responses.
 */
const handleDatabaseError = (
  res,
  error
) => {
  if (
    error.name ===
      'ValidationError'
  ) {
    const errors =
      Object.fromEntries(
        Object.entries(
          error.errors
        ).map(
          ([
            field,
            details
          ]) => [
            field,
            details.message
          ]
        )
      );

    return res
      .status(400)
      .json({
        message:
          'Trip validation failed.',

        errors
      });
  }

  if (
    error.code === 11000
  ) {
    return res
      .status(409)
      .json({
        message:
          'A trip with that code already exists.'
      });
  }

  console.error(
    'Trip controller error:',
    error
  );

  return res
    .status(500)
    .json({
      message:
        'An unexpected server error occurred.'
    });
};

/*
 * Returns the complete trip list.
 */
const tripsList = async (
  req,
  res
) => {
  try {
    const trips =
      await Trip
        .find({})
        .exec();

    return res
      .status(200)
      .json(trips);
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Returns ranked trip recommendations.
 */
const tripsRecommend = async (
  req,
  res
) => {
  const preferences = {
    maximumPrice:
      req.query.maximumPrice,

    resort:
      req.query.resort,

    startDate:
      req.query.startDate,

    length:
      req.query.length
  };

  const hasPreference =
    Object.values(
      preferences
    ).some(
      (value) =>
        value !== undefined &&
        value !== null &&
        String(value)
          .trim() !== ''
    );

  if (!hasPreference) {
    return res
      .status(400)
      .json({
        message:
          'Provide at least one preference to receive trip recommendations.'
      });
  }

  try {
    const trips =
      await Trip
        .find({})
        .lean()
        .exec();

    const rankedTrips =
      rankTrips(
        trips,
        preferences
      )
        .filter(
          (result) =>
            result.score > 0
        )
        .map(
          (result) => ({
            trip:
              result.trip,

            score:
              result.score,

            matchReasons:
              result.matchReasons
          })
        );

    return res
      .status(200)
      .json({
        preferences,

        count:
          rankedTrips.length,

        recommendations:
          rankedTrips
      });
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Retrieves one trip using its permanent code.
 */
const tripsFindCode = async (
  req,
  res
) => {
  const tripCode =
    normalizeTripCode(
      req.params.tripCode
    );

  if (!tripCode) {
    return res
      .status(400)
      .json({
        message:
          'Trip code is required.'
      });
  }

  try {
    const trip =
      await Trip
        .findOne({
          code:
            tripCode
        })
        .exec();

    if (!trip) {
      return res
        .status(404)
        .json({
          message:
            'Trip code was not found.'
        });
    }

    return res
      .status(200)
      .json(trip);
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Creates a new expanded trip record.
 */
const tripsAddTrip = async (
  req,
  res
) => {
  const tripData =
    normalizeTripInput(
      req.body
    );

  const validationError =
    validateTripInput(
      tripData,
      {
        allowPastStartDate:
          false
      }
    );

  if (validationError) {
    return res
      .status(400)
      .json(
        validationError
      );
  }

  try {
    const savedTrip =
      await Trip.create(
        tripData
      );

    return res
      .status(201)
      .json(
        savedTrip
      );
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Updates every editable trip field.
 */
const tripsUpdateTrip = async (
  req,
  res
) => {
  const tripCode =
    normalizeTripCode(
      req.params.tripCode
    );

  if (!tripCode) {
    return res
      .status(400)
      .json({
        message:
          'Trip code is required.'
      });
  }

  const submittedCode =
    normalizeTripCode(
      req.body?.code
    );

  if (
    submittedCode &&
    submittedCode !== tripCode
  ) {
    return res
      .status(400)
      .json({
        message:
          'Trip code cannot be changed after the trip is created.',

        fields: [
          'code'
        ]
      });
  }

  const tripData =
    normalizeTripInput({
      ...req.body,

      code:
        tripCode
    });

  const validationError =
    validateTripInput(
      tripData,
      {
        allowPastStartDate:
          true
      }
    );

  if (validationError) {
    return res
      .status(400)
      .json(
        validationError
      );
  }

  const updatableTripData = {
    ...tripData
  };

  delete updatableTripData.code;

  try {
    const trip =
      await Trip
        .findOne({
          code:
            tripCode
        })
        .exec();

    if (!trip) {
      return res
        .status(404)
        .json({
          message:
            'Trip code was not found.'
        });
    }

    /*
     * Saving the Mongoose document ensures nested room,
     * dining, and image validators run.
     */
    trip.set(
      updatableTripData
    );

    const updatedTrip =
      await trip.save();

    return res
      .status(200)
      .json(
        updatedTrip
      );
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

/*
 * Deletes a trip using its permanent code.
 */
const tripsDeleteTrip = async (
  req,
  res
) => {
  const tripCode =
    normalizeTripCode(
      req.params.tripCode
    );

  if (!tripCode) {
    return res
      .status(400)
      .json({
        message:
          'Trip code is required.'
      });
  }

  try {
    const deletedTrip =
      await Trip
        .findOneAndDelete({
          code:
            tripCode
        })
        .exec();

    if (!deletedTrip) {
      return res
        .status(404)
        .json({
          message:
            'Trip code was not found.'
        });
    }

    return res
      .status(200)
      .json({
        message:
          'Trip deleted successfully.'
      });
  } catch (error) {
    return handleDatabaseError(
      res,
      error
    );
  }
};

module.exports = {
  tripsList,
  tripsRecommend,
  tripsFindCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};