const mongoose = require('mongoose');

const slugPattern =
  /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

/*
 * Stores one Travel Blog article in MongoDB.
 */
const articleSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: true,
      trim: true,
      minlength: 3,
      maxlength: 160
    },

    slug: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
      maxlength: 180,
      validate: {
        validator: (value) =>
          slugPattern.test(value),

        message:
          'Article slug may contain lowercase letters, numbers, and hyphens.'
      }
    },

    summary: {
      type: String,
      required: true,
      trim: true,
      minlength: 10,
      maxlength: 500
    },

    content: {
      type: String,
      required: true,
      trim: true,
      minlength: 20,
      maxlength: 20000
    },

    image: {
      type: String,
      trim: true,
      maxlength: 255,
      default: ''
    },

    category: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 80
    },

    publicationStatus: {
      type: String,
      enum: [
        'draft',
        'published'
      ],
      default: 'draft',
      required: true,
      index: true
    },

    publishedAt: {
      type: Date,
      default: null
    }
  },
  {
    timestamps: true
  }
);

/*
 * Assigns a publication date the first time an article is
 * published.
 */
articleSchema.pre(
  'validate',
  function setPublishedDate() {
    if (
      this.publicationStatus ===
        'published' &&
      !this.publishedAt
    ) {
      this.publishedAt =
        new Date();
    }
  }
);

/*
 * Supports public article-list queries ordered by publication date.
 */
articleSchema.index({
  publicationStatus: 1,
  publishedAt: -1
});

/*
 * Supports filtering articles by category.
 */
articleSchema.index({
  category: 1,
  publicationStatus: 1
});

const Article = mongoose.model(
  'articles',
  articleSchema
);

module.exports = Article;