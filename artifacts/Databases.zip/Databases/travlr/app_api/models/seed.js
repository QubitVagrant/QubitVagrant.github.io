require('dotenv').config();

const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

const Trip = require('./travlr');
const Article = require('./article');

const host =
  process.env.DB_HOST || '127.0.0.1';

const dbURI =
  `mongodb://${host}/travlr`;

const tripsPath = path.join(
  __dirname,
  '..',
  '..',
  'app_server',
  'data',
  'trips.json'
);

const articlesPath = path.join(
  __dirname,
  '..',
  '..',
  'app_server',
  'data',
  'articles.json'
);

const trips = JSON.parse(
  fs.readFileSync(
    tripsPath,
    'utf8'
  )
);

const articles = JSON.parse(
  fs.readFileSync(
    articlesPath,
    'utf8'
  )
);

/*
 * Confirms that duplicate trip codes do not exist before creating
 * the unique trip-code index.
 */
const verifyUniqueTripCodes =
  async () => {
    const duplicates =
      await Trip.aggregate([
        {
          $group: {
            _id: '$code',
            count: {
              $sum: 1
            }
          }
        },
        {
          $match: {
            count: {
              $gt: 1
            }
          }
        }
      ]);

    if (duplicates.length > 0) {
      const duplicateCodes =
        duplicates
          .map(
            (item) =>
              item._id
          )
          .join(', ');

      throw new Error(
        `Duplicate trip codes must be resolved: ${duplicateCodes}`
      );
    }
  };

/*
 * Confirms that duplicate article slugs do not exist before creating
 * the unique article-slug index.
 */
const verifyUniqueArticleSlugs =
  async () => {
    const duplicates =
      await Article.aggregate([
        {
          $group: {
            _id: '$slug',
            count: {
              $sum: 1
            }
          }
        },
        {
          $match: {
            count: {
              $gt: 1
            }
          }
        }
      ]);

    if (duplicates.length > 0) {
      const duplicateSlugs =
        duplicates
          .map(
            (item) =>
              item._id
          )
          .join(', ');

      throw new Error(
        `Duplicate article slugs must be resolved: ${duplicateSlugs}`
      );
    }
  };

/*
 * Replaces a previous non-unique trip-code index with the unique
 * index defined by the current Trip schema.
 */
const synchronizeTripIndexes =
  async () => {
    const indexes =
      await Trip.collection.indexes();

    const existingCodeIndex =
      indexes.find(
        (index) =>
          index.name === 'code_1'
      );

    if (
      existingCodeIndex &&
      existingCodeIndex.unique !== true
    ) {
      await Trip.collection.dropIndex(
        'code_1'
      );

      console.log(
        'Removed legacy non-unique trip code index'
      );
    }

    await Trip.syncIndexes();

    console.log(
      'Trip indexes synchronized'
    );
  };

/*
 * Replaces a previous non-unique article-slug index with the unique
 * index defined by the current Article schema.
 */
const synchronizeArticleIndexes =
  async () => {
    const indexes =
      await Article.collection.indexes();

    const existingSlugIndex =
      indexes.find(
        (index) =>
          index.name === 'slug_1'
      );

    if (
      existingSlugIndex &&
      existingSlugIndex.unique !== true
    ) {
      await Article.collection.dropIndex(
        'slug_1'
      );

      console.log(
        'Removed legacy non-unique article slug index'
      );
    }

    await Article.syncIndexes();

    console.log(
      'Article indexes synchronized'
    );
  };

/*
 * Updates existing trips by their stable code and inserts trips that
 * do not already exist. Trips not listed in trips.json are not deleted.
 */
const seedTrips = async () => {
  let insertedCount = 0;
  let updatedCount = 0;

  for (const trip of trips) {
    const existingTrip =
      await Trip.exists({
        code: trip.code
      });

    const result =
      await Trip.findOneAndUpdate(
        {
          code: trip.code
        },
        {
          $set: trip
        },
        {
          returnDocument: 'after',
          upsert: true,
          runValidators: true,
          setDefaultsOnInsert: true
        }
      );

    if (existingTrip) {
      updatedCount += 1;

      console.log(
        `Updated trip ${result.code}: ${result.name}`
      );
    } else {
      insertedCount += 1;

      console.log(
        `Inserted trip ${result.code}: ${result.name}`
      );
    }
  }

  await verifyUniqueTripCodes();
  await synchronizeTripIndexes();

  const totalCount =
    await Trip.countDocuments();

  return {
    insertedCount,
    updatedCount,
    totalCount
  };
};

/*
 * Updates existing articles by their stable slug and inserts articles
 * that do not already exist. Other database articles are not deleted.
 */
const seedArticles = async () => {
  let insertedCount = 0;
  let updatedCount = 0;

  for (const article of articles) {
    const existingArticle =
      await Article.exists({
        slug: article.slug
      });

    const result =
      await Article.findOneAndUpdate(
        {
          slug: article.slug
        },
        {
          $set: article
        },
        {
          returnDocument: 'after',
          upsert: true,
          runValidators: true,
          setDefaultsOnInsert: true
        }
      );

    if (existingArticle) {
      updatedCount += 1;

      console.log(
        `Updated article ${result.slug}: ${result.title}`
      );
    } else {
      insertedCount += 1;

      console.log(
        `Inserted article ${result.slug}: ${result.title}`
      );
    }
  }

  await verifyUniqueArticleSlugs();
  await synchronizeArticleIndexes();

  const totalCount =
    await Article.countDocuments();

  return {
    insertedCount,
    updatedCount,
    totalCount
  };
};

/*
 * Safely seeds trips and Travel Blog articles without deleting
 * existing application data.
 */
const seedDB = async () => {
  try {
    await mongoose.connect(
      dbURI,
      {
        autoIndex: false
      }
    );

    console.log(
      `Mongoose connected to ${dbURI}`
    );

    const tripResults =
      await seedTrips();

    console.log('');

    const articleResults =
      await seedArticles();

    console.log('');
    console.log(
      `Trips updated: ${tripResults.updatedCount}`
    );
    console.log(
      `Trips inserted: ${tripResults.insertedCount}`
    );
    console.log(
      `Trips in database: ${tripResults.totalCount}`
    );

    console.log('');

    console.log(
      `Articles updated: ${articleResults.updatedCount}`
    );
    console.log(
      `Articles inserted: ${articleResults.insertedCount}`
    );
    console.log(
      `Articles in database: ${articleResults.totalCount}`
    );
  } catch (error) {
    console.error(
      'Database seed failed:',
      error.message
    );

    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();

    console.log(
      'Mongoose disconnected'
    );
  }
};

seedDB();